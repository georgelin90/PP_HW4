#!/bin/bash
TESTCASE_DIR="testcase"
OUTPUT_DIR="output"
ANSWER_DIR="answer"
EXEC_DIR="exec"

if [ $# -eq 0 ]; then
    rm -f grade.csv
    echo "student id,t1,t2,t3,t4,t5,bonus1,bonus2" > grade.csv
fi

for entry in ./${EXEC_DIR}/*
do
    student_id=$(echo ${entry} | awk '{print substr($1, 8, 7)}')

    grade="$student_id"

    echo Testing $student_id

    rm -f ${OUTPUT_DIR}/* test.tar

    cp basic/test.tar test.tar

    ${entry} -f tarfs > /dev/null & 
    PROGRAM_PID=$!
    sleep 1
    for i in $( seq 1 5 ); do
    ./${TESTCASE_DIR}/$i.txt &> ${OUTPUT_DIR}/${i}.txt
    diff -w ${OUTPUT_DIR}/${i}.txt ${ANSWER_DIR}/${i}.txt > /dev/null
    if [ $? -eq 0 ]; then
        grade="${grade},20"
    else
        grade="${grade},0"
    fi
    done

    kill ${PROGRAM_PID}
    rm -f test.tar

    cp bonus/test.tar test.tar

    ${entry} -f tarfs > /dev/null & 
    PROGRAM_PID=$!
    sleep 1
    for i in $( seq 6 7 ); do

    ./${TESTCASE_DIR}/$i.txt &> ${OUTPUT_DIR}/${i}.txt
    diff -w ${OUTPUT_DIR}/${i}.txt ${ANSWER_DIR}/${i}.txt > /dev/null
    if [ $? -eq 0 ]; then
        grade="${grade},5"
    else
        grade="${grade},0"
    fi
    done
    kill ${PROGRAM_PID}

    echo $grade >> grade.csv
done