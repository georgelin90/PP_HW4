#!/bin/bash

rm -f ./exec/*
rm -Rf -- ./student_code/*/
cd student_code


compile_error=""
format_error=""
for entry in *
do
	student_id=$(echo ${entry} | sed 's/.*\([[:digit:]]\{7\}\).*/\1/')
	# echo $student_id
	if [[ ${entry} =~ ^(.*)(\.c)$ ]]
	then
		gcc -w -o ../exec/${student_id}.out "${entry}" `pkg-config fuse --cflags --libs` > /dev/null
		if [ $? -ne 0 ]; then
			compile_error="${compile_error} ${student_id}"
		fi
	elif [[ ${entry} =~ ^(.*)(\.cpp)$ ]]
	then
		g++ -w -o ../exec/${student_id}.out "${entry}" `pkg-config fuse --cflags --libs` > /dev/null
		if [ $? -ne 0 ]; then
			compile_error="${compile_error} ${student_id}"
		fi
	elif [[ ${entry} =~ ^(.*)(\.zip)$ ]]
	then
		unzip -o "${entry}" > /dev/null
		if [ -e ${student_id}/Makefile ] || [ -e ${student_id}/makefile ]
		then
			make -C ${student_id}/ > /dev/null
			if [ $? -ne 0 ]; then
				compile_error="${compile_error} ${student_id}"
			fi
			cp ${student_id}/${student_id}.out ../exec/
			if [ $? -ne 0 ]; then
				format_error="${format_error} ${student_id}"
			fi
		else
			format_error="${format_error} ${student_id}"
			if [ -e ${student_id}/*c ]
			then
				gcc -w -o ../exec/${student_id}.out ${student_id}/*c `pkg-config fuse --cflags --libs` > /dev/null
				if [ $? -ne 0 ]; then
					compile_error="${compile_error} ${student_id}"
				fi					
			elif [ -e ${student_id}/*cpp ]
			then
				g++ -w -o ../exec/${student_id}.out ${student_id}/*cpp `pkg-config fuse --cflags --libs` > /dev/null
				if [ $? -ne 0 ]; then
					compile_error="${compile_error} ${student_id}"
				fi
			fi
		fi
	fi
	# echo ${student_id} done
done

echo compile_error=${compile_error}
echo format_error=${format_error}
exit
