/*
Student No.: 0616225
Student Name: 張承遠
Email: yuaannn_192.cs06@g2.nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/

#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <string.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <errno.h>
#include <map>
#include <vector>
using namespace std;
struct tar_attr {
    string file_name;
    int file_mode;
    int user_id;
    int group_id;
    int file_size;
    int m_time;
    char link_flag;

    char content[100000];
};
tar_attr read_tar(fstream &file);


int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
    cout << "readdir " << path << '\n';
    fstream file;
    file.open("test.tar", ios::in | ios::binary);
    vector<string> fil;

    map<string, int> m;
    while(!file.eof() ) {
        tar_attr tt;
        tt = read_tar(file);
        if (tt.file_name == "") continue;
        string fname = "/" + tt.file_name;
        string p = string(path);
	if (p != "/") p = (p + "/");
        if ( (fname.substr(0, p.size() ) ) != p ) continue;
        int findslash = fname.find('/', p.size() );
        if (findslash != string::npos){
            if ( findslash != (fname.size()-1) )
                continue;
            else
                findslash = fname.size()-p.size()-1;
        }
        else
            findslash = fname.size()-p.size();
	if (fname.substr(p.size(), findslash).size()==0) continue;
        string sf = fname.substr(p.size(), findslash);
	cout << "\n\n";
	cout << "file name: " << tt.file_name << "\n\n";
	cout << "modified time: " << tt.m_time << "\n\n";
	if (m.find(sf) != m.end() )
	    if (m[sf] > tt.m_time)
		continue;
	m[sf] = tt.m_time;


		
	cout << "readdir: " << ("/"+tt.file_name) << ' ' << string(path) << '\n';
        //filler(buffer, fname.substr(p.size(), findslash ).c_str()  , NULL, 0);
        cout << "success read " << fname.substr(p.size(), findslash).c_str() << '\n'; 
    }
    map<string, int>::iterator it;
    for (it=m.begin(); it!=m.end() ; it++)
	filler(buffer, (it->first).c_str(), NULL, 0);

    //filler(buffer, "tar.html", NULL, 0);
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    file.close();
    return 0;
}
int my_getattr(const char *path, struct stat *st){
    fstream file;
    if (strcmp(path, "/")==0){
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    file.open("test.tar", ios::in | ios::binary);
    //    cout << "find " << path << '\n';
    map<string, int> m;
    bool succ = false;
    while(!file.eof()){
	tar_attr tt;
        tt = read_tar(file);
	string fname = tt.file_name;
	if (tt.link_flag == '5'){
		//fname.pop_back();
		fname = fname.substr(0, fname.size()-1);
	}
	fname = "/" + fname;
	if (fname != string(path))
		continue;
	// find
	/*cout << "File name: " << tt.file_name << '\n';
	cout << "\n\n modifity time: "<< tt.m_time << "\n\n";*/
	
	if (m.find(fname) != m.end()){
	    if ( m[fname] > tt.m_time )
		continue;
	}
	m[fname] = tt.m_time;
	succ = 1;
	
        st->st_uid = tt.user_id;
        st->st_gid = tt.group_id;
        st->st_mtime = tt.m_time;
        st->st_size = tt.file_size;
       // st->st_mode = tt.file_mode;
        
        if (tt.link_flag == '5') st->st_mode = S_IFDIR | tt.file_mode; 
        else  st->st_mode = S_IFREG | tt.file_mode;

        cout << "gettar: " << "/"+tt.file_name << ' ' << path << '\n';
        //file.close();
        //return 0;
    }
    file.close();
    if(succ) return 0;
    return -ENOENT;

}


int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    fstream file;
    file.open("test.tar", ios::in | ios::binary);
    map<string, int> m;
    bool succ = false;
    while(!file.eof()){
	tar_attr tt;
        tt = read_tar(file);
	string fname = tt.file_name;
	if (tt.link_flag == '5')
		continue;
	fname = "/" + fname;
	if (fname != string(path))
		continue;
	
	if (m.find(fname) != m.end()){
	    if ( m[fname] > tt.m_time )
		continue;
	}
        succ = 1;
	m[fname] = tt.m_time;
	
	    //char rr[100000] = tt.content;
    	char ch[size+2];
    	int cnt = size;
    	for (int i=0; i<size; i++){
            ch[i] = tt.content[offset + i];
       	     cout << ch[i];
        }
        cout << "\n\n\n";
    //    memcpy(buffer, tt.content + offset, sizeof(char) * size);
        memcpy(buffer, ch, sizeof(ch) );
        //return cnt;
    }
    if(succ) return size;
    return 0;
}


static struct fuse_operations op;

int main(int argc, char *argv[]) {
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
 
}
tar_attr read_tar(fstream &file) {
    tar_attr attr;

    char ch[100000]; string name;
    memset(ch, 0, sizeof(ch));

    //read file name
    file.read(ch, 100);
    ch[100] = '\0';
    attr.file_name = string(ch);

    //if (name != string(path) ) continue;
    file.read(ch, 8);
    ch[8] = '\0';
    stringstream ss;
    ss << string(ch); ss >> oct >> attr.file_mode;

    file.read(ch, 8);
    ch[8] = '\0';
    ss.clear(); ss.str("");
    ss << string(ch); ss >> oct >> attr.user_id;

    file.read(ch, 8);
    ch[8] = '\0';
    ss.clear(); ss.str("");
    ss << string(ch); ss >> oct >> attr.group_id;

    file.read(ch, 12);
    ch[12] = '\0';
    ss.clear(); ss.str("");
    ss << string(ch); ss >> oct >> attr.file_size;

    file.read(ch, 12);
    ch[12] = '\0';
    ss.clear(); ss.str("");
    ss << string(ch); ss >> oct >> attr.m_time;

    file.read(ch, 8);

    file.read(ch, 1);
    ch[1] = '\0';
    attr.link_flag = ch[0];
    ss.clear(); ss.str("");
    
    
    //read until end
    file.read(ch, 355);
    ch[355] = '\0';

    int num = ((attr.file_size + 511) & (~511) );

    file.read(ch, num);
    ch[num] = '\0';
    //attr.content = ch;
    memcpy(attr.content, ch, sizeof(ch));
    return attr;
}


