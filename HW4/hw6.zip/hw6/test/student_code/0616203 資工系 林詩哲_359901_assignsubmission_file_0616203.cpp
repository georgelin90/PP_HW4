/*
Student No.: 0616203
Student Name: 林詩哲
Email: lin130917.cs06@g2.nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <bits/stdc++.h>
#include <unistd.h>

using namespace std;

string strbuffer;
map<string, int> mfhloc;
map<string, int>::iterator hit;
map<string, vector<string> > mdire;
map<string, vector<string> >::iterator dit;;
map<string, pair<string, int> > mfile;
map<string, pair<string, int> >::iterator fit;

int octal_string_to_int(string str) {
    unsigned int output = 0;
    for (int i = 0; i < str.size(); i++) {
		if (isdigit(str[i])) output = output * 8 + str[i] - '0';
    }
    return output;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
	filler(buffer, ".", NULL, 0);
	filler(buffer, "..", NULL, 0);
	string strpath(path);
	if (mdire.find(strpath) != mdire.end()) {
		for (int i = 0; i < mdire[strpath].size(); i++)
			filler(buffer, (mdire[strpath][i]).c_str(), NULL, 0);
	}
	return 0;
}

int my_getattr(const char *path, struct stat *st) {
	string strpath(path);
	// cout << "path: " << strpath << "\n";
	if (strcmp(path, "/") == 0) {
		st->st_mode = S_IFDIR | 0444;
	} else if (mfhloc.find(strpath) != mfhloc.end()) {
		int loc = mfhloc[strpath], flag = -1;
		int accessMode = octal_string_to_int(strbuffer.substr(loc+100, 7));
		st->st_uid = octal_string_to_int(strbuffer.substr(loc+108, 7));
		st->st_gid = octal_string_to_int(strbuffer.substr(loc+116, 7));
		st->st_size = octal_string_to_int(strbuffer.substr(loc+124, 11));
		st->st_mtime = octal_string_to_int(strbuffer.substr(loc+136, 11));
		switch(strbuffer[loc + 156]){
			case '0': // intentionally dropping through
			case '\0':
				// normal file
				flag = 1;
				break;
			case '1':
				// hard link
				break;
			case '2':
				// symbolic link
				break;
			case '3':
				// device file/special file
				break;
			case '4':
				// block device
				break;
			case '5':
				// directory
				flag = 0;
				break;
			case '6':
				// named pipe
				break;
		}
		if (flag == 0) {
			st->st_mode = S_IFDIR | accessMode;
		} else if (flag == 1) {
			st->st_mode = S_IFREG | accessMode;
		}
	} else {
		return -ENOENT;
	}
	return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
	string strpath(path);
	if (mfile.find(strpath) == mfile.end())
		return 0;
	size_t len = mfile[strpath].second;
	if (offset >= len) {
		return 0;
	}
	if (offset + size > len) {
		memcpy(buffer, mfile[strpath].first.c_str() + offset, len - offset);
		return len - offset;
	}
	memcpy(buffer, mfile[strpath].first.c_str() + offset, size);
	return size;
}

static struct fuse_operations op;

int main(int argc, char *argv[]) {
	ifstream fin("test.tar");
	stringstream ss;
	ss << fin.rdbuf();
	strbuffer = ss.str();
	fin.close();

	int location = 0, contentSize = strbuffer.size() - (512*2);
	while (location < contentSize) {
		// cout << "location: " << location << "\n";

		string fname(strbuffer, location, 99);
		fname.erase(find(fname.begin(), fname.end(), '\0'), fname.end());
		// cout << "filename: " << fname << "\n";
		string newfname = "/" + fname;

		int flag = -1;
		switch(strbuffer[location + 156]){
			case '0': // intentionally dropping through
			case '\0':
				// normal file
				flag = 1;
				break;
			case '1':
				// hard link
				break;
			case '2':
				// symbolic link
				break;
			case '3':
				// device file/special file
				break;
			case '4':
				// block device
				break;
			case '5':
				// directory
				flag = 0;
				break;
			case '6':
				// named pipe
				break;
		}

		// cout << "flag: " << flag << "\n";

		if (flag == 0) {
			newfname.erase(newfname.size() - 1);
		}

		if (mfhloc.find(newfname) != mfhloc.end()) {
			contentSize -= (512*2);
		}
		mfhloc[newfname] = location;

		int fsize = octal_string_to_int(strbuffer.substr(location+124, 11));
		// cout << "filesize: " << fsize << "\n";

		location += 512;
		if (flag == 1) {
			if (fsize > 0) {
				string file_contents(strbuffer, location, fsize);
				mfile[newfname] = make_pair(file_contents, fsize);
				location = location + (((fsize - 1) / 512) + 1) * 512;
			} else {
				mfile[newfname] = make_pair(string(""), fsize);
			}
		} else if (flag == 0) {
			if (mdire.find(newfname) == mdire.end()) {
				mdire[newfname] = vector<string>();
			}			
		}

		size_t found = newfname.find_last_of("/");
		string dire = newfname.substr(0, found);
		if (dire == "") dire = dire + "/";
		string file = newfname.substr(found + 1);
		if (mdire.find(dire) == mdire.end()) {
			mdire[dire] = vector<string>();
		}
		if (find(mdire[dire].begin(), mdire[dire].end(), file) == mdire[dire].end())
			mdire[dire].push_back(file);
		
		// cout << "\n";
	}

	// cout << "total size: " << contentSize << "\n";

	// for (hit = mfhloc.begin(); hit != mfhloc.end(); hit++) {
	// 	cout << hit->first << " " << hit->second << "\n";
	// }
	// cout << "\n";
	// for (dit = mdire.begin(); dit != mdire.end(); dit++) {
	// 	cout << dit->first << " " << (dit->second).size() << "\n";
	// }
	// cout << "\n";
	// for (fit = mfile.begin(); fit != mfile.end(); fit++) {
	// 	cout << fit->first << " " << (fit->second).first.size() << " " << (fit->second).second << "\n";
	// }

	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	return fuse_main(argc, argv, &op, NULL);
}