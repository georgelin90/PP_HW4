/*
Student No.: 0612255
Student Name: Yi-Ju Pan
Email: E.P.880107@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30

#include <iostream>
#include <string>
#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>

using namespace std;

struct header{
	char name[100], mode[8], uid[8], gid[8];
	char size[12], time[12];
	char checksum[8], flag[1];
	char link[100], ustar[8];
	char user[32], group[32], major[8], minor[8];
	char padding[167];
};

long long int oct2dec(long long int octal)
{
	long long int dec = 0, e = 0, digit;
	while (octal != 0) {
		digit = octal % 10;
		dec += digit * pow(8, e);
		e++;
		octal /= 10;
	}
	return dec;
}

void readheader(FILE *fp, header &temp)
{
	fread(temp.name, 100, 1, fp);
	fread(temp.mode, 8,1,fp);
	fread(temp.uid, 8,1,fp);
	fread(temp.gid, 8,1,fp);
	fread(temp.size, 12,1,fp);
	fread(temp.time, 12,1,fp);
	fread(temp.checksum, 8,1,fp);
	fread(temp.flag, 1,1,fp);
	fread(temp.link, 100,1,fp);
	fread(temp.ustar, 8,1,fp);
	fread(temp.user, 32,1,fp);
	fread(temp.group, 32,1,fp);
	fread(temp.major, 8,1,fp);
	fread(temp.minor, 8,1,fp);
	fread(temp.padding, 167,1,fp);
	return;
}

int my_getattr(const char *path, struct stat *st) {
	/*do something*/
	if(strcmp(path, "/") == 0){
		st->st_mode = S_IFDIR | 0444;
		st->st_uid = 1000;
		st->st_gid = 1000;
		st->st_mtime = 0;
		st->st_size = 0;
		return 0;
	}

	char fixpath[100] = "\0";
	memmove(fixpath, path+1, strlen(path)-1);
	
	FILE *fp;
	fp = fopen("test.tar", "r");

	header temp;
	readheader(fp, temp);
	while(!feof(fp)){
		if(strlen(temp.name) == 0){
			readheader(fp, temp);
			continue;
		}
		int size = oct2dec(atoi(temp.size));
		while(size>0)
		{
			char discard[512];
			fread(discard, 512, 1, fp);			
			size -= 512;
		}
		string n = temp.name;
		if(n.at(n.size()-1) == '/')
			n.erase(n.size()-1, 1);	
		
		if(strcmp(n.c_str(),fixpath)==0){
			string n = temp.name;
			if(n.at(n.size()-1) == '/'){
				st->st_mode = S_IFDIR | strtol(temp.mode, NULL, 8);
			}else{
				st->st_mode = S_IFREG | strtol(temp.mode, NULL, 8);
			}
			st->st_uid = oct2dec(atoll(temp.uid));
			st->st_gid = oct2dec(atoll(temp.gid));
			st->st_mtime = oct2dec(atoll(temp.time));
			st->st_size = oct2dec(atoll(temp.size));
			fclose(fp);
			return 0;
		}
		readheader(fp, temp);
	}
	fclose(fp);
	return -ENOENT;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
	/*do something*/
	printf("%s\n", path);
	char fixpath[100] = "\0";
	memmove(fixpath, path+1, strlen(path)-1);
	printf("%s\n", fixpath);

	FILE *fp;
	fp = fopen("test.tar", "r");

	header temp;
	readheader(fp, temp);
	while(!feof(fp)){
		if(strlen(temp.name) == 0){
			readheader(fp, temp);
			continue;
		}
		int size = oct2dec(atoi(temp.size));
		while(size>0)
		{
			char discard[512];
			fread(discard, 512, 1, fp);			
			size -= 512;
		}
		string n = temp.name;
		
		if(n.at(n.size()-1) == '/')
			n.erase(n.size()-1, 1);	
		char dir[100] = "";
		size_t found = n.rfind('/');
		if(found!=n.npos){
			n.copy(dir, found, 0);
			n.erase(0, found+1);
		}

		if(strcmp(fixpath, dir)==0)
			filler(buffer, n.c_str(), NULL, 0);
		readheader(fp, temp);
	}
	fclose(fp);
	return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
	/*do something*/
	char fixpath[100] = "\0";
	memmove(fixpath, path+1, strlen(path)-1);
	printf("%s\n", fixpath);
	
	FILE *fp;
	fp = fopen("test.tar", "r");

	header temp;
	readheader(fp, temp);
	while(!feof(fp)){
		if(strlen(temp.name) == 0){
			readheader(fp, temp);
			continue;
		}

		if(strcmp(temp.name,fixpath)==0){
			while(offset>0)
			{
				char *discard = new char[offset];
				fread(discard, offset, 1, fp);			
			}
			fread(buffer, size, 1, fp);
			fclose(fp);
			return strlen(buffer);
		}
		
		int size = oct2dec(atoi(temp.size));
		while(size>0)
		{
			char discard[512];
			fread(discard, 512, 1, fp);			
			size -= 512;
		}
		readheader(fp, temp);
	}
	fclose(fp);
	return 0;
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

