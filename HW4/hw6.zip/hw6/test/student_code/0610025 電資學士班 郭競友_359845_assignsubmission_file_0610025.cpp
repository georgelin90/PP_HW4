/*
Student No.: 0610025
Student Name: Jill Kuo
Email: lisakuo912052@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/

#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>

long long string2int(char* octal_string, int string_len){
	long long result = 0;
	while(string_len--){
		if(*octal_string >= '0' && *octal_string <= '7')
			result = result*8 + *octal_string - '0';
		octal_string++;
	}
	return result;
}

int get_depth(const char* path){
	int path_len = strlen(path);
	int depth = 0;
	for(int i=0; i<path_len; i++){
		if(path[i] == '/') depth++;
	}
	return depth;
}

int is_inCurrentDir(const char* path, char* file_name, char typeflag){
	int path_len = strlen(path) - 1;
	char temp_path[100];
	int flag = (typeflag == '5')? 1: 0;
	strcpy(temp_path,path+1);
	if(path_len == 0){
		if(get_depth(file_name)-flag == 0) return 1;
		return 0;
	}
	else{
		strcat(temp_path,"/");
		path_len++;
		if(strncmp(temp_path,file_name,path_len)){/* not the same */
			return 0;
		}
		if(get_depth(path) == get_depth(file_name) - flag){
			return 1;
		}
		else{
			return 0;
		}
	}
}

int is_theFile(const char* path, char* file_name, char typeflag){
	int path_len = strlen(path) - 1;
	char temp_path[100];
	strcpy(temp_path,path+1);
	if(typeflag == '5') file_name[strlen(file_name)-1] = '\0';
	if(strncmp(temp_path,file_name,path_len) || path_len != strlen(file_name)) return 0;
	return 1;
}

char* get_name(const char* path, char* file_name, char typeflag){
	int path_len = strlen(path) - 1;
	char* temp = (char*)malloc(sizeof(char)*100);
	strcpy(temp,file_name+path_len);
	if(typeflag == '5') temp[strlen(temp)-1] = '\0';
	if(temp[0] == '/') temp++;
	return temp;
}

int my_getattr(const char *path, struct stat *st) { 
	FILE* fp;
	int n_block = 0;
	int flag = 0;
	char file_name[100];	// offset 0
	char file_mode[8];		// offset 100
	char uid[8];			// offset 108
	char gid[8];			// offset 116
	char size[12];			// offset 124
	char mtime[12];			// offset 136
//	char chksum[8];			// offset 148
	char typeflag[1];		// offset 156
	int n_zero;
	char zero[100];

	if(!strncmp(path,"/",1) && strlen(path) == 1){
		printf("root\n");
		st->st_mode = S_IFDIR | 0444;
		st->st_uid = getuid();
		st->st_gid = getgid();
		return 0;
	}
	memset(zero,0,100);
	fp = fopen("test.tar","rb");
	if(fp == NULL){
		fprintf(stderr,"open input file error\n");
		exit(0);
	}
	do{
		fseek(fp, 512 * n_block, SEEK_SET);
		fread(file_name, sizeof(file_name), 1, fp);
		fseek(fp, 512 * n_block+100, SEEK_SET);
		fread(file_mode, sizeof(file_mode), 1, fp);
		fseek(fp, 512 * n_block+108, SEEK_SET);
		fread(uid, sizeof(uid), 1, fp);
		fseek(fp, 512 * n_block+116, SEEK_SET);
		fread(gid, sizeof(gid), 1, fp);
		fseek(fp, 512 * n_block+124, SEEK_SET);
		fread(size, sizeof(size), 1, fp);
		fseek(fp, 512 * n_block+136, SEEK_SET);
		fread(mtime, sizeof(mtime), 1, fp);
		fseek(fp, 512 * n_block+156, SEEK_SET);
		fread(typeflag, sizeof(typeflag), 1, fp);
		n_zero = memcmp(file_name, zero, 100);
		
		if(n_zero){
			
			if(is_theFile(path,file_name, typeflag[0])){
				if(typeflag[0]=='5'){
					st->st_mode = S_IFDIR | string2int(file_mode,strlen(file_mode));
				}
				else{
					st->st_mode = S_IFREG | string2int(file_mode,strlen(file_mode));
				}
				flag = 1;
				st->st_uid = string2int(uid,strlen(uid));
				st->st_gid = string2int(gid,strlen(gid));
				st->st_size = string2int(size,strlen(size));
				st->st_mtime = string2int(mtime,strlen(mtime));
			}
			int n_size = (string2int(size,strlen(size))+511)/512;
			n_block = n_block + n_size + 1;
		}
	}while(n_zero);

	fclose(fp);
	if(flag) return 0;
	return -ENOENT;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {  
	FILE* fp;
	int n_block = 0;
	char file_name[100];	// offset 0
//	char file_mode[8];		// offset 100
//	char uid[8];			// offset 108
//	char gid[8];			// offset 116
	char size[12];			// offset 124
//	char mtime[12];			// offset 136
//	char chksum[8];			// offset 148
	char typeflag[1];		// offset 156
	int n_zero;
	char zero[100];

	filler(buffer,".",NULL,0);
	filler(buffer,"..",NULL,0);
	memset(zero,0,100);
	fp = fopen("test.tar","rb");
	if(fp == NULL){
		fprintf(stderr,"open input file error\n");
		exit(0);
	}
	do{
		fseek(fp, 512 * n_block, SEEK_SET);
		fread(file_name, sizeof(file_name), 1, fp);
		fseek(fp, 512 * n_block+124, SEEK_SET);
		fread(size, sizeof(size), 1, fp);
		fseek(fp, 512 * n_block+156, SEEK_SET);
		fread(typeflag, sizeof(typeflag), 1, fp);
		n_zero = memcmp(file_name, zero, 100);
		if(n_zero){
			
			if(is_inCurrentDir(path,file_name,typeflag[0])){
				char* temp = get_name(path,file_name,typeflag[0]);
				filler(buffer,temp,NULL,0);
			}
			int n_size = (string2int(size,strlen(size))+511)/512;
			n_block = n_block + n_size + 1;
		}
	}while(n_zero);

	fclose(fp);
	return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
	FILE* fp;
	int n_block = 0;
	char file_name[100];	// offset 0
//	char file_mode[8];		// offset 100
//	char uid[8];			// offset 108
//	char gid[8];			// offset 116
	char b_size[12];		// offset 124
	char mtime[12];			// offset 136
//	char chksum[8];			// offset 148
	char typeflag[1];		// offset 156
	int n_zero;
	char* temp;
	char zero[100];
	memset(zero,0,100);
	fp = fopen("test.tar","rb");
	if(fp == NULL){
		fprintf(stderr,"open input file error\n");
		exit(0);
	}
	do{
		fseek(fp, 512 * n_block, SEEK_SET);
		fread(file_name, sizeof(file_name), 1, fp);
		fseek(fp, 512 * n_block+124, SEEK_SET);
		fread(b_size, sizeof(b_size), 1, fp);
		fseek(fp, 512 * n_block+136, SEEK_SET);
		fread(mtime, sizeof(mtime), 1, fp);
		fseek(fp, 512 * n_block+156, SEEK_SET);
		fread(typeflag, sizeof(typeflag), 1, fp);

		n_zero = memcmp(file_name, zero, 100);
		
		if(n_zero){
			
			if(is_theFile(path,file_name,typeflag[0])){
				long long n = string2int(b_size,strlen(b_size));
				n_block++;
				temp = (char*)malloc(n);
				fseek(fp, 512 * n_block, SEEK_SET);
				for(long long i=0; i<n; i++){
					temp[i] = getc(fp);
				}
				if(offset < n){
					if(offset+size > n) size = n - offset;
					memcpy(buffer, temp + offset, size);
				}
				else{
					size = 0;
				}
				fclose(fp);
				return size;
			}
			int n_size = (string2int(b_size,strlen(b_size))+511)/512;
			n_block = n_block + n_size + 1;
		
		}
	}while(n_zero);

	fclose(fp);
	return 0;
}

static struct fuse_operations op;

int main(int argc, char *argv[])
{
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

