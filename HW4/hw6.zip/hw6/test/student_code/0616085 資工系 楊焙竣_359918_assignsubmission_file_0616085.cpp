/*
Student No.: 0616085
Student Name: PeiChun Yang
Email: hchs310160@gmail.com.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <iterator>
#include <cmath>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <string>
#include <cstring>
#include <fstream>
#include <map>
#include <utility>
#include <queue>
#include <algorithm>
#include <iomanip>

/* The linkflag defines the type of file */
#define LF_OLDNORMAL '\0' /* Normal disk file, Unix compatible */
#define LF_NORMAL '0'	 /* Normal disk file */
#define LF_LINK '1'		  /* Link to previously dumped file */
#define LF_SYMLINK '2'	/* Symbolic link */
#define LF_CHR '3'		  /* Character special file */
#define LF_BLK '4'		  /* Block special file */
#define LF_DIR '5'		  /* Directory */
#define LF_FIFO '6'		  /* FIFO special file */
#define LF_CONTIG '7'	 /* Contiguous file */

using namespace std;

class TarNode
{
	// Offset   Length   Contents
	//   0    100 bytes  File name ('\0' terminated, 99 maxmum length)
	// 100      8 bytes  File mode (in octal ascii)
	// 108      8 bytes  User ID (in octal ascii)
	// 116      8 bytes  Group ID (in octal ascii)
	// 124     12 bytes  File size (s) (in octal ascii)
	// 136     12 bytes  Modify time (in octal ascii)
	// 148      8 bytes  Header checksum (in octal ascii)
	// 156      1 bytes  Link flag
	// 157    100 bytes  Linkname ('\0' terminated, 99 maxmum length)
	// 257      8 bytes  Magic ("ustar  \0")
	// 265     32 bytes  User name ('\0' terminated, 31 maxmum length)
	// 297     32 bytes  Group name ('\0' terminated, 31 maxmum length)
	// 329      8 bytes  Major device ID (in octal ascii)
	// 337      8 bytes  Minor device ID (in octal ascii)
	// 345    167 bytes  Padding
	// 512   (s+p)bytes  File contents (s+p) := (((s) + 511) & ~511), round up to 512 bytes
public:
	string FileName;
	int FileMode;
	int UserID;
	int GroupID;
	int FileSize;
	int ModifyTime;
	string HeaderChecksum;
	string LinkFlag;
	string Linkname;
	string Magic;
	string UserName;
	string GroupName;
	int MajorDeviceID;
	int MinorDeviceID;
	string FileContents;

	TarNode(string _FileName,
			int _FileMode,
			int _UserID,
			int _GroupID,
			int _FileSize,
			int _ModifyTime,
			string _HeaderChecksum,
			string _LinkFlag,
			string _LinkName,
			string _Magic,
			string _UserName,
			string _GroupName,
			int _MajorDeviceID,
			int _MinorDeviceID,
			string _FileContents)
	{
		FileName = _FileName;
		FileMode = _FileMode;
		UserID = _UserID;
		GroupID = _GroupID;
		FileSize = _FileSize;
		ModifyTime = _ModifyTime;
		HeaderChecksum = _HeaderChecksum;
		LinkFlag = _LinkFlag;
		_LinkName = _LinkName;
		Magic = _Magic;
		UserName = _UserName;
		GroupName = _GroupName;
		MajorDeviceID = _MajorDeviceID;
		MinorDeviceID = _MinorDeviceID;
		FileContents = _FileContents;
	}
	TarNode() {}
	~TarNode() {}
};

vector<TarNode> globalTable;
int str8ToInt10(char *bufferBase, int start, int end)
{
	int sum = 0;
	for (int i = start; i < end; i++)
	{
		char ch = *(bufferBase + i);
		if (isdigit(ch))
		{
			sum *= 8;
			sum += (ch - '0');
		}
	}
	return sum;
}

void readfile()
{
	fstream TargetFile;
	TargetFile.open("test.tar", ios::in);

	if (!TargetFile)
		cout << "error\n";
	else
	{
		//local node data
		string L_FileName;
		int L_FileMode;
		int L_UserID;
		int L_GroupID;
		int L_FileSize;
		int L_ModifyTime;
		string L_HeaderChecksum;
		string L_LinkFlag;
		string L_LinkName;
		string L_Magic;
		string L_UserName;
		string L_GroupName;
		int L_MajorDeviceID;
		int L_MinorDeviceID;
		string L_FileContents;

		char buffer[512];

		bool isHeader = true;
		int fileSizeCounter = 0;
		//read each block
		while (TargetFile.read(buffer, sizeof(buffer)))
		{

			//header
			if (fileSizeCounter == 0)
			{
				//detect file name
				L_FileName += '/';
				for (int i = 0; i < 100; i++)
				{
					if (buffer[i] != '\0')
						L_FileName += buffer[i];
					else
						break;
				}
				if (L_FileName[L_FileName.size() - 1] == '/')
					L_FileName.resize(L_FileName.size() - 1);
				//detect file mode
				L_FileMode = str8ToInt10(buffer, 100, 108);
				//detect user id
				L_UserID = str8ToInt10(buffer, 108, 116);
				//detect group id
				L_GroupID = str8ToInt10(buffer, 116, 124);
				//detect file size (_8 to _10)
				bool isEmpty = false;
				for (int i = 124; i < 135; i++)
				{
					char ch = buffer[i];
					if (isdigit(ch))
					{
						fileSizeCounter *= 8;
						fileSizeCounter += (ch - '0');
					}
					else
					{
						L_FileName.clear();
						L_FileMode = 0;
						L_UserID = 0;
						L_GroupID = 0;
						L_FileSize = 0;
						L_ModifyTime = 0;
						L_HeaderChecksum.clear();
						L_LinkFlag.clear();
						L_LinkName.clear();
						L_Magic.clear();
						L_UserName.clear();
						L_GroupName.clear();
						L_MajorDeviceID = 0;
						L_MinorDeviceID = 0;
						L_FileContents.clear();
						isEmpty = true;
						break;
					}
				}
				if (isEmpty)
					continue;
				//cout << fileSizeCounter << endl;
				L_FileSize = fileSizeCounter;
				//detect modify time (_8 string)
				L_ModifyTime = str8ToInt10(buffer, 136, 148);
				//detect header checksum (_8 string)
				for (int i = 148; i < 155; i++)
					L_HeaderChecksum += buffer[i];
				//detect link flag
				for (int i = 156; i < 157; i++)
					L_LinkFlag += buffer[i];
				//detect link name
				for (int i = 157; i < 257; i++)
				{
					if (buffer[i] != '\0')
						L_LinkName += buffer[i];
					else
						break;
				}
				//detect magic
				for (int i = 257; i < 265; i++)
					L_Magic += buffer[i];
				//detect user name
				for (int i = 265; i < 297; i++)
				{
					if (buffer[i] != '\0')
						L_UserName += buffer[i];
					else
						break;
				}
				//detect group name
				for (int i = 297; i < 329; i++)
				{
					if (buffer[i] != '\0')
						L_GroupName += buffer[i];
					else
						break;
				}
				//detect major device ID
				L_MajorDeviceID = str8ToInt10(buffer, 329, 337);
				//detect minor device ID
				L_MinorDeviceID = str8ToInt10(buffer, 337, 345);
				if (fileSizeCounter == 0)
				{
					vector<TarNode>::iterator it = globalTable.begin();
					for (; it != globalTable.end(); it++)
						if ((*it).FileName == L_FileName)
							break;
					if (it == globalTable.end())
					{
						globalTable.push_back(TarNode(L_FileName,
													  L_FileMode,
													  L_UserID,
													  L_GroupID,
													  L_FileSize,
													  L_ModifyTime,
													  L_HeaderChecksum,
													  L_LinkFlag,
													  L_LinkName,
													  L_Magic,
													  L_UserName,
													  L_GroupName,
													  L_MajorDeviceID,
													  L_MinorDeviceID,
													  L_FileContents));
						L_FileName.clear();
						L_FileMode = 0;
						L_UserID = 0;
						L_GroupID = 0;
						L_FileSize = 0;
						L_ModifyTime = 0;
						L_HeaderChecksum.clear();
						L_LinkFlag.clear();
						L_LinkName.clear();
						L_Magic.clear();
						L_UserName.clear();
						L_GroupName.clear();
						L_MajorDeviceID = 0;
						L_MinorDeviceID = 0;
						L_FileContents.clear();
					}
					else
					{
						int insider = (*it).ModifyTime;
						if (L_ModifyTime > insider)
						{
							globalTable.erase(it);
							globalTable.push_back(TarNode(L_FileName,
														  L_FileMode,
														  L_UserID,
														  L_GroupID,
														  L_FileSize,
														  L_ModifyTime,
														  L_HeaderChecksum,
														  L_LinkFlag,
														  L_LinkName,
														  L_Magic,
														  L_UserName,
														  L_GroupName,
														  L_MajorDeviceID,
														  L_MinorDeviceID,
														  L_FileContents));
						}
						L_FileName.clear();
						L_FileMode = 0;
						L_UserID = 0;
						L_GroupID = 0;
						L_FileSize = 0;
						L_ModifyTime = 0;
						L_HeaderChecksum.clear();
						L_LinkFlag.clear();
						L_LinkName.clear();
						L_Magic.clear();
						L_UserName.clear();
						L_GroupName.clear();
						L_MajorDeviceID = 0;
						L_MinorDeviceID = 0;
						L_FileContents.clear();
					}
				}
			}
			//content
			else
			{
				for (int i = 0; i < 512; i++)
				{
					if (fileSizeCounter != 0)
					{
						L_FileContents += buffer[i];
						fileSizeCounter--;
					}
					else
						break;
				}
				//end of content
				if (fileSizeCounter == 0)
				{
					vector<TarNode>::iterator it = globalTable.begin();
					for (; it != globalTable.end(); it++)
						if ((*it).FileName == L_FileName)
							break;
					if (it == globalTable.end())
					{
						globalTable.push_back(TarNode(L_FileName,
													  L_FileMode,
													  L_UserID,
													  L_GroupID,
													  L_FileSize,
													  L_ModifyTime,
													  L_HeaderChecksum,
													  L_LinkFlag,
													  L_LinkName,
													  L_Magic,
													  L_UserName,
													  L_GroupName,
													  L_MajorDeviceID,
													  L_MinorDeviceID,
													  L_FileContents));
						L_FileName.clear();
						L_FileMode = 0;
						L_UserID = 0;
						L_GroupID = 0;
						L_FileSize = 0;
						L_ModifyTime = 0;
						L_HeaderChecksum.clear();
						L_LinkFlag.clear();
						L_LinkName.clear();
						L_Magic.clear();
						L_UserName.clear();
						L_GroupName.clear();
						L_MajorDeviceID = 0;
						L_MinorDeviceID = 0;
						L_FileContents.clear();
					}
					else
					{
						int insider = (*it).ModifyTime;
						if (L_ModifyTime > insider)
						{
							globalTable.erase(it);
							globalTable.push_back(TarNode(L_FileName,
														  L_FileMode,
														  L_UserID,
														  L_GroupID,
														  L_FileSize,
														  L_ModifyTime,
														  L_HeaderChecksum,
														  L_LinkFlag,
														  L_LinkName,
														  L_Magic,
														  L_UserName,
														  L_GroupName,
														  L_MajorDeviceID,
														  L_MinorDeviceID,
														  L_FileContents));
						}
						L_FileName.clear();
						L_FileMode = 0;
						L_UserID = 0;
						L_GroupID = 0;
						L_FileSize = 0;
						L_ModifyTime = 0;
						L_HeaderChecksum.clear();
						L_LinkFlag.clear();
						L_LinkName.clear();
						L_Magic.clear();
						L_UserName.clear();
						L_GroupName.clear();
						L_MajorDeviceID = 0;
						L_MinorDeviceID = 0;
						L_FileContents.clear();
					}
				}
			}
		}
		TargetFile.close();
	}
}
int my_getattr(const char *path, struct stat *st)
{ /*do something*/
	string target(path);
	if (target == "/")
	{
		st->st_mode = S_IFDIR | 0444;
		return 0;
	}
	bool find = false;
	for (int i = 0; i <= globalTable.size(); i++)
	{
		if (globalTable[i].FileName == target)
		{
			st->st_uid = globalTable[i].UserID;
			st->st_gid = globalTable[i].GroupID;
			st->st_mtime = globalTable[i].ModifyTime;
			st->st_size = globalTable[i].FileSize;
			if (globalTable[i].LinkFlag[0] == LF_DIR)
			{
				int accessMode = globalTable[i].FileMode;
				st->st_mode = S_IFDIR | accessMode;
			}
			else
			{
				int accessMode = globalTable[i].FileMode;
				st->st_mode = S_IFREG | accessMode;
			}
			find = true;
			break;
		}
	}
	if (find == false)
	{
		return -ENOENT;
	}
	return 0;
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{ /*do something*/
	vector<string> readdir_path;
	string target(path);
	for (int i = 0; i < globalTable.size(); i++)
	{
		string comparePath = globalTable[i].FileName;
		size_t found = comparePath.find_last_of("/");
		comparePath = comparePath.substr(0, found);
		if (comparePath.size() == 0)
		{
			comparePath += '/';
		}

		if (comparePath == target)
		{
			string final = globalTable[i].FileName;

			size_t found = final.find_last_of("/");
			final = final.substr(found + 1);

			if (find(readdir_path.begin(), readdir_path.end(), final) == readdir_path.end())
			{
				filler(buffer, final.c_str(), NULL, 0);
				readdir_path.push_back(final);
			}
		}
	}
	filler(buffer, ".", NULL, 0);
	filler(buffer, "..", NULL, 0);
	return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi)
{ /*do something*/
	string target(path);
	for (int i = 0; i <= globalTable.size(); i++)
	{
		if (globalTable[i].FileName == target)
		{
			int limit = offset + size;
			if (offset >= globalTable[i].FileContents.size())
			{
				return 0;
			}
			else if (limit > globalTable[i].FileContents.size())
			{
				size = globalTable[i].FileContents.size() - offset;
				memcpy(buffer, globalTable[i].FileContents.c_str() + offset, size);
				return size;
			}
			else
			{
				memcpy(buffer, globalTable[i].FileContents.c_str() + offset, size);
				return size;
			}
		}
	}
	return 0;
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
	readfile();
	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	return fuse_main(argc, argv, &op, NULL);
}
