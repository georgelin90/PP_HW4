/*
Student No.: 0616069
Student Name: 張晉瑋
Email: austin880625@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30

#include <stdio.h>
#include <stdlib.h>
#include <fuse.h>
#include <stddef.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

static struct options {
} options;

#define OPTION(t, p) {t, offsetof(struct options, p), 1}

static const struct fuse_opt opt_spec[] = {
	FUSE_OPT_END
};

char fn[] = "test.tar";
FILE *fp, *lf;
struct tar_header {
	char name[100];
	char mode[8];
	char uid[8];
	char gid[8];
	char size[12];
	char mtime[12];
	char checksum[8];
	char typeflag;
	char linkname[100];
	char magic[6];
	char version[2];
	char uname[32];
	char gname[32];
	char devmaj[8];
	char devmin[8];
	char prefix[155];
	char padding[12];
} head_buffer;

int zero_block(char *buf) {
	for(int i=0; i<512; i++) {
		if(buf[i] != '\0') return 0;
	}
	return 1;
}

int tarfs_is_child(char *name, const char *path) {
	printf("checking child %s and %s\n", name, path);
	if(path[0] == '/')path++;
	int path_len = strlen(path);
	int name_len = strlen(name);
	if(strncmp(name, path, path_len) != 0) return 0;
	if(path_len + 1 == name_len && name[path_len] == '/') return 0;
	if(name[path_len] == '/') {
		path_len++;
	} else if(path_len != 0) {
		return 0;
	}
	int ret = 0;
	for(int i=path_len; i<name_len; i++) {
		if(name[i] == '/') {
			ret++;
		}
	}
	return ret == 0 || (ret == 1 && name[name_len-1] == '/');
}

int tarfs_match_entry(char *name, const char *path) {
	//printf("matching %s and %s\n", name, path);
	if(path[0] == '/')path++;
	int path_len = strlen(path);
	int name_len = strlen(name);
	//printf("lens: %d %d\n", name_len, path_len);
	if(strncmp(name, path, path_len) != 0) return 0;
	if(path_len + 1 == name_len && name[name_len-1] == '/') return 1;
	if(path_len == name_len) return 1;
	return 0;
}

char *tarfs_entry_name(char *name, const char *path) {
	if(path[0] == '/')path++;
	int path_len = strlen(path);
	int name_len = strlen(name);
	if(strncmp(name, path, path_len) != 0) return 0;
	if(name[path_len] == '/') {
		path_len++;
	}
	int ret = 0;
	for(int i=path_len; i<name_len; i++) {
		if(name[i] == '/') {
			name[i] = '\0';
		}
	}
	fprintf(lf, "entry name %s\n", name + path_len);
	return name + path_len;
}


int tarfs_find_entry(const char *path, int back, int inc_child, int skip_content) {
	size_t path_len = strlen(path + 1);
	int ret = -ENOENT;
	fpos_t candidate;
	int mtime = 0;
	memset(&candidate, 0, sizeof(fpos_t));
	while(1) {
		fpos_t current_fpos;
		fgetpos(fp, &current_fpos);
		fread(&head_buffer, 1, 512, fp);
		if(zero_block((char*)&head_buffer)) {
			fread(&head_buffer, 1, 512, fp);
			if(zero_block((char*)&head_buffer)) {
				printf("File end\n");
				break;
			}
		}
		//printf("%s, ", head_buffer.name);
		size_t file_size = 0;
		sscanf(head_buffer.size, "%o", &file_size);
		//printf("%u\n", file_size);
		size_t file_pad_size = ((file_size + 511) & (~511));
		fseek(fp, file_pad_size, SEEK_CUR);
		if(inc_child) {
			if(tarfs_is_child(head_buffer.name, path)) {
				fprintf(lf, "Found child %s\n", head_buffer.name);
				ret = 0;
				break;
			}
		} else {
			if(tarfs_match_entry(head_buffer.name, path)) {
				fprintf(lf, "Found entry %s\n", head_buffer.name);
				ret = 0;
				if(skip_content) {
					//fseek(fp, file_pad_size, SEEK_CUR);
				}
				int current_mtime;
				sscanf(head_buffer.mtime, "%o", &current_mtime);
				if(mtime < current_mtime) {
					mtime = current_mtime;
					candidate = current_fpos;
				}
				//break;
			}
			//fseek(fp, file_pad_size, SEEK_CUR);
		}
	}
	if(!inc_child) {
		fsetpos(fp, &candidate);
		fread(&head_buffer, 1, 512, fp);
	}
	if(back && skip_content)
		fseek(fp, 0, SEEK_SET);
	return ret;
}

/* Values used in typeflag field.  */
#define REGTYPE  '0'            /* regular file */
#define AREGTYPE '\0'           /* regular file */
#define LNKTYPE  '1'            /* link */
#define SYMTYPE  '2'            /* reserved */
#define CHRTYPE  '3'            /* character special */
#define BLKTYPE  '4'            /* block special */
#define DIRTYPE  '5'            /* directory */
#define FIFOTYPE '6'            /* FIFO special */
#define CONTTYPE '7'            /* reserved */

static int tarfs_getattr(const char *path, struct stat *stbuf) {
	fprintf(lf, "getattr %s\n", path);
	memset(stbuf, 0, sizeof(struct stat));
	if(strcmp(path, "/") == 0) {
		stbuf->st_mode = S_IFDIR | 0444;
	} else if(tarfs_find_entry(path, 1, 0, 1) == 0) {
		int mode, uid, gid, mtime, size;
		sscanf(head_buffer.mode, "%o", &mode);
		sscanf(head_buffer.uid, "%o", &uid);
		sscanf(head_buffer.gid, "%o", &gid);
		sscanf(head_buffer.mtime, "%o", &mtime);
		sscanf(head_buffer.size, "%o", &size);
		//fprintf(lf, "%o, %o, %o, %o, %o, %o\n", mode, uid, gid, mtime, size);
		stbuf->st_uid = uid;
		stbuf->st_gid = gid;
		stbuf->st_mtime = mtime;
		stbuf->st_size = size;
		if(head_buffer.typeflag == DIRTYPE) {
			stbuf->st_mode = mode | S_IFDIR;
		} else {
			stbuf->st_mode = mode | S_IFREG;
		}
	} else
		return -ENOENT;
	return 0;
}

static int tarfs_readdir(const char *path, void *buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *info) {
	fprintf(lf, "readdir %s\n", path);
	(void) offset;
	(void) info;
	size_t size_pre = strlen(path+1);
	filler(buf, ".", NULL, 0);
	filler(buf, "..", NULL, 0);
	while(tarfs_find_entry(path, 0, 1, 1) == 0) {
		fpos_t pos;
		fgetpos(fp, &pos);
		char name_base[100] = "/";
		char *name = strcat(name_base, head_buffer.name);
		int name_len = strlen(head_buffer.name);
		if(head_buffer.name[name_len - 1] == '/') {
			name[name_len] = '\0';
		}
		int new_mtime, current_mtime;
		sscanf(head_buffer.mtime, "%o", &current_mtime);
		fseek(fp, 0, SEEK_SET);
		printf("Looking for %s\n", name);
		tarfs_find_entry(name, 0, 0, 1);
		sscanf(head_buffer.mtime, "%o", &new_mtime);
		fsetpos(fp, &pos);
		if((!tarfs_is_child(head_buffer.name, path)) || (current_mtime < new_mtime)) continue;
		filler(buf, tarfs_entry_name(head_buffer.name, path), NULL, 0);
		//filler(buf, "HW6", NULL, 0);
	}
	fseek(fp, 0, SEEK_SET);
	return 0;
}

static int tarfs_open(const char *path, struct fuse_file_info *info) {
	fprintf(lf, "open\n");
	return 0;
}

static int tarfs_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *info) {
	fprintf(lf, "read\n");
	if(tarfs_find_entry(path, 0, 0, 0) == 0) {
		fpos_t pos;
		fgetpos(fp, &pos);
		fseek(fp, offset, SEEK_CUR);
		int step = fread(buf, 1, size, fp);
		size_t file_size = 0;
		sscanf(head_buffer.size, "%o", &file_size);
		size_t file_pad_size = ((file_size + 511) & (~511));
		fseek(fp, 0, SEEK_SET);
		//printf("pad %u\n", file_pad_size);
		fprintf(lf, "read %d bytes\n", step);
		return step;
	} else {
		return -1;
	}
}

struct fuse_operations tarfs_ops = {
	.getattr = tarfs_getattr,
	.readdir = tarfs_readdir,
	.open = tarfs_open,
	.read = tarfs_read
};

int main(int argc, char *argv[]) {
	struct fuse_args args = FUSE_ARGS_INIT(argc, argv);
	if(fuse_opt_parse(&args, &options, opt_spec, NULL) == -1) {
		fprintf(stderr, "option format error\n");
		return 1;
	}
	fp = fopen(fn, "rw");
	//lf = fopen("fs.log", "a");
	lf = stdout;
	//int ret = 0;
	int ret = fuse_main(args.argc, args.argv, &tarfs_ops, NULL);
	fclose(fp);
	//fclose(lf);
	fuse_opt_free_args(&args);
	if(ret != 0) {
		fprintf(stderr, "Exit with return code %d\n", ret);
	}

	return ret;
}
