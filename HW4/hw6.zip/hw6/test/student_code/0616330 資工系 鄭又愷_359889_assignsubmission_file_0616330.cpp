/*
Student No.: 0616330
Student Name: 鄭又愷
Email: at881005@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30
#include <errno.h>
#include <fuse.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fstream>
#include <iostream>
#include <map>

using namespace std;

typedef struct tar_header {
    char name[100];
    int mode;
    int uid;
    int gid;
    long long size;
    timespec mtime;
    int chksum;
    int linkflag;
    char linkname[100];
    char magic[8];
    char uname[32];
    char gname[32];
    int major_dev_id;
    int minor_dev_id;
} tar_header;

tar_header read_header(ifstream& tar);

bool operator<(const timespec& lhs, const timespec& rhs) {
    if (lhs.tv_sec == rhs.tv_sec)
        return lhs.tv_nsec < rhs.tv_nsec;
    else
        return lhs.tv_sec < rhs.tv_sec;
}

string extract_name(const char* name, const char* root) {
    string name_str = name; /* dir1/file1 -> /dir1/file1 */
    name_str = "/" + name_str;
    string root_str = root; /* / -> /, /dir1 -> /dir1/ */
    root_str = (root_str != "/") ? root_str + "/" : "/";

    size_t new_root = name_str.find(root_str);
    if (new_root == string::npos) {
        return "";
    } else {
        size_t start_pos = root_str.length();
        size_t end_pos = name_str.find("/", start_pos);
        return name_str.substr(start_pos, end_pos - start_pos);
    }
}

long long oct2dec(long long oct) {
    long long dec = 0, i = 0, rem;
    while (oct != 0) {
        rem = oct % 10;
        oct /= 10;
        dec += rem * pow(8, i);
        ++i;
    }
    return dec;
}

int my_readdir(const char* path, void* buffer, fuse_fill_dir_t filler,
               off_t offset, struct fuse_file_info* fi) {
    (void)offset;
    (void)fi;

    ifstream tar("./test.tar", ios::binary);
    tar.seekg(0, ios::end);
    long long length = tar.tellg();
    tar.seekg(0, ios::beg);

    long long pos = 0;
    map<string, bool> pool;
    while (pos < length) {
        tar_header header = read_header(tar);
        string name = extract_name(header.name, path);

        if (name.length() > 0 && !pool[name]) {
            pool[name] = true;
            filler(buffer, name.c_str(), NULL, 0);
        }

        int file_size = ((header.size + 511)) & ~511;
        pos += 512 + file_size;
        tar.seekg(pos);
    }

    return 0;
}

int my_getattr(const char* path, struct stat* st) {
    int res = 0;

    memset(st, 0, sizeof(st));

    if (strcmp(path, "/") == 0) {
        st->st_mode = S_IFDIR | 0444;
        st->st_nlink = 2;
        return res;
    }

    res = -ENOENT;

    string target = path;

    ifstream tar("./test.tar", ios::binary);
    tar.seekg(0, ios::end);
    long long length = tar.tellg();
    tar.seekg(0, ios::beg);

    long long pos = 0;
    map<string, timespec> pool;
    while (pos < length) {
        tar_header header = read_header(tar);
        string name = header.name;
        name = "/" + name;

        size_t start_pos = name.find(target);
        if (start_pos == 0 && name == target + '/') {  // dir
            if (!pool.count(name) || pool[name] < header.mtime) {
                st->st_mode = S_IFDIR | header.mode;
                st->st_uid = header.uid;
                st->st_gid = header.gid;
                st->st_mtim = header.mtime;
                st->st_size = 0;
                pool[name] = header.mtime;
            }
            res = 0;
        }

        if (start_pos == 0 && name == target) {  // file
            if (!pool.count(name) || pool[name] < header.mtime) {
                st->st_mode = S_IFREG | header.mode;
                st->st_uid = header.uid;
                st->st_gid = header.gid;
                st->st_mtim = header.mtime;
                st->st_size = header.size;
                pool[name] = header.mtime;
            }
            res = 0;
        }

        int file_size = ((header.size + 511)) & ~511;
        pos += 512 + file_size;
        tar.seekg(pos);
    }

    return res;
}
int my_read(const char* path, char* buffer, size_t size, off_t offset,
            struct fuse_file_info* fi) {
    string target = path;

    ifstream tar("./test.tar", ios::binary);
    tar.seekg(0, ios::end);
    long long length = tar.tellg();
    tar.seekg(0, ios::beg);

    long long pos = 0;
    int ret_size = -ENOENT;
    map<string, timespec> pool;
    while (pos < length) {
        tar_header header = read_header(tar);
        string name = header.name;
        name = "/" + name;

        int file_size = ((header.size + 511)) & ~511;

        if (name == target) {  // file
            tar.seekg(pos + 512 + offset);

            if (!pool.count(name) || pool[name] < header.mtime) {
                if (offset + size < file_size) {
                    tar.read(buffer, size);
                    ret_size = size;
                } else {
                    tar.read(buffer, file_size - offset);
                    ret_size = file_size - offset;
                }
                pool[name] = header.mtime;
            }
        }

        pos += 512 + file_size;
        tar.seekg(pos);
    }

    return ret_size;
}
static struct fuse_operations op;

int main(int argc, char* argv[]) {
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

tar_header read_header(ifstream& tar) {
    // read header
    tar_header ret;
    char buffer[512];
    tar.read((char*)&buffer, 512);

    // parse
    strncpy(ret.name, buffer, 100);

    char mode[9];
    strncpy(mode, buffer + 100, 8);
    mode[8] = '\0';
    ret.mode = oct2dec(atoi(mode));

    char uid[9];
    strncpy(uid, buffer + 108, 8);
    uid[8] = '\0';
    ret.uid = oct2dec(atoi(uid));

    char gid[9];
    strncpy(gid, buffer + 116, 8);
    gid[8] = '\0';
    ret.gid = oct2dec(atoi(gid));

    char size[13];
    strncpy(size, buffer + 124, 12);
    size[12] = '\0';
    ret.size = oct2dec(atoll(size));

    char mtime[13];
    strncpy(mtime, buffer + 136, 12);
    mtime[12] = '\0';
    ret.mtime.tv_sec = oct2dec(atoll(mtime));

    char chksum[13];
    strncpy(chksum, buffer + 148, 8);
    chksum[12] = '\0';
    ret.chksum = oct2dec(atoi(chksum));

    char linkflag[2];
    strncpy(linkflag, buffer + 156, 1);
    linkflag[1] = '\0';
    ret.linkflag = atoi(linkflag);

    strncpy(ret.linkname, buffer + 157, 100);
    strncpy(ret.magic, buffer + 257, 8);
    strncpy(ret.uname, buffer + 265, 32);
    strncpy(ret.gname, buffer + 297, 32);

    char major_dev_id[9];
    strncpy(major_dev_id, buffer + 329, 8);
    major_dev_id[8] = '\0';
    ret.major_dev_id = oct2dec(atoi(major_dev_id));

    char minor_dev_id[9];
    strncpy(minor_dev_id, buffer + 337, 8);
    minor_dev_id[8] = '\0';
    ret.minor_dev_id = oct2dec(atoi(minor_dev_id));

    return ret;
}