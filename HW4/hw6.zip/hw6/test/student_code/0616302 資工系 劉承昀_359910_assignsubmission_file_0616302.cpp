/*
Student No.: 0616302	
Student Name: 劉承昀
Email: pp986300.cs06@g2.nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
using namespace std;

struct TAR{
    char name[100];
    char mode[8];
    char user_id[8];
    char group_id[8];
    char size[12];
    char modify_time[12];
    char checksum[8];
    char linkflag;
    char linkname[100];
    char magic[8];
    char user_name[32];
    char group_name[32];
    char major_device[8];
    char minor_device[8];
    char padding[167];
};

struct file{
	TAR tar;
	char* con;
};

unsigned long long cfs;
vector<file> vec;
void parsing(){
    int f;
    f = open("test.tar",O_RDONLY);
    int ret;
    unsigned long long seek;
    TAR Header,empty;
    int emptyHeader = 0;
    memset(&empty,0,512);
    while(1){
        ret = read(f,&Header,512);
        if( memcmp(&Header, &empty,512) == 0){ //Header is empty
	  emptyHeader++;
          if(emptyHeader == 2) break;
          continue;
        }
        if(memcmp(&Header, &empty,512) == 0) break; 
        emptyHeader = 0;
        seek = (cfs/512) + ((cfs%512)? 1 : 0);
	seek*=512;
	int s;
	file hac; // header and content
	hac.tar = Header;
	sscanf(Header.size,"%o",&s);
	long long int block = ((s + 511) & ~511);
	hac.con = (char*) malloc(block);
	read(f,hac.con,block);
	seek = lseek(f,seek,SEEK_CUR);
	vec.push_back(hac);
	if(seek == -1) break;
    }
}

int my_getattr(const char *path, struct stat *st) { 
	int ret = -1;
	if(string(path) == "/"){
		st->st_mode = S_IFDIR | 0444;
		int uid,gid,mtime;
		sscanf(vec[0].tar.user_id,"%o",&uid);
		sscanf(vec[0].tar.group_id,"%o",&gid);
		sscanf(vec[0].tar.modify_time,"%o",&mtime);
	 	st->st_uid = uid;
		st->st_gid = gid;
		st->st_mtime = mtime;	
		ret = 0;
	}
	for(int i = 0; i<vec.size();i++){
		if("/" + string(vec[i].tar.name) == (string(path) + "/")){
			//a dir
			int mode;
			sscanf(vec[i].tar.mode,"%o",&mode);
			st->st_mode = S_IFDIR | mode;
                	int uid,gid,mtime,s;
                	sscanf(vec[i].tar.user_id,"%o",&uid);
               	 	sscanf(vec[i].tar.group_id,"%o",&gid);
                	sscanf(vec[i].tar.modify_time,"%o",&mtime);
			sscanf(vec[i].tar.size,"%o",&s);
			st->st_size = s;
               	 	st->st_uid = uid;
                	st->st_gid = gid;
                	st->st_mtime = mtime;
			ret = 0;
		}
		else if("/" + string(vec[i].tar.name) == string(path)){
			//a reg
			int mode;
                        sscanf(vec[i].tar.mode,"%o",&mode);
                        st->st_mode = S_IFREG | mode;
                        int uid,gid,mtime,s;
                        sscanf(vec[i].tar.user_id,"%o",&uid);
                        sscanf(vec[i].tar.group_id,"%o",&gid);
                        sscanf(vec[i].tar.modify_time,"%o",&mtime);
                        sscanf(vec[i].tar.size,"%o",&s);
                        st->st_size = s;
			st->st_uid = uid;
                        st->st_gid = gid;
                        st->st_mtime = (st->st_mtime > mtime)? st->st_mtime : mtime;
                        ret = 0;
		}
	}
        return (ret == 0)? 0 : -ENOENT;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) { 

	char* p = (char*)malloc(strlen(path) * sizeof(char));
	strcpy(p,path);
	if(string(p) != "/") strcat(p,"/"); //convert it to full path

	char *find_str;
	vector <string> temp;
	for(int i = 0 ;i < vec.size();i++){
		char n[100] = "/";
		strcat(n,vec[i].tar.name);
		find_str = strstr(n,p);
		if(find_str == NULL) continue;
		if(string(p) == string(n)) continue; //current root
		char *tmp;
		tmp = find_str + strlen(p); //path without current dir
		tmp = strtok(tmp,"/");
		if(strtok(NULL,"/") != NULL) continue; 
		//discard if name is a path

		bool find_same = false;
		for(int j = 0; j < temp.size();j++){
			if(temp[j] == string(tmp)){ //have same file name
				find_same = true;
				break;
			}
		}
		//discard file with same name
		if(!find_same){
			temp.push_back(string(tmp));
		}
		else{
			
		}
	}

	for(int i =0;i<temp.size();i++){
		filler(buffer,temp[i].c_str(),NULL,0);
	}
	return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
	//cout << string(path) << " " << size << " " << offset << endl;
	char* p = (char*)malloc(strlen(path) * sizeof(char));
        strcpy(p,path);
        if(string(p) != "/") strcat(p,"/"); //convert it to full path

        char *find_str;
        vector <string> temp;
	int idx; // the position of the content place
        int ret = -1;
	for(int i = 0 ;i < vec.size();i++){
                char n[100] = "/";
                strcat(n,vec[i].tar.name);
		if(string(n)+"/" == string(p)){
			ret = 0;
			idx = i;
		}
        }

	//find the file
	int s;
        sscanf(vec[idx].tar.size,"%o",&s);
	int smaller;
	if(offset  < s){
		smaller = (offset + size > s)? s-offset : size;
		memcpy(buffer, vec[idx].con + offset, smaller);
	}
	else smaller = 0;
	
	if(ret == -1) ret = -ENOENT;
	else ret = smaller; 
	return ret;
}

static struct fuse_operations op;



int main(int argc, char *argv[])
{
    parsing();
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

