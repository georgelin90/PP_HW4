/*
Student No.: 0616309
Student Name: Xiang-Ren Wang
Email: wangallen880117.cs06@nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be 
posted to a public server, such as a public GitHub repository or a public 
web page.
*/
#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <vector>
#include <map>
#include <sstream>
#include <iostream>
using namespace std;

/* The linkflag defines the type of file */
#define  LF_OLDNORMAL '\0'       /* Normal disk file, Unix compatible */
#define  LF_NORMAL    '0'        /* Normal disk file */
#define  LF_LINK      '1'        /* Link to previously dumped file */
#define  LF_SYMLINK   '2'        /* Symbolic link */
#define  LF_CHR       '3'        /* Character special file */
#define  LF_BLK       '4'        /* Block special file */
#define  LF_DIR       '5'        /* Directory */
#define  LF_FIFO      '6'        /* FIFO special file */
#define  LF_CONTIG    '7'        /* Contiguous file */

/* Self-Define */
#define BLOCK_SIZE (512)

struct TARHeader{
    char file_name[100]; // 0
    char file_mode[8];   // 100
    char user_id[8];     // 108
    char group_id[8];    // 116
    char file_size[12];  // 124
    char modify_time[12];// 136
    char checksum[8];    // 148
    char link_flag[1];   // 156
    char link_name[100]; // 157
    char magic[8];       // 257
    char user_name[32];  // 265
    char group_name[32]; // 297
    char major_device[8];// 329
    char minor_device[8];// 337
    char padding[167];   // 345
};

void tar_header_reset(TARHeader* lhs){
    memset(lhs, 0, sizeof(TARHeader));
}

void tar_header_assign(TARHeader* lhs, char* read_buffer){
    memcpy(lhs->file_name   , read_buffer+  0, 100);
    memcpy(lhs->file_mode   , read_buffer+100,   8);
    memcpy(lhs->user_id     , read_buffer+108,   8);
    memcpy(lhs->group_id    , read_buffer+116,   8);
    memcpy(lhs->file_size   , read_buffer+124,  12);
    memcpy(lhs->modify_time , read_buffer+136,  12);
    memcpy(lhs->checksum    , read_buffer+148,   8);
    memcpy(lhs->link_flag   , read_buffer+156,   1);
    memcpy(lhs->link_name   , read_buffer+157, 100);
    memcpy(lhs->magic       , read_buffer+257,   8);
    memcpy(lhs->user_name   , read_buffer+265,  32);
    memcpy(lhs->group_name  , read_buffer+297,  32);
    memcpy(lhs->major_device, read_buffer+329,   8);
    memcpy(lhs->minor_device, read_buffer+337,   8);
    memcpy(lhs->padding     , read_buffer+345, 167);
}

int get_modify_time(TARHeader* lhs){
    return strtol(lhs->modify_time, 0, 8);
}

string name_w_root(char* name){
    string temp(name);
    temp = "/" + temp;
    return temp;
}
string name_w_root_o_endslash(char* name){
    string temp(name);
    if(temp[temp.length()-1] == '/') temp = temp.substr(0, temp.length()-1);
    temp = "/" + temp;
    return temp;
}

struct BigBlock{
    TARHeader   header;
    //string      content;
    char*       content;
    size_t      limit_size;
};

void content_concate(BigBlock* lhs, char* rhs){
    char *result = (char*)malloc(lhs->limit_size + BLOCK_SIZE + 1); // +1 for the null-terminator
    
    if(lhs->limit_size!=0) memcpy(result, lhs->content, lhs->limit_size);
    memcpy(result + lhs->limit_size, rhs, BLOCK_SIZE + 1); // +1 to copy the null-terminator

    //if(lhs->limit_size!= 0 ) free(lhs->content);
    lhs->limit_size+=BLOCK_SIZE;    
    lhs->content = result;
}

void content_free(BigBlock *lhs){
    //if(lhs->limit_size != 0 ) free(lhs->content);
    lhs->limit_size = 0;
}

struct TableInfo{
    bool is_used;
    unsigned int idx;
    TableInfo(){
        this->is_used = false;
    }
    TableInfo(unsigned int _idx){
        this->is_used = true;
        this->idx = _idx;
    }
};

vector<BigBlock> parse_tar;
vector<BigBlock>::iterator it;
map<string, TableInfo> name_is_used;

bool checksum_check(char *read_buffer){
    char checksum_buffer[8];
    
    int i, sum=0;
    char* header = read_buffer;
    for(i=0; i<148; i++) sum+=header[i];
    for(i=156; i<512; i++) sum+=header[i];
    sum+=32*8;

    memset(checksum_buffer, 0, sizeof(checksum_buffer));
    memcpy(checksum_buffer, read_buffer+148, 8);
    if(sum == strtol(checksum_buffer, 0, 8)) {
        return true;
    }
    else {
        return false;
    }
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi);
int my_getattr(const char *path, struct stat *st);
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi);

static struct fuse_operations op;

int main(int argc, char *argv[]){
// Pre-Parse
    FILE *fp = fopen("test.tar", "r");
    char read_buffer[513];
    unsigned int cur_idx = 0;
    while(true){
        size_t ret = fread(read_buffer, 1, 512, fp);
        if(ret != 512)                       {break;}
        else if(strcmp(read_buffer, "") == 0){break;}

        read_buffer[512] = '\0';

        if(checksum_check(read_buffer) == true){
            BigBlock temp;
            tar_header_assign(&(temp.header), read_buffer);
            if(name_is_used[string(temp.header.file_name)].is_used){
                cur_idx = name_is_used[string(temp.header.file_name)].idx;
                tar_header_assign(&(parse_tar.at(cur_idx).header), read_buffer);
                content_free(&(parse_tar.at(cur_idx)));
            } else {
                parse_tar.push_back(temp);
                name_is_used[string(temp.header.file_name)].is_used = true;
                name_is_used[string(temp.header.file_name)].idx = parse_tar.size()-1;
                cur_idx = parse_tar.size()-1;
            }
        } else {
            content_concate(&(parse_tar.at(cur_idx)), read_buffer);
        }
    }    
    fclose(fp);
// Pre-Parse

    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);

}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
    
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    
    string convert_path(path);
    if(convert_path != "/") convert_path+="/";
    for(it=parse_tar.begin(); it!=parse_tar.end(); it++){
        if(strncmp(convert_path.c_str(), name_w_root(it->header.file_name).c_str(), convert_path.length()) == 0){
            string temp = name_w_root(it->header.file_name).substr(convert_path.length());
            string token="";
            bool is_ok = true;
            for(unsigned int i=0; i<temp.length(); i++){
                if(temp[i] == '/' && i != temp.length()-1){
                    is_ok = false;
                    break;
                } else if(temp[i] == '/' && i == temp.length()-1){
                    is_ok = true;
                    break;   
                } else {
                    token+=temp[i];
                }
            }
            if(is_ok){
                if(token == "") continue; // Path equal to Directory
                filler(buffer, token.c_str(), NULL, 0);
            }
        }
    }
    return 0;
}
int my_getattr(const char *path, struct stat *st){
    memset(st, 0, sizeof(struct stat));

    if(strcmp(path, "/") == 0){
        st->st_mode = S_IFDIR | 0444;
        return 0; // SUCCESS
    }

    for(it=parse_tar.begin(); it!=parse_tar.end(); it++){
        if(strcmp(path, name_w_root_o_endslash(it->header.file_name).c_str()) == 0){
            if(it->header.link_flag[0] == LF_DIR){ // Directory
                st->st_mode = S_IFDIR | strtol(it->header.file_mode, 0, 8);
                st->st_uid  = strtol(it->header.user_id, 0, 8);
                st->st_gid  = strtol(it->header.group_id, 0, 8);
                st->st_mtim.tv_sec  = strtol(it->header.modify_time, 0, 8);
                st->st_size = strtol(it->header.file_size, 0, 8);
                return 0;
            } else { // Regular File
                st->st_mode = S_IFREG | strtol(it->header.file_mode, 0, 8);
                st->st_uid  = strtol(it->header.user_id, 0, 8);
                st->st_gid  = strtol(it->header.group_id, 0, 8);
                st->st_mtim.tv_sec  = strtol(it->header.modify_time, 0, 8);
                st->st_size = strtol(it->header.file_size, 0, 8);
                return 0;
            }
        }
    }

    return -2; // FAIL // -2 means no this file
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    for(it=parse_tar.begin(); it!=parse_tar.end(); it++){
        if(strcmp(path, name_w_root_o_endslash(it->header.file_name).c_str()) == 0){
            if(offset > it->limit_size){
                return 0; // No Byte will be read
            } else if(offset + size > it->limit_size){
                memcpy(buffer, it->content+offset, it->limit_size - offset);
                return it->limit_size - offset;
            } else {
                memcpy(buffer, it->content+offset, size);
                return size;
            }
        }
    }

    return 0; // FAIL
}
