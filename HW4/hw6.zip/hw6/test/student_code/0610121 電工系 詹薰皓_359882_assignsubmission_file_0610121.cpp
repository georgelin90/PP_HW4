/*
student No.: 0610121
Student Name: 詹薰皓
Email: k66281.ee06@nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string.h>

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

const int count[]={99,8,8,8,12,12};
struct data
{
	long long int mtime;
	int val[4];
	string name;
};

int aa=0;
long long int getdata(fstream &fi,string &val,const int &off)
{
	for(int i=0;i<count[off];i++)
		val.push_back(fi.get());
	
	if(!off)
	{
		for(int i=val.size()-1;!val[i];i--)
			val.erase(val.end()-1);
		return 0;
	}
	else if(off==5)
	{
		long long int ans=0,i;
		stringstream str; str << val; str >> i;

		for(int b=1;i;i/=10,b=b<<3)
			if(i%10) ans+=b*(i%10);
		return ans;
	}
	else
	{
		int ans=0,i;
		stringstream str; str << val; str >> i;

		for(int b=1;i;i/=10,b=b<<3)
			if(i%10) ans+=b*(i%10);
		return ans;
	}
}
bool cmp(string &name,const char *path)
{
	int i=1;
	for(;i<strlen(path);i++)
	{
		if(name[i-1]!=path[i])
			return false;
	}
	if(i<name.size())
		return false;
	return true;
}
bool judge(string &name,const char *path)
{
	if(strcmp(path,"/"))
	{
		int j;
		for(j=1;j<strlen(path);j++)
		{
			if(name[j-1]!=path[j])
				return false;
		}
		if(j==name.size())
			return false;
		else if(name[j-1]!='/')
			return false;
		else
			name.erase(name.begin(),name.begin()+j);
	}

	for(int i=0;i<name.size();i++)
	{
		if(name[i]=='/' && i!=name.size()-1)
			return false;
	}
	if(name[name.size()-1]=='/')
		name.erase(name.end()-1);
	return true;
}

int my_getattr(const char *path, struct stat *st) 
{ /*do something*/ 
	fstream test;	test.open("test.tar",ios::in);

/////////////////////////////////////////////////////////////////////

	data temp,last;
	temp.name.push_back(test.get());
	while(temp.name[0])
	{
		int size;  string mt;
		getdata(test,temp.name,0);
		//cout << name << "    " << path << endl;
		
		if(cmp(temp.name,path))
		{
			for(int i=1;i<5;i++,mt.clear())
				temp.val[i-1]=getdata(test,mt,i);
			temp.mtime=getdata(test,mt,5);

			if(last.name.size()==0 || temp.mtime>last.mtime)
			{
				last.name=temp.name;
				last.mtime=temp.mtime;
				for(int i=0;i<4;i++)
					last.val[i]=temp.val[i];
			}
			size=temp.val[3];
		}
		else
		{
			for(int i=0;i<24;i++,test.get());
			mt.clear();	size=getdata(test,mt,4);
			for(int i=0;i<12;i++,test.get());
		}

		size=(size&0x000001ff) ? (size>>9)+1:size>>9;
		size=size<<9;
		for(int i=0;i<size+364;i++,test.get());
		temp.name.clear();
		temp.name.push_back(test.get());
	}
	test.close();

/////////////////////////////////////////////////////////////////////

	if(!strcmp(path,"/"))
		st->st_mode = S_IFDIR | 0444;
	else if(last.name.size())
	{
		if(last.name[last.name.size()-1]=='/')
			st->st_mode = S_IFDIR | last.val[0];
		else
			st->st_mode = S_IFREG | last.val[0];
		st->st_uid=last.val[1];
		st->st_gid=last.val[2];
		st->st_size=last.val[3];
		st->st_mtime=last.mtime;
	}
	else
		return -2;
	return 0;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{ /*do something*/ 
	fstream test;	test.open("test.tar",ios::in);

/////////////////////////////////////////////////////////////////////
	
	vector<data> mem; data temp;
	temp.name.push_back(test.get());
	while(temp.name[0])
	{
		int size;  string mt;

		getdata(test,temp.name,0);
		for(int i=0;i<24;i++,test.get());
		size=getdata(test,mt,4);
		mt.clear(); temp.mtime=getdata(test,mt,5);

		if(judge(temp.name,path))
		{
			for(int i=0;i<mem.size();i++)
			{
				if(temp.name==mem[i].name && temp.mtime>mem[i].mtime)
				{
					mem[i].mtime=temp.mtime;
					temp.mtime=0;
					break;
				}
			}

			if(temp.mtime)
				mem.push_back(temp);
		}

		size=(size&0x000001ff) ? (size>>9)+1:size>>9;
		size=size<<9;
		for(int i=0;i<size+364;i++,test.get());
		temp.name.clear();  temp.mtime=0;
		temp.name.push_back(test.get());
	}
	for(int i=0;i<mem.size();i++)
		filler(buffer,mem[i].name.c_str(),NULL,0);
	
/////////////////////////////////////////////////////////////////////

	test.close();	return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi)
{ /*do something*/ 
	fstream test;	test.open("test.tar",ios::in);

/////////////////////////////////////////////////////////////////////
	
	long long int mtime,last=-1;
	int ptr=0,tar=0,siz=0;
	string name,mt;
	name.push_back(test.get());
	while(name[0])
	{
		getdata(test,name,0);
		for(int i=0;i<24;i++,test.get());
		mt.clear();	int size=getdata(test,mt,4);
		
		if(cmp(name,path))
		{
			mt.clear(); mtime=getdata(test,mt,5);
			
			if(mtime>last)
			{
				tar=ptr; last=mtime; siz=size;
			}
		}
		else
			for(int i=0;i<12;i++,test.get());

		int skip=(size&0x000001ff) ? (size>>9)+1:size>>9;
		skip=skip<<9; ptr=ptr+skip+512;
		for(int i=0;i<skip+364;i++,test.get());
		name.clear();
		name.push_back(test.get());
	}

	test.close(); test.open("test.tar",ios::in);

	for(int i=0;i<tar+512;i++,test.get());
	mt.clear();

//offset & size bound
	for(int i=0;i<offset;i++,test.get());
	for(int i=0;i<siz && i<size;i++)
		mt.push_back(test.get());

	memcpy(buffer,mt.c_str(),mt.size());
	test.close();	return mt.size();

/////////////////////////////////////////////////////////////////////
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

