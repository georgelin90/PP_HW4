/*
Student No.: 0616038
Student Name: 蔡雨恩
Email:vivian31aa@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <bits/stdc++.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <fstream>

#define pb push_back
#define mp make_pair
#define REP(i,n) for(int i=0;i<n;i++)
#define REP1(i,a,b) for(int i=a;i<b;i++)
#define REP2(i,a,b) for(int i=a;i<=b;i++)
#define MEM(x) memset(x,0,sizeof(x));

using namespace std;

struct FFF{
	string name, data;
	long long uid, gid, mode, size, mtime;
	vector< FFF > ch;
};

vector<FFF> v;

char getBack(string s){
	return s[s.size()-1];
}

const char* getCString(string s){
	return s.c_str();
}

string getSimpleName(string s){
	string s2;
	for(int i=0;i<s.size()-1;i++){
		s2.pb(s[i]);
	}
	if( getBack(s) != '/') s2.pb(getBack(s));

	return s2;
}

int samePath(string sa, string sb){
	if(sa == sb || sa + "/" == sb || sa == sb + "/") return 1;
	return 0;
}

string getFather(string sa){
	int keyPt;
	for(int i = sa.size()-2;i>=0;i--){
		if(sa[i] == '/'){
			keyPt = i;
			break;
		}
	}
	string ans;
	REP(i,keyPt+1){
		ans.pb(sa[i]);
	}
	return ans;
}

char buf[5000000];

void getBuf(string &s, int &ptr, int len, int readAll = 0){
	s.clear();
	for(int i=ptr;i<ptr+len;i++){
		if(readAll == 0 && buf[i] == 0) break;
		s.pb(buf[i]);
	}
	ptr += len;
	return;
}

void getBufN(long long &n, int &ptr, int len){
	n = 0;
	for(int i=ptr;i<ptr + len;i++){
		if(buf[i] >= '0' && buf[i] <= '9'){
			n = n*8+(buf[i] - '0');
		}
	}
	ptr += len;
	return;
}

void readTar(){
	ifstream infile("./test.tar");

	infile.seekg(0, ios::end);
	size_t n = infile.tellg();
	infile.seekg(0, ios::beg);

	infile.read(buf, n);

	// for(int i=0;i<n;i++){
	// 	cout<<buf[i];
	// }
	// cout<<endl;
	cout<<"n = "<<n<<endl;
	FFF ff;
	ff.mode = 0444;
	ff.size = 0;
	ff.name = "/";
	ff.data = "";
	ff.uid = getuid();
	ff.gid = getgid();
	v.pb(ff);
	for(int ptr=0;ptr<n;){
		FFF f;

		getBuf(f.name, ptr, 100);
		if(f.name == "") break;
		f.name = "/" + f.name;
		getBufN(f.mode, ptr, 8);
		getBufN(f.uid, ptr, 8);
		getBufN(f.gid, ptr, 8);
		getBufN(f.size, ptr, 12);
		// cout<<"size "<<f.size<<endl;
		getBufN(f.mtime, ptr, 12);
		ptr += 9 + 108 + 64 + 16 + 167;
		getBuf(f.data, ptr, f.size,1);
		cout<<"check "<<ptr<<endl;
		cout<<f.name<<':'<<f.mode<<' '<<f.uid<<' '<<f.gid<<endl;
		cout<<f.size<<' '<<f.mtime<<endl<<endl<<endl;
		// cout<<f.data<<endl;	

		if(ptr%512){
			ptr = ptr + 512 - (ptr%512);
		}
		cout<<"check2 "<<ptr<<endl;

		v.pb(f);

		string fa = getFather(f.name);
		cout<<"fa of "<<f.name<<" = "<<fa<<endl;

		for(int i=0;i<v.size();i++){
			if( samePath(fa, v[i].name) ){
				cout<<"pushFaCh "<<v[i].name<<' '<<f.name<<endl;
				v[i].ch.pb(f);
			}
		}

	}
}

string getSon(string s){
	int keyPt;
	for(int i=s.size()-2;i>=0;i--){
		if(s[i] == '/') {
			keyPt=  i;
			break;
		}
	}
	string ans;
	for(int i=keyPt+1;i<s.size();i++){
		ans.pb(s[i]);
	}
	return ans;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct
fuse_file_info *fi) { 

	cout<<"readdir "<<path<<endl;
	filler( buffer, ".", NULL, 0 ); 
	filler( buffer, "..", NULL, 0 );
	

	for(int i=0;i<v.size();i++){
		// cout<<"cmp "<<v[i].name<<' '<<path<<endl;
		if(samePath(v[i].name, string(path))){
			// cout<<"ac"<<endl;
			for(int j=0;j<v[i].ch.size();j++){
				// cout<<"children "<<v[i].ch[j].name<<' '<<getSimpleName(v[i].ch[j].name)<<' '<<endl;
				string sss = getSon(v[i].ch[j].name);

				if(getBack(sss) == '/') sss.resize(sss.size()-1);
				cout<<"fill "<<sss.c_str()<<endl;
				filler(buffer,  sss.c_str(), NULL, 0);
			}
			return 0;
		}
	}
	return 0;
}

int my_getattr(const char *path, struct stat *st) { 
	string pathS = string(path);

	cout<<"getattr "<<path<<endl;
	// if(pathS == "/"){
	// 	st->st_mtime = time( NULL );
	// 	st->st_atime = time( NULL );
	// 	st->st_uid = getuid();
	// 	st->st_gid = getgid();
	// 	st->st_mode = S_IFDIR | 0444;
	// 	st->st_size = 0;
	// 	return 0;
	// }
	// else{
	for(int i=0;i<v.size();i++){
		if(samePath(v[i].name,string(path))){
			cout<<"found "<<v[i].name<<endl;
			st->st_mtime = v[i].mtime;
			st->st_atime = time( NULL );
			st->st_uid = v[i].uid;
			st->st_gid = v[i].gid;
			st->st_size = v[i].size;
			if(getBack(v[i].name) == '/'){
				st->st_mode = S_IFDIR | v[i].mode;
			}
			else{
				st->st_mode = S_IFREG | v[i].mode;
			}
			return 0;
		}
	}	
	return -ENOENT;
	// }
}


int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info
*fi) {
	cout<<"myread "<<path<<endl;
	for(int i=0;i<v.size();i++){
		if(samePath(v[i].name, string(path)) ){
			cout<<"found "<<v[i].name<<endl;
			memcpy(buffer, v[i].data.c_str() + offset, size);
			return size;
		}
	}
	return 0;
}

static struct fuse_operations op;
int main(int argc, char *argv[]){
	readTar();
	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	return fuse_main(argc, argv, &op, NULL);
}