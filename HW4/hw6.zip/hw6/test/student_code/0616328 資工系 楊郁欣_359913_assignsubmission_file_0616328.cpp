/*
Student No.: 0616328
Student Name: Yang Yu-Hsin 
Email: cindy02017@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repositor_filey or a public web page.
*/
#define FUSE_USE_VERSION 30

#include <iostream>
#include <fstream>
#include <fuse.h>
#include <string.h>
#include <unistd.h>     //getuid(), getgid()
#include <sys/stat.h> // for my_getattr 裡的 stat *st
#include <errno.h>
#include <stdio.h> //fopen fread
#include <string.h>
#include <algorithm>
#include <vector>
//#include <map>
#define PSS pair<string, string>
#define ll long long
#define MAXN 1000000
using namespace std;

char buff[MAXN];
static struct fuse_operations op;



struct tarFile
{
    string name; //name = parent_dir + fname
    string parent_dir, fname;
    //int dirOrfile;   //可以直接看fname的最後一位來判斷
    ll mode, uid, gid, size, time;
    string data;
};

vector<tarFile> file_vector;
vector<tarFile>::iterator itor_file;

//map<string, tarFile> file_map;

/*
typedef int (*fuse_fill_dir_t) (void *buf, const char *name, const struct stat *stbuf, off_t off);
*/

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{

    string path_tmp = string(path);
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    for (itor_file = file_vector.begin(); itor_file != file_vector.end(); itor_file++)
    {
        if (itor_file->parent_dir == path_tmp || itor_file->parent_dir == path_tmp + "/")
        {
            string file_name = itor_file->fname;
            int len_tmp = file_name.length();
            if (file_name[len_tmp - 1] == '/')
            {
                //後面還有"/"但filler不能吃到“/”
                //這個c++版 不能用pop_back() = =
                file_name.resize(len_tmp - 1);
            }
            filler(buffer, file_name.c_str(), NULL, 0);
        }
    }

    return 0;
}

int my_getattr(const char *path, struct stat *st)
{

    string path_tmp = string(path);

    if (path_tmp == "/")
    {
        st->st_mtime = time(NULL);
        st->st_uid = getuid();
        st->st_gid = getgid();
        st->st_mode = S_IFDIR | 0444;
        st->st_nlink = 2;
        st->st_size = 0;
        return 0;
    }
    else
    {
        for (itor_file = file_vector.begin(); itor_file != file_vector.end(); itor_file++)
        {

            if (itor_file->name == path_tmp || itor_file->name == (path_tmp + "/"))
            {
                st->st_uid = itor_file->uid;
                st->st_gid = itor_file->gid;
                st->st_mtime = itor_file->time;

                
                //dir
                if (itor_file->name[itor_file->name.length() - 1] == '/')
                {
                    st->st_mode = S_IFDIR | itor_file->mode;
                    st->st_nlink = 2;
                }
                //regular file
                else
                {
                    st->st_mode = S_IFREG | itor_file->mode;
                    st->st_nlink = 1;
                }
                st->st_size = itor_file->size;

                return 0;
            }
        }
        // not found
        return -ENOENT;
    }
}

//return the number of bytes that have been read successfully
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi)
{
    string path_tmp = string(path);
    string data;
    for (itor_file = file_vector.begin(); itor_file != file_vector.end(); itor_file++)
    {
        if (itor_file->name == path_tmp || itor_file->name == (path_tmp + "/"))
        {
            data = itor_file->data;
            memcpy(buffer, data.c_str() + offset, size);
            return size;
        }
    }
    return 0;
}

ll OcttoDec(string str)
{
    //八進位轉十進位
    ll num = 0, base = 1;
    int len = str.length();

    for (int i = len - 1; i >= 0; i--)
    {
        //printf("oct to decimal %d\n", int(str[i]));
        if (str[i] >= '0' && str[i] <= '9')
        {
            num += base * (str[i] - '0');
            base *= 8;
        }
    }

    return num;
}

string OutofBuff(int &count, int len)
{
    int pos = 0;
    string tmp;
    tmp.clear();
    for (int i = 0; i < len; i++)
    {
        pos = i;
        if (buff[count + i] == '\0')
        {
            break; //'\0' terminated
        }
    }

    for (int i = 0; i <= pos; i++)
    {
        tmp += buff[count + i];
    }

    count += len;

    return tmp;
}

string AllOutofBuff(int &count, int len)
{
    //整個檔案裡的
    string tmp;
    tmp.clear();
    for (int i = 0; i < len; i++)
    {
        //不管有沒有terminate 都全部拿出來
        tmp += buff[count + i];
    }
    count += len;
    return tmp;
}

PSS CutDirFname(string name)
{
    string dir, fname; //放最後切好的
    dir.clear();
    fname.clear();

    string tmp;
    tmp = name;
    reverse(tmp.begin(), tmp.end());

    //把name裡的dir和filename分開
    int len = name.length();
    if (name.rfind("/") == len - 2) //dir
    {
        //cout << "hhohoohoh ";
        int pos = tmp.find("/", 2);
        //cout << "pos = " << pos << "len = " << len;
        pos = len - pos; //在str裡的位置
        for (int i = 0; i < pos; i++)
        {
            dir += name[i];
        }
        for (int i = pos; i < len; i++)
        {
            fname += name[i];
        }
    }
    else //file
    {
        int pos = tmp.find("/", 0);
        pos = len - pos; //在str裡的位置
        for (int i = 0; i < pos; i++)
        {
            dir += name[i];
        }
        for (int i = pos; i < len; i++)
        {
            fname += name[i];
        }
    }

    tmp.clear();
    return PSS(dir, fname);
}

void TokenizeTarfile()
{
    //readfile

    FILE *tFile = fopen("./test.tar", "r");
    fseek(tFile, 0, SEEK_END);
    size_t file_len = ftell(tFile);
    fseek(tFile, 0, SEEK_SET);

    //cout << "len = " << file_len;
    //先全部讀進buff 再一次一次拿出來
    fread(&buff, sizeof(char), file_len, tFile);
    /*
    for(int i = 0; i < 50; i++){
        cout << "buff " << buff[i] << " " ;
    }
    */

    int count = 0;
    while (count < file_len)
    {
        tarFile entry;
        //沒有名字 -> root
        string tmp = OutofBuff(count, 100);
        //cout << "tmp = " << tmp << endl;

        entry.name = "/" + tmp;
        if (entry.name == "/")
            break;
        PSS attr = CutDirFname(entry.name);
        entry.parent_dir = attr.first;
        entry.fname = attr.second;
        //cout << "haha" << endl;
        cout << entry.name << endl;
        cout << entry.parent_dir << " " << entry.fname << endl;

        entry.mode = OcttoDec(OutofBuff(count, 8));
        entry.uid = OcttoDec(OutofBuff(count, 8));
        entry.gid = OcttoDec(OutofBuff(count, 8));
        entry.size = OcttoDec(OutofBuff(count, 12));
        entry.time = OcttoDec(OutofBuff(count, 12));
        //count = 136
        //以下無關緊要

        count += 8;   //header checksum
        count += 1;   //link flag
        count += 100; //Link name
        count += 8;   //Magic??
        count += 32;  //User name
        count += 32;  //Group name
        count += 8;   //Major device ID
        count += 8;   //Minor device ID
        count += 167; //Padding

        //cout << "hahha " << count << endl;
        //count = 512
        entry.data = AllOutofBuff(count, entry.size);

        if (count % 512 != 0)
            count += 512 - (count % 512);

        file_vector.push_back(entry);
        /*
        if (file_map.find(entry.name) != file_map.end())
        {
            
            file_map[entry.name] = entry;
        }
        */
    }
}

int main(int argc, char *argv[])
{
    TokenizeTarfile();
    memset(&op, 0, sizeof(op));
    op.readdir = my_readdir;
    op.getattr = my_getattr;
    op.read = my_read;

    return fuse_main(argc, argv, &op, NULL);
    return 0;
}
