/*
Student No.:0616093
Student Name: Po Hsien Wu
Email:clive.cs06@nctu.edu.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that thi program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30
#define _FILE_OFFSET_BITS 64

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <iostream>
#include <map>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef struct tarfile {
  string fname, data;
  ll gid, uid, sz, md, timecnt;
} tf;

char buffer[100000];

map<string, tf> timemap;
map<string, tf>::iterator itt;

void cut( string s, string &x, string &y ) {
  x.clear();
  y.clear();
  y.push_back(s[s.size()-1]);
  int cnt;
  for ( cnt = s.size()-2; cnt >= 0; cnt-- ) {
    if ( s[cnt] == '/' ) break;
    y.push_back(s[cnt]);
  }
  for ( ; cnt >= 0; cnt-- ) 
    x.push_back(s[cnt]);

  
  for ( int i = 0; i < x.size()/2; i++ )
    swap(x[i], x[x.size()-1-i]);
  
  for ( int i = 0; i < y.size()/2; i++ )
    swap(y[i], y[y.size()-1-i]);
  
 
  return;

}

bool equil ( string s, string t ) {
  return (( s == t ) || (s == t+"/"));
}
int my_getattr(const char *path, struct stat *st) {
  string ref = string(path);

  if ( ref == "/") { //root dir
    st->st_mtime = time(NULL);
		st->st_uid = getuid();
		st->st_gid = getgid();
		st->st_mode = S_IFDIR | 0444;
		st->st_size = 0;

		return 0;
  }
  else {
    for ( itt = timemap.begin(); itt != timemap.end(); itt++ ) {
      if ( equil(itt->second.fname, ref)) {
        st->st_mtime = itt->second.timecnt;
				st->st_uid = itt->second.uid;
				st->st_gid = itt->second.gid;

				int sfmd;
				if( itt->second.fname[itt->second.fname.size()-1] == '/' )
					sfmd = S_IFDIR;
				else
					sfmd = S_IFREG;
				
				st->st_mode = sfmd | itt->second.md;
				st->st_size = itt->second.sz;
				return 0;
      }
    }

    return -ENOENT;
  }
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) { 
  filler(buffer, ".", NULL, 0);
  filler(buffer, "..", NULL, 0);

  string ref = string(path);
  for ( itt = timemap.begin(); itt != timemap.end(); itt++ ) {

    string parent, pwd;

    cut(itt->second.fname, parent, pwd );

    if ( equil(parent, ref)) {
      if ( pwd[pwd.size()-1] == '/' ) pwd.resize(pwd.size()-1); 
      filler(buffer, pwd.c_str(), NULL, 0);
    }
  }
  return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
  string ref = string(path);

  for ( itt = timemap.begin(); itt != timemap.end(); itt++) {
    if ( equil(itt->second.fname, ref)) {
      memcpy(buffer, itt->second.data.c_str()+offset, size);
      return size;
    }
  }

  return 0;
}

ll convert ( string s ) {
  ll x = 0, tmp = 1;

	for ( int i = s.size()-1; i >= 0; i-- ) {
		if ( s[i] >= '0' && s[i] <= '9' ) {
			x += tmp * (s[i] - '0');
			tmp *= 8;
		}
	}

	return x;
}

string scan ( int it, int byte ) {
  string s;

  for ( int i = it; i < it + byte; i++ ) {
    if ( !buffer[i] ) break;
    s += buffer[i];
  }

  return s;
}

string sscan ( int it, int byte ) {
  string s;

  for ( int i = it; i < it + byte; i++ ) 
    s += buffer[i];

  return s;
}

void readtar () {
  ifstream input;
  input.open("test.tar");

  input.seekg(0, ios::end);
	size_t len = input.tellg();
	input.seekg(0, ios::beg);

  input.read(buffer, len);

  size_t it;
  while ( it < len ) {
    tf tmp;

    tmp.fname = "/" + scan(it, 100);
    
    if ( tmp.fname == "/" ) break;
    it += 100;

    tmp.md = convert(scan(it, 8));
    it += 8;
 
    tmp.uid = convert(scan(it, 8));
    it += 8;

    tmp.gid = convert(scan(it, 8));
    it += 8;

    tmp.sz = convert(scan(it, 12));
    it += 12;

    tmp.timecnt = convert(scan(it, 12));
    it += 376;

    tmp.data = sscan(it, tmp.sz);

    it += tmp.sz;

    int r = it % 512;
    if ( r ) 
      it += 512 - r;

    if ( (timemap.find(tmp.fname) == timemap.end()) || (tmp.timecnt > timemap[tmp.fname].timecnt))
      timemap[tmp.fname] = tmp;

  }
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{   
    readtar();
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
