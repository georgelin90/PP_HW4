/*
 * Student No.: 0616014
 * Student Name: Zheng-Dao Yang
 * Email: s1357andy871207@gmail.com
 * SE tag: xnxcxtxuxoxsx
 * Statement: 
 * I am fully aware that this program is not 
 * supposed to be posted to a public server, such
 * as a public GitHub repository or a public web page.
 */
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <bits/stdc++.h>
#define  LF_OLDNORMAL '\0'       /* Normal disk file, Unix compatible */
#define  LF_NORMAL    '0'        /* Normal disk file */
#define  LF_LINK      '1'        /* Link to previously dumped file */
#define  LF_SYMLINK   '2'        /* Symbolic link */
#define  LF_CHR       '3'        /* Character special file */
#define  LF_BLK       '4'        /* Block special file */
#define  LF_DIR       '5'        /* Directory */
#define  LF_FIFO      '6'        /* FIFO special file */
#define  LF_CONTIG    '7'        /* Contiguous file */
#define load_str(dist, len) \
    in.read(buf, len);      \
    dist = string(buf);

#define load_oct(dist, len) \
    in.read(buf, len);      \
    ss.clear(); ss.str(""); \
    ss << string(buf);      \
    ss >> oct >> dist
using namespace std;

struct Object {
    string          name;
    unsigned int    mode;
    unsigned int    uid;
    unsigned int    gid;
    unsigned int    size;
    unsigned int    mtime;
    unsigned int    checksum;
    char            flag;
    string          trash;
    char*           content;
    Object() { }
    Object(const Object &rhs) {
        content = new char[strlen(rhs.content) + 1];
        memcpy(content, rhs.content, strlen(rhs.content));
        content[strlen(rhs.content) + 1] = '\0';
    }
    ~Object() {
        free(content);
    }
};
char buf[1 << 20];

Object read_obj(ifstream &in) {
    Object obj;
    stringstream ss;
    load_str(obj.name, 100);
    load_oct(obj.mode, 8);
    load_oct(obj.uid, 8);
    load_oct(obj.gid, 8);
    load_oct(obj.size, 12);
    load_oct(obj.mtime, 12);
    load_oct(obj.checksum, 8);
    load_oct(obj.flag, 1);
    load_str(obj.trash, 355);
    int total_byte = (obj.size + 511) & ~511;
    obj.content = new char[total_byte + 1];
    in.read(obj.content, total_byte);
    obj.content[total_byte] = '\0';
    obj.name = "/" + obj.name;
    if (obj.flag == LF_DIR) {
        obj.name.pop_back();
        obj.mode |= S_IFDIR;
    } else 
        obj.mode |= S_IFREG;
    return obj;
}

int my_getattr(const char *_path, struct stat *st) {
    string path = string(_path);
    if (path == "/") {
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    ifstream in("test.tar", ifstream::binary);
    bool find = false;
    while (!in.eof()) {
        Object obj = read_obj(in);
        if (obj.name != path) 
            continue;
        if (!find) {
            find = true;
            st->st_mode = obj.mode;
            st->st_uid = obj.uid;
            st->st_gid = obj.gid;
            st->st_mtime = obj.mtime;
            st->st_size = obj.size;
        } else if (st->st_mtime < obj.mtime) {
            st->st_mode = obj.mode;
            st->st_uid = obj.uid;
            st->st_gid = obj.gid;
            st->st_mtime = obj.mtime;
            st->st_size = obj.size;
        }
    }
    if (!find)
        return -ENOENT;
    return 0;
}
int my_readdir(const char *_path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    string path = string(_path);
    if (path == "/") 
        path = "";
    ifstream in("test.tar", ifstream::binary);
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    set<string> pool;
    while (!in.eof()) {
        Object obj = read_obj(in);
        if (path.size() + 1 >= obj.name.size())
            continue;
        if (path != obj.name.substr(0, path.size()))
            continue;
        if (obj.name[path.size()] != '/')
            continue;
        if (obj.name.substr(path.size() + 1).find('/') != string::npos)
            continue;
        pool.insert(obj.name.substr(path.size() + 1));
    }
    for (auto &str : pool)
        filler(buffer, str.c_str(), NULL, 0);
    return 0;
}
int my_read(const char *_path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
    string path = string(_path);
    ifstream in("test.tar", ifstream::binary);
    int mtime = 0; char content[1 << 20];
    while (!in.eof()) {
        Object obj = read_obj(in);
        if (obj.name != path)
            continue;
        if (mtime < obj.mtime) {
            mtime = obj.mtime;
            int total_byte = (obj.size + 511) & ~511;
            memcpy(content, obj.content, total_byte);
            content[total_byte] = '\0';
        }
    }
    if (!mtime)
        return -ENOENT;
    memcpy(buffer, content + offset, size);
    buffer[size] = '\0';
    return size;
}

static struct fuse_operations op;
int main(int argc, char *argv[]) {
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
