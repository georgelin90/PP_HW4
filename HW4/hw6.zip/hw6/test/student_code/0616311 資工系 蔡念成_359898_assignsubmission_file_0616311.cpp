#define FUSE_USE_VERSION 30
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <fuse.h>
#include <cstring>
#include <sstream>
#include <cmath>
#include <vector>
using namespace std;

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi);
int my_getattr(const char *path, struct stat *st);
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi);
static struct fuse_operations op;
int oct2dec(string s);
string entire;

int main(int argc, char *argv[])
{
	char c;
	ifstream TarFile;
	TarFile.open("test.tar");
	while (TarFile.get(c))
		entire += c;
	
	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	TarFile.close();
	
	return fuse_main(argc,argv,&op,NULL);
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
	string name, s, base, full, remain;
	vector<string> list;
	int start_byte = 0, size, chunk, contentSize, is_folder = 0, i;
	base = (strcmp(path,"/")==0)? "":path;
	
	struct stat tarstatus;
	stat("test.tar", &tarstatus );
	filler(buffer, "..", NULL, 0);
	filler(buffer, ".", NULL, 0);
	
	while (start_byte+512*2 < tarstatus.st_size)
	{
		full.clear(); remain.clear(); name.clear(); s.clear();
		for (i = 0;i < 100 && entire[start_byte+i] != '\0';i++)
			full += entire[start_byte+i];
		full = "/"+full;
		for (int j = 0;j < list.size();j++)
			if (list[j] == full)
				goto next;
		for (i = 0;i < base.length();i++)
			if (base[i] != full[i])
				goto next;
		if (i == full.length() || (i == full.length()-1 && full[i] == '/'))
			goto next;
		for (;i < full.length();i++)
			remain += full[i];
		if (remain[0] != '/')
			goto next;
		for (i = 0;i < remain.length();i++)
			if (i != 0 && remain[i] == '/')
				break;
			else
				name += remain[i];
		
		for (int j = 1;j < name.length();j++)
			s += name[j];
		if (i == remain.length())
			filler(buffer, s.c_str(), NULL, 0);
		else if (i == remain.length()-1 && remain[i] == '/')
			filler(buffer, s.c_str(), NULL, 0);
		list.push_back(full);
		
		next:
		s.clear();
		for (int j = 0;j < 12;j++)
			s += entire[start_byte+124+j];
		size = oct2dec(s);
		
		start_byte += (full[full.length()-1] == '/')? 512:512+(ceil(size/512.0))*512;
	}
	
	return 0;
}

int my_getattr(const char *path, struct stat *st)
{
	memset(st, 0, sizeof(struct stat));
	if (strcmp(path,"/") == 0)
	{
		st->st_mode = S_IFDIR | 0444;
		return 0;
	}
	
	string path_s(path), p;
	for (int i = 1;i < path_s.length();i++)
		p += path_s[i];
	
	string name, s, base, full, remain;
	int size, chunk, contentSize, is_folder = 0, i;
	long NewestTime = 0, NewestByte = -1;
	long start_byte = 0, mode;
	struct stat tarstatus;
	stat("test.tar", &tarstatus );
	
	while (start_byte+512*2 < tarstatus.st_size)
	{
		name.clear();
		for (i = 0;i < 100 && entire[start_byte+i] != '\0';i++)
			name += entire[start_byte+i];
		if (name == p || name == p+"/")
		{
			s.clear();
			for (int i = 0;i < 12;i++)
				s += entire[start_byte+136+i];
			long Time = oct2dec(s);
			if (Time > NewestTime)
			{
				NewestTime = Time;
				NewestByte = start_byte;
			}
		}
		s.clear();
		for (int j = 0;j < 12;j++)
			s += entire[start_byte+124+j];
		size = oct2dec(s);
		start_byte += (name[name.length()-1] == '/')? 512:512+(ceil(size/512.0))*512;
	}
	
	if (NewestByte == -1)
		return -2;
	else
	{
		start_byte = NewestByte;
		
		name.clear();
		for (i = 0;i < 100 && entire[start_byte+i] != '\0';i++)
			name += entire[start_byte+i];
		s.clear();
		for (int i = 0;i < 8;i++)
			s += entire[start_byte+100+i];
		mode = oct2dec(s);
		if (name == p+"/")
			st->st_mode = S_IFDIR | mode;
		else
			st->st_mode = S_IFREG | mode;
		s.clear();
		for (int i = 0;i < 8;i++)
			s += entire[start_byte+108+i];
		st->st_uid = oct2dec(s);
		s.clear();
		for (int i = 0;i < 8;i++)
			s += entire[start_byte+116+i];
		st->st_gid = oct2dec(s);
		s.clear();
		for (int i = 0;i < 12;i++)
			s += entire[start_byte+124+i];
		st->st_size = oct2dec(s);
		s.clear();
		for (int i = 0;i < 12;i++)
			s += entire[start_byte+136+i];
		st->st_mtime = oct2dec(s);
		return 0;		
	}
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi)
{
	string name, s;
	int sizeI;
	long start_byte = 0, NewestByte = -1, NewestTime = 0;
	
	struct stat tarstatus;
	stat("test.tar", &tarstatus );
	
	while (start_byte+512*2 < tarstatus.st_size)
	{
		name = "/";
		for (int i = 0;i < 100 && entire[start_byte+i] != '\0';i++)
			name += entire[start_byte+i];
		if (name == path && name[name.length()-1] != '/')
		{
			s.clear();
			for (int i = 0;i < 12;i++)
				s += entire[start_byte+136+i];
			long Time = oct2dec(s);
			if (Time > NewestTime)
			{
				NewestTime = Time;
				NewestByte = start_byte;
			}
		}
		
		s.clear();
		for (int j = 0;j < 12;j++)
			s += entire[start_byte+124+j];
		sizeI = oct2dec(s);
		start_byte += (name[name.length()-1] == '/')? 512:512+(ceil(sizeI/512.0))*512;
	}
	
	if (NewestByte == -1)
		return 0;
	else
	{
		start_byte = NewestByte;
		s.clear();
		for (int j = 0;j < 12;j++)
			s += entire[start_byte+124+j];
		sizeI = oct2dec(s);
		if (offset < sizeI)
		{
			if (offset + size > sizeI)
				size = sizeI - offset;
			memcpy(buffer, entire.c_str()+start_byte+512+offset, size);
		}
		else
			size = 0;
		return size;
	}
}

int oct2dec(string s)
{
    stringstream ss;
	string p;
	for (int i = 0;i < s.length();i++)
		if (s[i] != '\0')
			p += s[i];
    int o;
    ss << p;
    ss >> oct >> o;
	return o;
}
