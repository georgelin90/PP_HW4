/*
Student No.: 0616005
Student Name: 洪瑋均
Email: hungwei123.cs06@g2.nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

int octal_string_to_int(char *cur_char, unsigned int size){
    unsigned int output = 0;
    while(size > 0){
        if(*cur_char - '0' > 9 || *cur_char - '0' < 0) break;
        output = output*8 + *cur_char - '0';
        cur_char++;
        size--;
    }
    return output;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
    FILE* fp;
    fp = fopen("test.tar", "rb");
    char buf[51200];
    fread(buf, 51200, 1, fp);
    int locat = 0;
    int indir = 0;
    char *filepath;
    while(buf[locat]){
        int i, pathid = 0;
        for(i = 0; i < 100; i++){
            if(buf[locat + i] == '\0') break;
            if(buf[locat + i] == '/' && buf[locat + i + 1] == '\0'){
                indir = 1;
            }
            if(buf[locat + i] == '/' && buf[locat + i + 1] != '\0'){
                pathid = i + 1;
            }
        }
	    char *name;
        name = strndup(&buf[locat + pathid], i + 1 - pathid);
        if(strcmp(path, "/") == 0 && pathid == 0){
            if(indir == 0){
                filler(buffer, name, NULL, 0);
            }
            else if(indir == 1){
                name[i-1] = '\0';
                filler(buffer, name, NULL, 0);
            }
        }
        else if(pathid != 0){
            filepath = strndup(&buf[locat], pathid - 1);
            if(indir == 1){
                name[strlen(name)-1] = '\0';
            }
            if(strcmp(path+1, filepath) == 0){
                filler(buffer, name, NULL, 0);
            }
        }
        indir = 0;
        int sz_of_file = octal_string_to_int(&buf[locat + 124], 11);
        int block = (sz_of_file + 511)/512 + 1;
        locat += block * 512;
    }
    return 0;
}

int my_getattr(const char *path, struct stat *st){
    memset(st, 0, sizeof(struct stat));
    FILE* fp;
    fp = fopen("test.tar", "rb");
    char buf[51200];
    fread(buf, 51200, 1, fp);
    int locat = 0;
	char name[100];
    memset(name, 0, 100);
    int indir = 0;
    if(strcmp(path, "/") == 0){
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    while(buf[locat]){
        int i;
        for(i = 0; i < 100; i++){
            if(buf[locat + i] == '/' && buf[locat + i + 1] == '\0'){
                indir = 2;
            }
            name[i] = buf[locat + i];
            if(buf[locat + i] == '\0') break;
        }
        int sz_of_file = octal_string_to_int(&buf[locat + 124], 11);
        int block = (sz_of_file + 511)/512 + 1;
        if(indir == 2){
            name[i-1] = '\0';
        }
        if(strcmp(path+1, name) == 0){
            st->st_uid = octal_string_to_int(&buf[locat + 108], 7);
            int uid = octal_string_to_int(&buf[locat + 108], 7);
            st->st_gid = octal_string_to_int(&buf[locat + 116], 7);
            st->st_mtime = octal_string_to_int(&buf[locat + 136], 11); 
            st->st_size = sz_of_file;
            if(buf[locat+156] == '5')
                st->st_mode = S_IFDIR | octal_string_to_int(&buf[locat + 100], 7);
            else
                st->st_mode = S_IFREG | octal_string_to_int(&buf[locat + 100], 7);
            return 0;
        }
        indir = 0;
        memset(name, 0, 100);
        locat += block * 512;
    }
    return -ENOENT;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    FILE* fp;
    fp = fopen("test.tar", "rb");
    char buf[51200];
    fread(buf, 51200, 1, fp);
    int locat = 0;
	char name[100];
    memset(name, 0, 100);
    while(buf[locat]){
        for(int i = 0; i < 100; i++){
            name[i] = buf[locat + i];
            if(buf[locat + i] == '\0') break;
        }
        int sz_of_file = octal_string_to_int(&buf[locat + 124], 11);
        int block = (sz_of_file + 511)/512 + 1;
        if(strcmp(path+1, name) == 0){
            if(offset < sz_of_file){
                if(offset + size > sz_of_file)
                    size = sz_of_file - offset;
                    memcpy(buffer, &buf[locat+512+offset], size);
            }
            else
                size = 0;
            return size;
        }
        memset(name, 0, 100);
        locat += block * 512;
    }
    return 0;
}

static struct fuse_operations op;

int main(int argc, char *argv[]){
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
