/*
Student No.: 0616022
Student Name: 張軒瑞
Email:raymond880215@gmail.com 
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <string.h>
#include <string>
#include <map>
#include <vector>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

struct fileS{
	string name, data;
	long long uid, gid, mode, size;
	long long mtime;
};

map<string, fileS> fs;

char buf[5000000];


void split(string s,string &sa, string &sb){
	sa.clear();
	sb.clear();
	sb.push_back(s[s.length()-1]);
	int i ;
	for(i=s.length()-2;i>=0;i--){
		if( s[i] == '/' ) break;
		sb.push_back(s[i]);
	}
	for(;i>=0;i--){
		sa.push_back(s[i]);
	}
	for(int i=0;i<sa.length()/2;i++){
		swap(sa[i],sa[sa.length()-1-i]);
	}
	for(int i=0;i<sb.length()/2;i++){
		swap(sb[i],sb[sb.length()-1-i]);
	}
	return ;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct
fuse_file_info *fi) { 
	string pathS = string(path);
	filler( buffer, ".", NULL, 0 ); 
	filler( buffer, "..", NULL, 0 );
	map<string, fileS> :: iterator it;
	for( it = fs.begin(); it != fs.end() ; it++ ){
		string father, son;
		split( it->second.name, father, son);
		// cout<<it->second.name<<" split -> "<<father<<' '<<son<<endl;

		if( father == pathS || father == pathS + "/" ){
			if( son[son.length()-1] == '/' ) son.resize(son.length()-1);
			filler(buffer, son.c_str(), NULL, 0);
		}
	}
	return 0;
}


int my_getattr(const char *path, struct stat *st) { 
	string pathS = string(path);

	if(pathS == "/"){
		st->st_mtime = time( NULL );
		st->st_uid = getuid();
		st->st_gid = getgid();
		st->st_mode = S_IFDIR | 0444;
		st->st_size = 0;
		return 0;
	}
	else{
		map<string,fileS> :: iterator it;
		for( it = fs.begin(); it != fs.end() ; it++ ){
			if(it->second.name == pathS || it->second.name == (pathS + "/")){
				st->st_mtime = it->second.mtime;
				st->st_uid = it->second.uid;
				st->st_gid = it->second.gid;
				int sif;
				if( it->second.name[it->second.name.length()-1] == '/' ){
					sif = S_IFDIR;
				}
				else{
					sif = S_IFREG;
				}
				st->st_mode = sif | it->second.mode;
				st->st_size = it->second.size;
				return 0;
			}	
		}

		// not found
		return -ENOENT;
	}
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info
*fi) {
	string pathS = string(path);
	map<string, fileS> :: iterator it;
	for( it = fs.begin(); it != fs.end() ; it++ ){
		if(it->second.name == pathS || it->second.name == (pathS + "/")){
			memcpy(buffer, it->second.data.c_str() + offset, size);
			return size;
		}
	}
	return 0;
}

string getData(int &cnt, int len){
	string s;
	s.clear();
	for(int i=0;i<len;i++){
		if(buf[cnt+i] == 0) break;
		s.push_back(buf[cnt + i]);
	}
	cnt+=len;
	return s;
}

string getAllData(int &cnt, int len){
	string s;
	s.clear();
	// cout<<"gad "<<cnt<<' '<<len<<endl;
	for(int i=0;i<len;i++){
		s.push_back(buf[cnt + i]);
	}
	cnt+=len;
	// cout<<"gad2 "<<cnt<<endl;
	return s;
}

long long eight10(string s){
	long long x = 0;
	long long tmp = 1;


	for(int i = s.size()-1;i>=0;i--){
		// cout<<"yo "<<int(s[i])<<endl;
		if(s[i]>='0' && s[i]<='9'){
			x += tmp * (s[i] - '0');
			tmp *= 8;
		}
	}
	// cout<<"hi "<<s<<" -> "<<x<<endl;
	return x;
}

void debug1(fileS now){
	cout<<now.name<<endl;//<<now.data<<endl;
	cout<<now.uid<<' '<<now.gid<<' '<<now.mode<<' '<<now.size<<' '<<now.mtime<<endl;
}

void init(string fileDir){
	ifstream infile(fileDir.c_str());

	infile.seekg(0, ios::end);
	size_t len = infile.tellg();
	infile.seekg(0, ios::beg);

	infile.read(buf, len);

	int cnt = 0;
	while(cnt < len){
		fileS now;

		now.name = "/" + getData(cnt, 100);
		if(now.name == "/") break;

		now.mode = eight10( getData(cnt, 8) );
		now.uid = eight10( getData(cnt, 8) );
		now.gid = eight10( getData(cnt, 8) );
		now.size = eight10( getData(cnt, 12) );
		now.mtime = eight10( getData(cnt, 12) );
		cnt += 8;
		cnt += 1;
		cnt += 108;
		cnt += 32;
		cnt += 32;
		cnt += 8;
		cnt += 8;
		cnt += 167;
		// cout<<"cnt = "<<cnt<<endl;
		now.data = getAllData(cnt, now.size);
		// cout<<"cnt2 = "<<cnt<<endl;

		// debug1(now);

		if(cnt%512 != 0){
			cnt += 512 - (cnt%512);
		}

		if(fs.find(now.name) == fs.end() || (fs[now.name].mtime < now.mtime)){
			fs[now.name] = now;
		}

	}
}

static struct fuse_operations op;
int main(int argc, char *argv[]){
	init("./test.tar");
	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	return fuse_main(argc, argv, &op, NULL);
}