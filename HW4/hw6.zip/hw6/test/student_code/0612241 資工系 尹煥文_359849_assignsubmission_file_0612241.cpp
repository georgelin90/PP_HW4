/*
Student No.: 0612241
Student Name: Huan-Wen Yin
Email: kevinyin999@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse/fuse.h>
#include <cstdio>
#include <fcntl.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <cstring>
#include <cerrno>


#define existin(element, container) (container.find(element) != container.end())

using namespace std;

const char sep = '/';

size_t same(const string &s){
	return s.rfind(sep, s.length());
}
map<string, gid_t> files_gid;
string getFileName(const string &s) {
	size_t i = same(s);
	if (i != string::npos) {
		return (s.substr(i + 1, s.length() - i));
	}else{
		return s;
	}
}

string getPath(const string &s) {
	size_t i = same(s);
	if (i != string::npos) {
		return (s.substr(0, i));
	}else{
		return ("");
	}
}


const auto TMAGIC = "ustar";        /* ustar and a null */


const int block_size{512};
set<char> typeflag_record = {'0','\0','5'};

#define word char



map<string, uid_t> files_uid;


char tar_path[] = "./test.tar";
map<string, time_t> files_mtime;

typedef struct shit {                                     /* byte offset */
	word name[100];               /*   0 */
	char mode[8];                 /* 100 */
	word uid[8];                  /* 108 */
	char gid[8];                  /* 116 */
	word size[12];                /* 124 */
	char mtime[12];               /* 136 */
	char chsum[8];                /* 148 */
	word typeflag;                /* 156 */
	char lname[100];              /* 157 */
	char magic[6];                /* 257 */
	word sion[2];                 /* 263 */
	char ume[32];                 /* 265 */
	word gne[32];                 /* 297 */
	char major[8];                /* 329 */
	word minor[8];                /* 337 */
	word prefix[155];             /* 345 */
	/* 500 */
} tar_posix_header;


map<string, mode_t> files_mode;
map<string, size_t> file_in_tar_addrs;
map<string, size_t> files_size;

void read_tar_attr(const tar_posix_header *header, size_t pos, size_t file_size, const string &cur_file) {
	files_size[cur_file] = file_size;
	file_in_tar_addrs[cur_file] = pos;
	files_mtime[cur_file] = strtoul(header->mtime, nullptr, 8);
	files_uid[cur_file] = strtoul(header->uid, nullptr, 8);
	files_gid[cur_file] = strtoul(header->gid, nullptr, 8);
	files_mode[cur_file] = strtoul(header->mode, nullptr, 8);
}

string &remove_unnecssary_slash(string &cur_file) {
	int again = 5;
	if (cur_file.back() != '/'){
		return cur_file;
	}else if (again + 2 == 7){
		cur_file = cur_file.substr(0, cur_file.size() - 1);
		return cur_file;
	}else{
		return cur_file;
	}
}

basic_string<char, char_traits<char>, allocator<char>> remove_first_slash(const char *path) {
	string pathstr = path;
	int shit = 5;
	if(shit + 1 == 6)
		return pathstr.substr(1, pathstr.size() - 1);
	else
		return 0;
}
map<string, set<string>> dir_content;
size_t size;
FILE *file;
bool IsValidTarFile() {
	unsigned char buf[block_size];
	if (!file) {
		return false;
	}
	auto *header = (tar_posix_header *) buf;
	
	memset(buf, 0, block_size);

	fseek(file, 0, SEEK_END);
	size = ftell(file);
	fseek(file, 0, SEEK_SET);
	if (size % block_size != 0) {
		return false;
	}

	size_t pos{0};

	while (true) {
		size_t read_size = fread(buf, block_size, 1, file);
		if (read_size != 1) break;
		if (header->magic == TMAGIC) break;

		pos += block_size;
		size_t file_block_count = (strtoul(header->size, nullptr, 8) + block_size - 1) / block_size;

		string cur_file = (header->name);
		cur_file = remove_unnecssary_slash(cur_file);
		auto cur_path = getPath(cur_file);
		auto cur_filename = getFileName(cur_file);

		if(existin(header->typeflag, typeflag_record)){
			if(!existin(cur_file,files_mtime)){
				read_tar_attr(header, pos, strtoul(header->size, nullptr, 8), cur_file);
			}else {
				if(files_mtime[cur_file] < strtoul(header->mtime, nullptr, 8)){
					read_tar_attr(header, pos, strtoul(header->size, nullptr, 8), cur_file);
				}
			}
			if (!existin(cur_path, dir_content)) {
				set<string> temp;
				dir_content[cur_path] = temp;
			}
			if (cur_filename.size() != 0) {
				dir_content[cur_path]
						.insert(cur_filename);
			}
			pos += file_block_count * block_size;
			fseek(file, pos, SEEK_SET);
		}
	}
	if(!file)
		fseek(file, 0, SEEK_SET);

	return true;
}

bool flag;
bool GetFileContents(const string& file_name, char *contents) {
	flag = false;
	if(existin(file_name, files_size)){
		flag = true;
		fseek(file, file_in_tar_addrs[file_name], SEEK_SET);
		fread(contents, files_size[file_name], 1, file);
		fseek(file, 0, SEEK_SET);
		return flag;
	}
	return flag;
}

size_t GetFileSize(string file_name) {	
	return files_size[file_name];
}

int open_and_parse_tar_contents() {
	file = fopen(tar_path, "rb");
	if (!IsValidTarFile()) {
		return -1;
	}

	/*for (auto const &pair : dir_content) {
		for (auto name : pair.second) {
			//string full_path = ;
			cout << "    " << name << ", Size: " << files_size[pair.first + "/" + name] << endl;
			cout << "        Mtime: " << files_mtime[pair.first + "/" + name];
			cout << ", Gid: " << files_gid[pair.first + "/" + name];
			cout << ", Uid: " << files_uid[pair.first + "/" + name];
			cout<<endl;
		}
	}*/
	return 0;
}
//#ifndef __APPLE__


int
read_dir_content(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
	string pathstr = path;
	for (auto file : dir_content[pathstr.substr(1, pathstr.size() - 1)]) {
		filler(buffer, file.c_str(), nullptr, 0);
	}
	return 0;
}

int getattr(const char *path, struct stat *stdbuf) {
	memset(stdbuf, 0, sizeof(struct stat));
	string pathstr = path;

	stdbuf->st_uid = files_uid[pathstr.substr(1, pathstr.size() - 1)];
	stdbuf->st_gid = files_gid[pathstr.substr(1, pathstr.size() - 1)];
	stdbuf->st_mtime = files_mtime[pathstr.substr(1, pathstr.size() - 1)];
	if(pathstr.substr(1, pathstr.size() - 1) == ""){
		stdbuf->st_mode = S_IFDIR | 0444u;
	} else if (existin(pathstr.substr(1, pathstr.size() - 1), dir_content)) {// Setup as dir
		stdbuf->st_mode = S_IFDIR | files_mode[pathstr.substr(1, pathstr.size() - 1)];
	} else if (existin(pathstr.substr(1, pathstr.size() - 1), file_in_tar_addrs)) {// Setup as file
		stdbuf->st_mode = S_IFREG | files_mode[pathstr.substr(1, pathstr.size() - 1)];
		stdbuf->st_size = GetFileSize(pathstr.substr(1, pathstr.size() - 1));
	} else
		return -ENOENT; // File not found

	return 0;
}

int readfile(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *_) {
	(void) _;

	file = fopen(tar_path, "rb");
	auto strip_path = remove_first_slash(path);
	char *contents = new char[GetFileSize(strip_path) + 1];
	if (GetFileContents(strip_path, contents)) {
		contents[GetFileSize(strip_path)] = '\0';
		if (offset < GetFileSize(strip_path)) {
			if (offset + size > GetFileSize(strip_path)) 
				size = GetFileSize(strip_path) - offset;
			
			memcpy(buffer, contents + offset, size);
		} else {
			size = 0;
		}
		return size;
	}
	return 0;
}


struct fuse_operations oper;

int mount_tar(int argc, char *argv[]) {
	open_and_parse_tar_contents();
	if (!IsValidTarFile()) {
		//fprintf(stderr, "it is not a valid tar file: %s\n", tar_path);
		return -1;
	}

	oper.getattr = getattr;
	oper.readdir = read_dir_content;
	oper.read = readfile;
	return fuse_main(argc, argv, &oper, nullptr);
}

int main(int argc, char *argv[]) {
    //cout << "Fuse Server Start" << endl;
#ifndef __APPLE__
    return mount_tar(argc, argv);
#endif
}


