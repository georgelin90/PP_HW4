/*
Student No.: 0611262
Student Name: Chang-Yen Tseng
Email: vanilla.cv06@nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30
#include <fcntl.h>
#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#define LF_OLDNORMAL '\0' /* Normal disk file, Unix compatible */
#define LF_NORMAL '0'     /* Normal disk file */
#define LF_LINK '1'       /* Link to previously dumped file */
#define LF_SYMLINK '2'    /* Symbolic link */
#define LF_CHR '3'        /* Character special file */
#define LF_BLK '4'        /* Block special file */
#define LF_DIR '5'        /* Directory */
#define LF_FIFO '6'       /* FIFO special file */
#define LF_CONTIG '7'     /* Contiguous file */

#define MIN(a, b) (((a) < (b)) ? (a) : (b))

using namespace std;
static unordered_map<string, struct stat> um;
static unordered_map<string, unordered_set<string> > dir;
static unordered_map<string, char *> content;
char *mem_map;
size_t mem_map_size;

string trim_path(const string path) {
    return path.back() == '/' ? path.substr(0, path.length() - 1) : path;
}

pair<string, string> split_path(const string path) {
    size_t idx = path.find_last_of('/');
    string dir_path = idx == 0 ? "/" : path.substr(0, idx);
    return make_pair(dir_path, path.substr(idx + 1));
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler,
               off_t offset, struct fuse_file_info *fi) {
    string spath(path);
    for (string s : dir[spath]) {
        filler(buffer, s.c_str(), NULL, 0);
    }
    return 0;
}

int my_getattr(const char *path, struct stat *st) {
    string spath(path);
    if (spath == "/") {
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    if (um.find(spath) == um.end()) return -ENOENT;
    memcpy(st, &um[spath], sizeof(struct stat));
    return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset,
            struct fuse_file_info *fi) {
    string spath(path);
    size_t size_c = MIN(size, um[spath].st_size - offset);
    memcpy(buffer, content[path] + offset, size_c);
    return size_c;
}

void read_tar(char *mem_map, size_t size) {
    char *ptr = mem_map;
    char blank[512] = {};
    while (ptr - mem_map < size) {
        if (memcmp(ptr, blank, 512) == 0) {
            ptr += 512;
            continue;
        }

        struct stat st;
        memset(&st, 0, sizeof(st));

        string path(ptr);
        path = "/" + path;
        path = trim_path(path);
        st.st_mode |= strtol(ptr + 100, NULL, 8);
        switch (*(ptr + 156)) {
            case LF_SYMLINK:
                st.st_mode |= S_IFLNK;
                break;
            case LF_CHR:
                st.st_mode |= S_IFCHR;
                break;
            case LF_BLK:
                st.st_mode |= S_IFBLK;
                break;
            case LF_DIR:
                st.st_mode |= S_IFDIR;
                break;
            case LF_FIFO:
                st.st_mode |= S_IFIFO;
                break;
            default:
                st.st_mode |= S_IFREG;
                break;
        }
        st.st_uid = strtol(ptr + 108, NULL, 8);
        st.st_gid = strtol(ptr + 116, NULL, 8);
        st.st_size = strtol(ptr + 124, NULL, 8);
        st.st_mtime = strtoul(ptr + 136, NULL, 8);

        if (um.find(path) == um.end() || um[path].st_mtime <= st.st_mtime) {
            um[path] = st;
            pair<string, string> splitted_path = split_path(path);
            if (splitted_path.second.length() > 0) {
                dir[splitted_path.first].insert(splitted_path.second);
            }
            content[path] = ptr + 512;
        }
        ptr += 512 + ((st.st_size + 511) & ~511);
    }
    cout << "done" << endl;
}

void my_destroy(void *private_data) { munmap(mem_map, mem_map_size); }

static struct fuse_operations op;
int main(int argc, char *argv[]) {
    int fd = open("test.tar", O_RDONLY, 0x644);
    struct stat file_stat;
    fstat(fd, &file_stat);
    mem_map_size = file_stat.st_size;
    mem_map = (char *)mmap(NULL, mem_map_size, PROT_READ, MAP_PRIVATE, fd, 0);
    read_tar(mem_map, mem_map_size);
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    op.destroy = my_destroy;
    return fuse_main(argc, argv, &op, NULL);
}
