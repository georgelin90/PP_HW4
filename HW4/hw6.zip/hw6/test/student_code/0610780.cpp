/*
Student No.: 0610780
Student Name: 楊哲睿
Email: jerry.eed06@g2.nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <string.h>
#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <algorithm>
#include <errno.h>

#define BLOCK_SIZE 512

#define  LF_OLDNORMAL '\0'       /* Normal disk file, Unix compatible */
#define  LF_NORMAL    '0'        /* Normal disk file */
#define  LF_LINK      '1'        /* Link to previously dumped file */
#define  LF_SYMLINK   '2'        /* Symbolic link */
#define  LF_CHR       '3'        /* Character special file */
#define  LF_BLK       '4'        /* Block special file */
#define  LF_DIR       '5'        /* Directory */
#define  LF_FIFO      '6'        /* FIFO special file */
#define  LF_CONTIG    '7'        /* Contiguous file */

typedef struct {
	char name[100];
	char mode[8];
	char uid[8];
	char gid[8];
	char size[12];
	char modify_time[12];
	char checksum[8];
	char link_flag;
	char link_name[100];
	char magic[8];
	char uname[32];
	char gname[32];
	char major_dev[8];
	char minor_dev[8];
	char padding[167];
} tar_header;

/*
Offset   Length   Contents
  0    100 bytes  File name ('\0' terminated, 99 maxmum length)
100      8 bytes  File mode (in octal ascii)
108      8 bytes  User ID (in octal ascii)
116      8 bytes  Group ID (in octal ascii)
124     12 bytes  File size (s) (in octal ascii)
136     12 bytes  Modify time (in octal ascii)
148      8 bytes  Header checksum (in octal ascii)
156      1 bytes  Link flag
157    100 bytes  Linkname ('\0' terminated, 99 maxmum length)
257      8 bytes  Magic ("ustar  \0")
265     32 bytes  User name ('\0' terminated, 31 maxmum length)
297     32 bytes  Group name ('\0' terminated, 31 maxmum length)
329      8 bytes  Major device ID (in octal ascii)
337      8 bytes  Minor device ID (in octal ascii)
345    167 bytes  Padding
512   (s+p)bytes  File contents (s+p) := (((s) + 511) & ~511), round up to 512 bytes
*/

using namespace std;

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi);
int my_getattr(const char *path, struct stat *st);
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi);

static struct fuse_operations op;

int main(int argc, char *argv[]) {
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    printf( "--> Getting The List of Files of %s\n", path );

    FILE* file = fopen("./test.tar", "r");

    int path_length = strlen(path);
    char* path_new = new char[path_length+2];
    strcpy(path_new, path+1);
    if (strlen(path_new) > 1) {
    	path_new[path_length-1] = '/';
    	path_new[path_length] = '\0';
    }

    cout << path << endl;
    cout << path_new << endl;

    tar_header header;
    memset(&header, 0, BLOCK_SIZE);

    fseek(file, 0, SEEK_END);
	int tar_file_size = ftell(file);
	fseek(file, 0, SEEK_SET);

    int pos = 0;

    while (1) {
        size_t read_size = fread(&header, BLOCK_SIZE, 1, file);
        if (read_size != 1 || ((tar_file_size - pos) / BLOCK_SIZE <= 2)) break;

        pos += BLOCK_SIZE;
        int file_size = stoi(header.size, nullptr, 8);
        int file_block_count = (file_size + BLOCK_SIZE - 1) / BLOCK_SIZE;

        cout << "0. " << header.name << endl;

        if (strlen(path_new) == strlen(header.name) && !strncmp(path_new, header.name, path_length-1));
        // else if (header.name[strlen(header.name)-1] == '/' && strstr(header.name, path_new) && strncmp(path, "/\0", 2));
        else if (!strncmp(path_new, header.name, path_length) || !strncmp(path, "/\0", 2)) {
        	strcpy(&header.name[0], &header.name[path_length-1]);

        	cout << "1. " << header.name << endl;

        	if (header.name[strlen(header.name)-1] == '/')
            	header.name[strlen(header.name)-1] = '\0';

            cout << "2. " << header.name << endl;

            if (header.name[0] == '/' && strncmp(path, "/\0", 2)) {
            	strcpy(&header.name[0], &header.name[1]);

            	cout << "3. " << header.name << endl;

            	if (strstr(header.name, "/") == NULL) {
	            	cout << "4. " << header.name << endl;
	            	filler(buffer, header.name, NULL, 0);
	            }
        	} else {
        		if (strstr(header.name, "/") == NULL) {
	            	cout << "5. " << header.name << endl;
	            	filler(buffer, header.name, NULL, 0);
	            }
        	}
            
        }       

        pos += file_block_count * BLOCK_SIZE;
		fseek(file, pos, SEEK_SET);
    }

    fclose(file);
    return 0;
}

int my_getattr(const char *path, struct stat *st) {
    printf("--> Attributes of %s requested\n", path);
    cout << "getattr: " << path << endl;

    FILE* file = fopen("./test.tar", "r");

    tar_header header;
    memset(&header, 0, BLOCK_SIZE);

    fseek(file, 0, SEEK_END);
	int tar_file_size = ftell(file);
	fseek(file, 0, SEEK_SET);

    int pos = 0;

    int found = 0;

    while (1) {
        size_t read_size = fread(&header, BLOCK_SIZE, 1, file);
        if (read_size != 1 || ((tar_file_size - pos) / BLOCK_SIZE <= 2)) break;

        pos += BLOCK_SIZE;
        int file_size = stoi(header.size, nullptr, 8);
        int file_block_count = (file_size + BLOCK_SIZE - 1) / BLOCK_SIZE;

        st->st_uid = stoi(header.uid, nullptr, 8);
        st->st_gid = stoi(header.gid, nullptr, 8);
        st->st_mtime = stoi(header.modify_time, nullptr, 8);
        st->st_size = stoi(header.size, nullptr, 8);

        if (header.name[strlen(header.name)-1] == '/')
            header.name[strlen(header.name)-1] = '\0';

        if (strncmp(path, "/\0", 2) == 0) {
	    	st->st_mode = S_IFDIR | 0444;
	    	found = 1;
	    	break;
	    } else if (strcmp(header.name, &path[1]) == 0) {
            switch(header.link_flag) {
                case LF_OLDNORMAL: // intentionally dropping through
    			case LF_NORMAL:
    				// normal file
                    st->st_mode = S_IFREG | stoi(header.mode, nullptr, 8);
    				break;
    			case LF_DIR:
    				// directory
                    st->st_mode = S_IFDIR | stoi(header.mode, nullptr, 8);
    				break;
    			default:
    				break;
            }
            found = 1;
            break;
        }

        pos += file_block_count * BLOCK_SIZE;
		fseek(file, pos, SEEK_SET);
    }

    fclose(file);

    if (found)
    	return 0;
    else
    	return -ENOENT;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
    printf( "--> Trying to read %s, %u, %u\n", path, offset, size );

    FILE* file = fopen("./test.tar", "r");

    tar_header header;
    char* content = NULL;

    memset(&header, 0, BLOCK_SIZE);

    fseek(file, 0, SEEK_END);
	int tar_file_size = ftell(file);
	fseek(file, 0, SEEK_SET);

    int pos = 0;

    while (1) {
        size_t read_size = fread(&header, BLOCK_SIZE, 1, file);
        if (read_size != 1 || ((tar_file_size - pos) / BLOCK_SIZE <= 2)) break;

        pos += BLOCK_SIZE;
        int file_size = stoi(header.size, nullptr, 8);
        int file_block_count = (file_size + BLOCK_SIZE - 1) / BLOCK_SIZE;

        if (strcmp(header.name, &path[1]) == 0) {
            if (header.link_flag == LF_OLDNORMAL || header.link_flag == LF_NORMAL) {
                content = new char[file_block_count*BLOCK_SIZE];
                fseek(file, pos, SEEK_SET);
                fread(content, file_size, 1, file);
                break;
            }
        }

        pos += file_block_count * BLOCK_SIZE;
		fseek(file, pos, SEEK_SET);
    }

    memcpy(buffer, content + offset, size);
    fclose(file);

    if (strlen(content) < offset)
    	return 0;
    else
    	return strlen(content) - offset;
}
