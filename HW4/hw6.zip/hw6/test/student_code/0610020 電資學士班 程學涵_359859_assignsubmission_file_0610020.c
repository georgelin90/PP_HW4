/*
Student No.: 0610020
Student Name: 程學涵
Email: heidi8844@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION    30
#define FM_OFFSET           100
#define UID_OFFSET          108
#define GID_OFFSET          116
#define FS_OFFSET           124
#define MTIME_OFFSET        136
#define TYPE_OFFSET         156
#define MAGIC_OFFSET        257
#define BLOCK_SIZE          512
#define NAME_SIZE           100
#define S_SIZE              12
#define MAGIC_SIZE          5

#include <fuse.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

struct TarHeader{
    char file_path[100];
    char filename[100];
    int mode;
    int uid;
    int gid;
    unsigned long file_size;
    int mtime;
};

void header_proc(char buffer[512], struct TarHeader* TH){
    int len = 0;
    int k = 0;
    char name[100];
    char path[100];
    
    TH->mode = 0;
    TH->uid = 0;
    TH->gid = 0;
    TH->file_size = 0;
    TH->mtime = 0;

    //filename
    strncpy(path, buffer, 100);
    if(path[(int)strlen(path)-1] == '/')
        path[(int)strlen(path)-1] = '\0';
    strncpy(TH->file_path, path, 100);
    
    char *ptr = strtok(path, "/");

    while(ptr != NULL){
        strncpy(name, ptr, 100);
        ptr = strtok(NULL, "/");
        len++;
    }
    strncpy(TH->filename, name, 100);
    //mode
    for(int i = FM_OFFSET; i < 108; i++){
        if(buffer[i]<'0'||buffer[i]>'7')break;
        TH->mode = (TH->mode)*8 + (buffer[i] - '0');
    }
    //uid
    for(int i = UID_OFFSET; i< 116; i++){
        if(buffer[i]<'0'||buffer[i]>'7')break;
        TH->uid = TH->uid*8 + (buffer[i]-'0');
    }
    //gid
    for(int i = GID_OFFSET; i < 124; i++){
        if((buffer[i]<'0'||buffer[i]>'7'))break;
        TH->gid = TH->gid*8 + (buffer[i]-'0');
    }
    //file size
    for(int i = FS_OFFSET; i < FS_OFFSET+S_SIZE-1; i++){
        if(buffer[i] < '0'||buffer[i] > '7')break;
        TH->file_size = TH->file_size*8 + (buffer[i]-'0');
    }
    //mtime
    for(int i = MTIME_OFFSET; i < 148; i++){
        if(buffer[i]<'0'||buffer[i]>'7')break;
        TH->mtime = TH->mtime*8 + (buffer[i]-'0');
    }
}


int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
    struct TarHeader* TH;
    int fileOffset = 0;
    char zeroBlock[512] = {0};
    char filename[100];
    char buf[512];
    char *output = NULL;
    
    TH = malloc(sizeof(struct TarHeader));
    (void) offset;
    (void) fi;
    
    FILE *fp;
    fp = fopen("test.tar", "r");
    
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    if(strcmp(path, "/") == 0){
        while(1){
            for(int i = 0; i<512; i++){
                buf[i] = fgetc(fp);
            }
            
            if(!(memcmp(buf, zeroBlock, 512)))return 0;
            
            header_proc(buf, TH);
            if(strcmp(TH->file_path, TH->filename) == 0){
                filler(buffer, TH->filename, NULL, 0);
            }
            fileOffset = TH->file_size/BLOCK_SIZE;
            if(TH->file_size%BLOCK_SIZE) fileOffset+=1;
            fseek( fp, fileOffset*BLOCK_SIZE, SEEK_CUR);
        }
        fclose(fp);
    }
    
    while(1){
        for(int i = 0; i<512; i++){
            buf[i] = fgetc(fp);
        }
        
        if(!(memcmp(buf, zeroBlock, 512)))return 0;
        
        header_proc(buf, TH);
        if(strstr(TH->file_path, path+1) != NULL){
            if(strlen(TH->file_path)==(strlen(path)+strlen(TH->filename)))
                filler(buffer, TH->filename, NULL, 0);
        }
        fileOffset = TH->file_size/BLOCK_SIZE;
        if(TH->file_size%BLOCK_SIZE) fileOffset+=1;
        fseek( fp, fileOffset*BLOCK_SIZE, SEEK_CUR);
    }
    fclose(fp);
    return 0;
}
int my_getattr(const char *path, struct stat *st){
    struct TarHeader* TH;
    char buf[512];
    char zeroBlock[512] = {0};
    int fileOffset = 0;
    int ret = 0;
    
    TH = malloc(sizeof(struct TarHeader));
    
    FILE *fp;
    fp = fopen("test.tar", "r");
    if(strcmp(path, "/") == 0){
        st->st_mode = S_IFDIR | 0444;
        st->st_uid = getuid();
        st->st_gid = getgid();
        return 0;
    }else{
        while(1){
            for(int i = 0; i<512; i++){
                buf[i] = fgetc(fp);
            }
            
            if(!(memcmp(buf, zeroBlock, 512))){
                ret = -ENOENT;
                break;
            }
            
            header_proc(buf, TH);
            if(strcmp(path+1, TH->file_path) == 0){
                if(buf[TYPE_OFFSET] == '5'){
                    st->st_mode = S_IFDIR | TH->mode;
                }else if(buf[TYPE_OFFSET] == '0'){
                    st->st_mode = S_IFREG | TH->mode;
                }else ret = -ENOENT;
                st->st_uid = TH->uid;
                st->st_gid = TH->gid;
                st->st_mtime = TH->mtime;
                st->st_size = TH->file_size;
                break;
            }
            fileOffset = TH->file_size/BLOCK_SIZE;
            if(TH->file_size%BLOCK_SIZE) fileOffset+=1;
            fseek( fp, fileOffset*BLOCK_SIZE, SEEK_CUR);
        }
    }
    fclose(fp);
    return ret;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    
    struct TarHeader* TH;
    char buf[512];
    char *subbuf;
    char zeroBlock[512] = {0};
    int fileOffset = 0;
    unsigned long content_size = 0;
    int count = 0;
    int index = 0;
    
    TH = malloc(sizeof(struct TarHeader));
    (void) fi;
    
    FILE *fp;
    fp = fopen("test.tar", "r");
    while(1){
        for(int i = 0; i<512; i++){
            buf[i] = fgetc(fp);
        }
        
        if(!(memcmp(buf, zeroBlock, 512))){
            fclose(fp);
            return -ENOENT;
        }
        
        header_proc(buf, TH);
        
        if(strcmp(path+1, TH->file_path) == 0){
            
            subbuf = malloc(TH->file_size*sizeof(buf[0]));
            
            content_size = TH->file_size;
            index = 0;
            for(index = 0; index< TH->file_size; index++){
                subbuf[index] = fgetc(fp);
            }
            if(offset < TH->file_size){
                if(offset + size > TH->file_size)
                    size = TH->file_size - offset;
                memcpy(buffer, subbuf + offset, size);
            }else size = 0;
            fclose(fp);
            return size;
        }
        fileOffset = TH->file_size/BLOCK_SIZE;
        if(TH->file_size%BLOCK_SIZE) fileOffset+=1;
        fseek( fp, fileOffset*BLOCK_SIZE, SEEK_CUR);
    }
    fclose(fp);
    return -ENOENT;
}
static struct fuse_operations op;

int main(int argc, char *argv[]){
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
