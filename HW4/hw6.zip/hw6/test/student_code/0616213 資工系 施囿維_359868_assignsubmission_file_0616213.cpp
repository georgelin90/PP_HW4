/*
Student No.: 0616213
Student Name:  施囿維(Willy shih)
Email: neoyuki.cs06@nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <cmath>
#include <vector>
#include <errno.h>
#define ASCII_TO_NUMBER(num) ((num)-48)

using namespace std;

ifstream tar;

static uint64_t decodeTarOct(char* data, size_t size = 12){

    unsigned char* currentPtr = (unsigned char*)data + size;
    uint64_t sum = 0;
    uint64_t currentMul = 1;

    unsigned char* checkPtr = currentPtr;

    for(; checkPtr >= (unsigned char*)data; checkPtr--){
        if((*checkPtr)==0 || (*checkPtr) == ' '){
            currentPtr = checkPtr - 1;
        }
    }
    for(; currentPtr >= (unsigned char*)data; currentPtr--){
        sum += ASCII_TO_NUMBER(*currentPtr) * currentMul;
        currentMul *= 8;
    }
    return sum;
}

struct tarHeader {
    char filename[100]; /*0~99*/
    char filemode[8]; /*100~107*/
    char userID[8]; /*108~115*/
    char groupID[8]; /*116~123*/
    char fileSize[12]; /*124~135*/
    char modifyTime[12]; /*136~147*/
    char checksum[8]; /*148~155*/
    char typeFlag; /*156*/
    char offset[355]; /*any other infos :D*/
    
};

class contblock {
    public:
    char cont[512];
    int len;
    contblock(char* c, int n){
        bzero(&cont, 512);
        memcpy(&cont, c, n);
        len = n;
    }
};

class fileNode {
    public:
    char filename[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char filesize[12];
    char mtime[12];
    //char* content;
    vector<contblock > content;
    char flag;
    fileNode(struct tarHeader header, vector<contblock > cont){
        //cout<<"haha it's me00\n";
        memcpy(filename, header.filename, 100);
        //cout<<"haha it's me11\n";
        memcpy(mode, header.filemode, 8);
        //cout<<"haha it's me22\n";
        memcpy(uid, header.userID, 8);
        //cout<<"haha it's me33\n";
        memcpy(gid, header.groupID, 8);
        //cout<<"haha it's me44\n";
        memcpy(filesize, header.fileSize, 12);
        //cout<<"haha it's me55\n";
        memcpy(mtime, header.modifyTime, 12);
        //cout<<"haha it's me66\n";
        flag = header.typeFlag;
        int sz = decodeTarOct(filesize);
        content = cont;
        //cout<<"haha it's me77\n";
    }
    ~fileNode(){
        //delete(content);
    }
};

class dirNode {
    public:
    char dirname[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char mtime[12];
    char flag;
    dirNode(struct tarHeader header){
        //cout<<"haha it's me0\n";
        memcpy(dirname, header.filename, 100);
        //cout<<"haha it's me1\n";
        memcpy(mode, header.filemode, 8);
        //cout<<"haha it's me2\n";
        memcpy(uid, header.userID, 8);
        //cout<<"haha it's me3\n";
        memcpy(gid, header.groupID, 8);
        //cout<<"haha it's me4\n";
        memcpy(mtime, header.modifyTime, 12);
        //cout<<"haha it's me5\n";
        flag = header.typeFlag;
    }
};
vector<fileNode > files;
vector<dirNode > dirs;

int finddir(const char *path){
    for(int i=0;i<dirs.size();i++){
        char pathn[1024];
        if(path[0]=='/')
            strcpy(pathn, path+1);
        else
            strcpy(pathn, path);
        strcat(pathn, "/");
        if(strcmp(pathn, dirs[i].dirname)==0){
            //cout<<"found correspond dirname\n";
            return i;
        }
        else {
            //cout<<path+1<<" != "<<dirs[i].dirname<<endl;
        }
    }
    //cout<<"can't find dirname "<<path<<endl;
    return -1;
}

int findfile(const char *path){
    for(int i=0;i<files.size();i++){
        
        if(strcmp(path+1, files[i].filename)==0){
            //cout<<"found correspond filename\n";
            return i;
        }
        else {
            //cout<<path+1<<" != "<<files[i].filename<<endl;
        }
    }
    //cout<<"can't find filename "<<path<<endl;
    return -1;
}

int my_getattr(const char *path, struct stat *st) { /*do something*/
    cout<<"run my_getattr with path :"<<path<<endl;
    int res = 0;

    memset(st, 0, sizeof(struct stat));
    int ind = -1;
    if(strcmp(path, "/")==0){
        //cout<<"case 1\n";
        st->st_mode = S_IFDIR | 0444;
        st->st_uid = getuid();
        st->st_gid = getgid();
        st->st_mtime = time(NULL);
    }
    else if(finddir(path) >= 0){
        ind = finddir(path);
        //cout<<"case 2\n";
        st->st_mode = S_IFDIR | decodeTarOct(dirs[ind].mode);
        cout<<st->st_mode<<endl;
        st->st_uid = decodeTarOct(dirs[ind].uid);
        cout<<st->st_uid<<endl;
        st->st_gid = decodeTarOct(dirs[ind].gid);
        cout<<st->st_gid<<endl;
        st->st_mtime = (time_t)decodeTarOct(dirs[ind].mtime);
        cout<<st->st_mtime<<endl;
    }
    else if(findfile(path) >= 0){
        ind = findfile(path);
        //cout<<"case 3\n";
        //cout<<"id: "<<ind<<endl;
        st->st_mode = S_IFREG | decodeTarOct(files[ind].mode);
        cout<<st->st_mode<<endl;
        st->st_uid = decodeTarOct(files[ind].uid);
        cout<<st->st_uid<<endl;
        st->st_gid = decodeTarOct(files[ind].gid);
        cout<<st->st_gid<<endl;
        st->st_mtime = (time_t)decodeTarOct(files[ind].mtime);
        cout<<st->st_mtime<<endl;
        st->st_size = decodeTarOct(files[ind].filesize);
        cout<<st->st_size<<" : "<<decodeTarOct(files[ind].filesize)<<endl;
    }
    else{
        cout<<"unknown path "<<path<<endl;
        return -ENOENT;
    }
    return res;
 }
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) { 
    cout<<"run my_readdir with path :"<<path<<"\n";
    (void)offset;
    (void)fi;
    //if(strcmp(path, "/")!=0)
    //    return 0;
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    for(int i=0;i<dirs.size();i++){
        char tmp[1024] = "/";
        char fname[1024];
        char pathd[1024];
        bzero(fname, 1024);
        strcpy(pathd, path);
        if(strlen(path)>1){
            strcat(pathd, tmp); //pathd = / or path/
        }
        strcat(tmp, dirs[i].dirname);
        if(strlen(tmp)<strlen(path)){
            continue; 
        }
        memcpy(fname, tmp, strlen(pathd));
        //cout<<"pathd:"<<pathd<<endl;
        if((strcmp(fname, pathd)==0)&&(strcmp(tmp, pathd)!=0)){
            //cout<<"(in readdir)find dirs\n";
            char name[1024];
            bzero(name, 1024);
            memcpy(name, dirs[i].dirname, strlen(dirs[i].dirname)-1);
            string nametmp = tmp;
            string path_s = pathd;
            bool add = 1;
            for(int j=path_s.size();j<nametmp.size();j++){
                if(nametmp[j]=='/'&&j!=nametmp.size()-1){
                    add = 0;
                    break;
                }
            }
            if(add){
                string name_s = name;
                if(name_s[name_s.size()-1]=='/')
                    name_s = name_s.substr(0, name_s.size()-1);
                int id = name_s.find_last_of("/");
                char fin[1024];
                bzero(fin, 1024);
                for(int j=id+1; j<name_s.size();j++){
                    fin[j-id-1] = name_s[j];
                }
                filler(buffer, fin, NULL, 0);
                //cout<<fin<<" stored\n";
            }
            
        }
        
    }
    for(int i=0;i<files.size();i++){
        char tmp[1024] = "/";
        char fname[1024];
        bzero(fname, 1024);
        strcat(tmp, files[i].filename);
        if(strlen(tmp)<strlen(path)){
            continue;
        }
        memcpy(fname, tmp, strlen(path));
        
        if(strcmp(fname, path)==0){
            cout<<"(in readdir)find files\n";
            string name = files[i].filename;
            string path_s = path;
            bool add = 1;
            for(int j=path_s.size();j<name.size();j++){
                if(name[j]=='/'){
                    add = 0;
                    break;
                }
            }
            if(add){
                int id = name.find_last_of("/");
                char fin[1024];
                bzero(fin, 1024);
                for(int j=id+1; j<name.size();j++){
                    fin[j-id-1] = name[j];
                }
                filler(buffer, fin, NULL, 0);
                //cout<<fin<<" stored\n";
            }
        }
    }
    
    return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
    /*do something*/
    cout<<"run my_read with path:"<<path<<"\n";
    int id = findfile(path);
    if(id<0){
        cout<<"error: can't find path in read\n";
        return 0;
    }
    char *buf = new char[size];
    bzero(buf, size);
    int blocknum = size/512 + 1;
    int count=0;
    int datasize = decodeTarOct(files[id].filesize);
    int estsize = offset+size < datasize ? offset+size : datasize;
    for(int i=offset;i<estsize;i++,count++){
        buf[count] = files[id].content[i/512].cont[i-(i/512)*512];
        //if(count%10==0)cout<<count<<endl;
    }
    cout<<"result:(count:"<<count<<", offset:"<<offset<<", size:"<<size<<", datasize:"<<datasize<<")\n";
    //cout<<buf<<endl;
    bzero(buffer, size);
    memcpy(buffer, buf, size);
    //cout<<"read "<<size<<" of data\n";
    
    return count;
}

void init_add(struct tarHeader header){
    //cout<<"start init\n";
    char flg = header.typeFlag;
    
    if(flg == '5'){
        dirNode tmp(header);
        dirs.push_back(tmp);
    }
    else{
        int sz = decodeTarOct(header.fileSize);
        char readblock[512];
        
        int sz_b = sz;
        vector<contblock > vec;
        while(sz_b > 0){
            bzero(&readblock, 512);
            tar.read(readblock, 512);
            //cout<<"read data done\n";
            contblock blocktmp(readblock, 512);
            vec.push_back(blocktmp);
            //cout<<"cat buff done\n";
            sz_b -= 512;
        }
        
        fileNode tmp(header, vec);
        
        files.push_back(tmp);
        //cout<<"push done\n";
    }
    
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
    tar.open("test.tar", ios::in | ios::binary);
    if(!tar){
        cout<<"can't open test.tar!\n";
        return -1;
    }
    char zeroBlock[512];
    //char headerBuff[512];
    memset(zeroBlock, 0, 512);
    //memset(headerBuff, 0, 512);
    //cout<<"start init\n";
    while(tar){
        tarHeader headerBuff;
        tar.read((char*)&headerBuff, 512);
        if(memcmp(&headerBuff, zeroBlock, 512)==0){
            cout<<"Found TAR end\n";
            break;
        }
        init_add(headerBuff);
    }
    tar.close();
    cout<<"init ends\n";
    cout<<"number of dirs: "<<dirs.size()<<endl;
    cout<<"number of files: "<<files.size()<<endl;
    for(int i=0;i<files.size();i++){
        cout<<files[i].filename<<":\n";
        cout<<decodeTarOct(files[i].mode)<<endl;
        cout<<decodeTarOct(files[i].uid)<<endl;
        cout<<decodeTarOct(files[i].gid)<<endl;
        cout<<(time_t)decodeTarOct(files[i].mtime)<<endl;
        cout<<decodeTarOct(files[i].filesize)<<endl;
        cout<<"\n---------------------\n";
    }

    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

