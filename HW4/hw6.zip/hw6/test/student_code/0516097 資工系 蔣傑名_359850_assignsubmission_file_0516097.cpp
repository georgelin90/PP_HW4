/*
Student No.: 0516097
Student Name: 蔣傑名
Email: nax1016@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30
#include <iostream>
#include <fuse.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
using namespace std;

char file[512]; //NUL-terminated
char filename[100]; //NUL-terminated
char mode[8];
char uid[8];
char gid[8];
char fileSize[12];
char lastModification[12];
char Header_checksum[8];
char Link_flag[1];
char Linkname [100]; 
char Magic  [8]; 
char User_name  [32]; 
char Group_name  [32]; 
char Major_device_ID  [8]; 
char Minor_device_ID  [8]; 


unsigned int octal_string_to_int(char *a){
   unsigned int output = 0;
   int space = 0;
   if(a[strlen(a)-1] == ' ') space = 1;
    for(int i=strlen(a)-space; i>0; i--){
        output = output*8 +  *a++ - '0';
    }
    return output;
}



int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    char temp_filename[1000][100]; //NUL-terminated
    // for(int i=0; i<50; i++) memset(temp_filename[i], 100, '\0');
    FILE* fp;
    fp = fopen("test.tar", "r");
    char temp;
    int ct = 0;
    int current_num = 0;

    while(fscanf(fp, "%c", &temp) ==1 ){

        file[ct++] = temp;
        if(ct == 512){
            strncpy(filename, file, 100 );
            strncpy(fileSize, file + 124, 12 );
            if(strlen(filename) == 0) break;   
            if(strlen(path) == 1){
                ct = 0;
                int slash_found = 0;
                for(int i=strlen(path) -1 ; i<strlen(filename); i++){
                    if(filename[i] == '/'){
                        if(i != strlen(filename) -1){
                            slash_found = 1;
                            break;
                        }
                        else{
                            filename[i] = '\0';
                            if(strlen(filename) != 0){
                                if (filename[strlen(filename)-1]=='/') filename[strlen(filename)-1]='\0';
                                int duplicate = 0;
                                for(int i=0; i<current_num; i++){
                                    if(strcmp(temp_filename[i], filename) == 0){
                                        cout<<i<<temp_filename[i]<<" "<< filename<<endl;
                                        duplicate = 1;
                                    }
                                }
                                if(!duplicate){
                                    filler(buffer, filename, NULL, 0);
                                    strcpy(temp_filename[current_num++], filename);
                                }
                            }
                            slash_found = 1;
                            break;
                        }
                    }
                }
                if(!slash_found) {
                    if(strlen(filename) != 0){
                        if (filename[strlen(filename)-1]=='/') filename[strlen(filename)-1]='\0';
                        int duplicate = 0;
                        for(int i=0; i<current_num; i++){
                            if(strcmp(temp_filename[i], filename) == 0){
                                duplicate = 1;
                            }
                        }
                        if(!duplicate){
                            filler(buffer, filename, NULL, 0);
                            strcpy(temp_filename[current_num++], filename);
                        }

                    }
                }
                fseek(fp, (((octal_string_to_int(fileSize)) + 511) & ~511), SEEK_CUR);
            }
            else{
                int same_dir = 1;
                ct = 0;
                for(int i=1; i<strlen(path); i++){
                    if(filename[i-1] != path[i]) {
                        same_dir = 0;
                        break;
                    }
                }
                if(filename[strlen(path)-1] != '/') {
                    same_dir = 0;
                }
                int slash_found = 0;
                for(int i=strlen(path) ; i<strlen(filename); i++){
                    if(filename[i] == '/'){
                        if(i != strlen(filename) -1){
                            slash_found = 1;
                            break;
                        }
                        else{
                            filename[i] = '\0';
                            if(same_dir){
                                char temp_filename_2 [100];
                                strncpy(temp_filename_2, filename + strlen(path), strlen(filename) - strlen(path));
                                temp_filename_2[strlen(filename) - strlen(path)] = '\0';
                                if(strlen(temp_filename_2) != 0){
                                    if (temp_filename_2[strlen(temp_filename_2)-1]=='/') temp_filename_2[strlen(temp_filename_2)-1]='\0';
                                    int duplicate = 0;
                                    for(int i=0; i<current_num; i++){
                                        if(strcmp(temp_filename[i], temp_filename_2) == 0){
                                            duplicate = 1;
                                        }
                                    }
                                    if(!duplicate){
                                        filler(buffer, temp_filename_2, NULL, 0);
                                        strcpy(temp_filename[current_num++], temp_filename_2);
                                    }

                                }
                            }
                            slash_found = 1;
                            break;
                        }
                    }
                }
                if(!slash_found && same_dir) {
                    char temp_filename_2 [100];
                    strncpy(temp_filename_2, filename + strlen(path), strlen(filename) - strlen(path));
                    temp_filename_2[strlen(filename) - strlen(path)] = '\0';
                    if(strlen(temp_filename_2) != 0){
                        if (temp_filename_2[strlen(temp_filename_2)-1]=='/') temp_filename_2[strlen(temp_filename_2)-1]='\0';
                        int duplicate = 0;
                        for(int i=0; i<current_num; i++){
                            if(strcmp(temp_filename[i], temp_filename_2) == 0){
                                duplicate = 1;
                            }
                            
                        }
                        if(!duplicate){
                            filler(buffer, temp_filename_2, NULL, 0);
                            strcpy(temp_filename[current_num++], temp_filename_2);
                        }
                    }
                }
                fseek(fp, (((octal_string_to_int(fileSize)) + 511) & ~511), SEEK_CUR);
            }
        }
    }

    fclose(fp);
    return 0;
}


int my_getattr(const char *path, struct stat *st) {
    // char temp_filename[100]; //NUL-terminated
    int temp_uid = 0;
    int temp_gid = 0;
    unsigned long int temp_mtime = 0;
    int temp_size = 0;
    int temp_mode = 0;
    int current_num = 0;
    char temp_link_flag ;
    int find = 0;
    char temp; 
    int ct = 0;
    FILE* fp;
    char t_file[512];
    fp = fopen("test.tar", "r");

    while(fscanf(fp, "%c", &temp) ==1 ){
        t_file[ct++] = temp;

        if(ct == 512){
            strncpy(filename, t_file, 100 );
            if (filename[strlen(filename)-1]=='/') filename[strlen(filename)-1]='\0';
            strncpy(mode, t_file + 100, 8 );
            strncpy(uid, t_file + 108, 8 );
            strncpy(gid, t_file + 116, 8 );
            strncpy(fileSize, t_file + 124, 12 );
            strncpy(lastModification, t_file + 136, 12 );
            strncpy(Link_flag, t_file + 156, 1 );
            strncpy(User_name, t_file + 265, 32 );
            strncpy(Group_name, t_file + 297, 32 );
            ct = 0;


            if(! strncmp(path+1, filename, strlen(filename)) && (strlen(path) == (strlen(filename) +1)) ){
                find = 1;

                if(octal_string_to_int(lastModification) > temp_mtime){
                    temp_uid = octal_string_to_int(uid);
                    temp_gid = octal_string_to_int(gid);
                    temp_mtime = octal_string_to_int(lastModification);
                    temp_size = octal_string_to_int(fileSize);
                    temp_mode = octal_string_to_int(mode);
                    temp_link_flag = Link_flag[0];
                    current_num++;
                }
                
                
                // break;
            }
            fseek(fp, (((octal_string_to_int(fileSize)) + 511) & ~511), SEEK_CUR);
        }
    }
    fclose(fp);

    if(find==0) return-ENOENT ;
    memset(st, 0, sizeof(struct stat));
    
    st->st_uid = temp_uid;
    st->st_gid = temp_gid;
    st->st_mtime = temp_mtime;
    st->st_size = temp_size;

    if (strcmp(path, "/") == 0 ){
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    // other directory
    else if (temp_link_flag == '5') {
        st->st_mode = S_IFDIR | temp_mode;
        return 0;
    }
    // file
    else{
        st->st_mode = S_IFREG | temp_mode;
        return 0;
    }
    return -ENOENT ;
}


int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {

    unsigned long int temp_mtime = 0;
    int temp_size = 0;
    int temp_page_num = 0;

    int find = 0;
    char temp; 
    int ct = 0;
    FILE* fp;
    char t_file[512];
    int page_num = 0;
    fp = fopen("test.tar", "r");
    while(fscanf(fp, "%c", &temp) ==1 ){
        t_file[ct++] = temp;
        if(ct == 512){
            page_num++;
            strncpy(filename, t_file, 100 );
            if (filename[strlen(filename)-1]=='/') filename[strlen(filename)-1]='\0';
            strncpy(fileSize, t_file + 124, 12 );
            strncpy(lastModification, t_file + 136, 12 );

            ct = 0;
            if(! strncmp(path+1, filename, strlen(filename)) && (strlen(path) == (strlen(filename) +1)) ){
                find = 1;
                if(octal_string_to_int(lastModification) > temp_mtime){
                    temp_mtime = octal_string_to_int(lastModification);
                    temp_size = octal_string_to_int(fileSize);
                    temp_page_num = page_num;
                }
            }
            fseek(fp, (((octal_string_to_int(fileSize)) + 511) & ~511), SEEK_CUR);
        }
    }
    fclose(fp);
    fp = fopen("test.tar", "r");
    // int fsize = octal_string_to_int(fileSize);
    int s = 0;
    ct = 0;
    while(fscanf(fp, "%c", &temp) ==1 ){
         t_file[ct++] = temp;
        if(ct == 512){
            s++;
            strncpy(filename, t_file, 100 );
            if (filename[strlen(filename)-1]=='/') filename[strlen(filename)-1]='\0';
            strncpy(fileSize, t_file + 124, 12 );
            if(s==temp_page_num) {
                break;
            }
            ct = 0;
            fseek(fp, (((octal_string_to_int(fileSize)) + 511) & ~511), SEEK_CUR);
        }
    }
    if(find == 0) return -ENOENT ;

    int fsize = temp_size;
    char read_file[fsize];
    int count = 0;
    int index = 0;
    while(fscanf(fp, "%c", &temp) == 1 && count < fsize){
        read_file[count++] = temp;
    }
    memcpy(buffer, read_file+offset, size);
    fclose(fp);
    return count>=size? size : size;
}


static struct fuse_operations op;

int main(int argc, char *argv[])

{
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}