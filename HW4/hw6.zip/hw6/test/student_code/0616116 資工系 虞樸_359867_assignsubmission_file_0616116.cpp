/*
Student No.: 0616116
Student Name: Yu Pu
Email: tobyupu@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#include <bits/stdc++.h>
#include <dirent.h>
#include <fuse.h>
#include <string>
#include <unistd.h>

#include <sys/types.h>
#include <typeinfo>
#include <sstream>
using namespace std;

struct myFile{
	string name;
	string data;
	int mode;
	string userName, groupName;
	long long uid, gid;
	long long len;
	long long modifyTime;
	int link;
};


// struct srt{
// 	bool operator()(const myFile &a,const myFile &b){
// 		return a.modifyTime > b.modifyTime;
// 	}
// };

// vector<myFile> allFile;

map<string,myFile> allFile;

char buffer[10000000];

void printFile(myFile f){
	cerr<<"name: "<<f.name<<endl;
	cerr<<"mode: "<<f.mode<<endl;
	// cerr<<"uid: "<<f.uid<<endl;
	// cerr<<"gid: "<<f.gid<<endl;
	// cerr<<"userName: "<<f.userName<<endl;
	// cerr<<"groupName: "<<f.groupName<<endl;
	cerr<<"len: "<<f.len<<endl<<endl;;
	// cerr<<"modifyTime: "<<f.modifyTime<<endl;
	// cerr<<"link: "<<f.link<<endl;
	cerr<<"data: "<<f.data<<endl;
	cerr<<"dataSize "<<f.data.size()<<endl;
}

long long toInt(string s){
	long long x = 0;
	for(int i=0;i<s.size();i++){
		char f = s[i];
		if(f>='0' && f<='9'){
			// cout<<"f "<<int(s[i])<<endl;
			x = x*10 + f - '0';
		}
	}
	return x;
}

string getBuffer(int l,int r,int dKey){
	string ans;
	for(int i=l;i<r;i++){
		// cout<<buffer[i]<<' ';
		if(dKey == 0 && buffer[i] == 0) break;
		ans.push_back(buffer[i]);
	}
	// cout<<"get "<<l<<' '<<r<<" = "<<ans<<endl;
	return ans;

}

long long convert8210(long long x){
	long long ans,tmp;
	stringstream ss;
	ss.clear();
	ss<<x;
	string s;
	s = ss.str();
	tmp = 1;
	ans = 0;
	for(int i=s.size()-1;i>=0;i--){
		ans += tmp * (s[i]-'0');
		tmp *= 8;
	}
	// cout<<x<<" -> "<<ans<<endl;
	return ans;

}

pair<string, string> splitFatherSon(string s){
	int key = 0;
	string father, son;
	for(int i=s.size()-1;i>=0;i--){
		if(i < s.size() - 1 && s[i] == '/' ) key = 1;
		if(key == 1) father.push_back(s[i]);
		else son.push_back(s[i]);
	}
	reverse(father.begin(), father.end());
	reverse(son.begin(), son.end());
	return make_pair(father,son);
}



void readFile(){
	string fileName = "./test.tar";

	ifstream infile(fileName.c_str());

	infile.seekg(0, ios::end);
	size_t length = infile.tellg();
	infile.seekg(0,ios::beg)	;

	cout<<"length = "<<length<<endl;
	if(length > sizeof(buffer)){
		assert(0);
	}

	infile.read(buffer, length);

	// for(int i=0;i<length;i++){
	// 	if(buffer[i] == 'r' && buffer[i+1] == 'e') cout<<"i = "<<i<<endl;
	// 	cout<<buffer[i];

	// }
	// cout<<endl;

	int now = 0;
	while(now < length){
		// cout<<"now = "<<now<<endl;
		myFile nowF;

		nowF.name = getBuffer(now, now+100,0);
		now += 100;

		if(nowF.name.empty()) break;
		nowF.name = "/" + nowF.name;

		nowF.mode = convert8210(toInt(getBuffer(now, now+8,0)));
		now += 8;

		nowF.uid = convert8210(toInt(getBuffer(now,now+8,0)));
		now += 8;

		nowF.gid = convert8210(toInt(getBuffer(now,now+8,0)));
		now += 8;
		// cout<<"len Check "<<getBuffer(now,now+12)<<endl;
		nowF.len = convert8210(toInt(getBuffer(now,now+12,0)));
		now += 12;

		nowF.modifyTime = convert8210(toInt(getBuffer(now,now+12,0)));
		now += 12;
		now += 8;

		nowF.link = toInt(getBuffer(now,now+1,0));
		now += 109;

		nowF.userName = getBuffer(now,now+32,0);
		now+=32;

		nowF.groupName = getBuffer(now,now+32,0);
		now+=32;

		now+= 8 + 8 + 167;

		nowF.data = getBuffer(now, now+nowF.len,1);
		now += nowF.len;

		// cout<<"ccc "<<now<<endl;

		now = (now + 511) / 512 * 512;
		// printFile(nowF);
		if(allFile.find(nowF.name) == allFile.end()){
			allFile[nowF.name] = nowF;
		}
		else{
			if(allFile[nowF.name].modifyTime < nowF.modifyTime){
				allFile[nowF.name] = nowF;
			}
		}
		
	}
}


int myReadDir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {

	// cout<<"readDir "<<path<<endl;
	filler( buffer, ".", NULL, 0 ); // Current Directory
	filler( buffer, "..", NULL, 0 ); // Parent Directory
	map<string,myFile> :: iterator it;
	for(it = allFile.begin(); it!=allFile.end(); it++){
		pair<string,myFile> f = *it;
		// cout<<"hi "<<f.second.name<<endl;
		pair<string, string> pp = splitFatherSon(f.second.name);
		// cout<<f.second.name<<" => "<<pp.first<<" <-> "<<pp.second<<endl;
		if(pp.first == string(path) || pp.first == ( string(path) + "/" )){
			// cout<<"ac "<<endl;
			string fn = pp.second;
			if(fn[fn.size()-1] == '/') fn.resize(fn.size()-1);
			filler(buffer, fn.c_str(), NULL, 0);
		}
	}
	// filler(buffer,pp.second.c_str(),NULL,0);

	return 0;
    
}


int myGetAttr(const char *path, struct stat *st) { 

	// cerr<<"getAttr "<<path<<endl;
	
	if ( strcmp( path, "/" ) == 0 )
	{	
		st->st_mtime = time( NULL );
		// st->st_atime = time(NULL);
		st->st_uid = getuid();
		st->st_gid = getgid();
		st->st_size = 0;
		st->st_mode = S_IFDIR | 0444;
		return 0;
	}
	else {
		map<string,myFile> :: iterator it;
		for(it = allFile.begin(); it!=allFile.end(); it++){
			pair<string,myFile> f = *it;
			// pair<string, string> pp = splitFatherSon(f.second.name);
			// cerr<<"cc "<<f.second.name<<endl;
			if(f.second.name == string(path) || f.second.name == ( string(path) + "/" )){
				// cerr<<"ac"<<endl;
				st->st_mtime = f.second.modifyTime;
				st->st_mode = ( (f.second.name[f.second.name.size()-1] == '/') ? S_IFDIR:S_IFREG) | (int)(f.second.mode);
				// st->st_nlink = 1;
				// st->st_nlink = f.second.link;
				st->st_size = f.second.len;
				st->st_uid = f.second.uid;
				st->st_gid = f.second.gid;
				return 0;
			}
		} 
	}
	
	// return -100;
	return -ENOENT;
}
int myRead(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
	
	map<string,myFile> :: iterator it;
	for(it = allFile.begin(); it!=allFile.end(); it++){
		pair<string,myFile> f = *it;
		if(f.second.name == string(path) || f.second.name == ( string(path) + "/" )){
			// cerr<<"check "<<size<<' '<<((int)f.second.data.length() - offset)<<endl;
			// if((int)(size) > ((int)f.second.data.length() - offset + 1)){
			// 	size = ((int)f.second.data.length() - offset);
			// }
			// if(offset > f.second.data.size()) {
			// 	offset = f.second.data.size();
			// 	// return 0;
			// }
			// cerr<<"hi "<<f.second.data.size()<<' '<<offset<<' '<<size<<endl;
			memcpy(buffer, f.second.data.c_str() + offset, size);
			// cerr<<"hi2"<<' '<<(f.second.data.length()) - offset<<endl;
			return size; //(f.second.data.length()) - offset;
		}
	}
			// memcpy(buffer, f.second.data.c_str() + offset, size);

	return 0;	
	
}

static struct fuse_operations op;

int main(int argc, char *argv[]) {
	readFile();

	memset(&op, 0, sizeof(op));

	op.getattr = myGetAttr;
	op.readdir = myReadDir;
	op.read = myRead;

	return fuse_main(argc, argv, &op, NULL);

}