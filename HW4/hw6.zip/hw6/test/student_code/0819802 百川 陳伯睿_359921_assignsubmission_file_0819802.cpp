/*
Student No.: 0819802
Student Name: 陳伯睿
Email: bryant90424@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <vector>

using namespace std;

class my_file_attr {
private:
public:
    char pathTo[100];
    char file_name[100];
    mode_t file_mode;
	mode_t file_mode_oct;
    uid_t uid;
    gid_t gid;
    off_t file_size;
    time_t modify_time;
    long int header_chechsum;
    char link_flag;
    char link_name[100];
    char magic[8];
    char user_name[32];
    char group_name[32];
    dev_t maj_dev_id;
    dev_t min_dev_id;
    char * content;

    void read_file(FILE * fp) {
        char str[512];
        char *ptr;

        fread(str, 100, 1, fp);
        strcpy(file_name, str);
        printf("file name : %s\n", file_name);
        
        fread(str, 8, 1, fp);
        file_mode = (mode_t)strtol(str, &ptr, 8);
		file_mode_oct = (mode_t)strtol(str, &ptr, 10);
        printf("file mode (oct): %d\n", file_mode_oct);

        fread(str, 8, 1, fp);
        uid = (uid_t)strtol(str, &ptr, 8);
        printf("uid : %d\n", uid);

        fread(str, 8, 1, fp);
        gid = (gid_t)strtol(str, &ptr, 8);
        printf("gid : %d\n", gid);

        fread(str, 12, 1, fp);
        file_size = (off_t)strtol(str, &ptr, 8);
        printf("file size : %ld\n", file_size);

        fread(str, 12, 1, fp);
        modify_time = (time_t)strtol(str, &ptr, 8);
        printf("modify time : %ld\n", modify_time);

        fread(str, 8, 1, fp);
        header_chechsum = (long int)strtol(str, &ptr, 8);
        printf("header checksum : %ld\n", header_chechsum);

        fread(str, 1, 1, fp);
        link_flag = str[0];
        printf("link flag : %c\n", link_flag);

        fread(str, 100, 1, fp);
        strcpy(link_name, str);
        printf("link name : %s\n", link_name);

        fread(str, 8, 1, fp);
        strcpy(magic, str);
        printf("magic : %s\n", magic);

        fread(str, 32, 1, fp);
        strcpy(user_name, str);
        printf("user name : %s\n", user_name);

        fread(str, 32, 1, fp);
        strcpy(group_name, str);
        printf("group name : %s\n", group_name);

        fread(str, 8, 1, fp);
        maj_dev_id = (dev_t)strtol(str, &ptr, 8);
        printf("maj dev id : %lu\n", maj_dev_id);

        fread(str, 8, 1, fp);
        min_dev_id = (dev_t)strtol(str, &ptr, 8);
        printf("min dev id : %lu\n", min_dev_id);

        fread(str, 167, 1, fp);
        printf("padding\n");

        int blockNum = (int)ceil(file_size / 512.0);
        content = (char *)malloc(sizeof(char) * 512 * blockNum);
        //printf("%d\n", blockNum);
        //getchar();

        // char temp;
        // for(int i = 0; i < 512 * blockNum ; i++) {
        //     fread(&temp, 1, 1, fp);
        //     printf("%d\t: %c\t(%d)\n", i, temp, temp);
        // }
        fread(content, 512 * blockNum, 1, fp);
        for(int i = 0; i < file_size ; i++) {
            printf("%c", content[i]);
        }
        printf("\n");
        // printf("content : %s\n", content);

        char tempPath[100];
        for(int i = 0; i < 100; i++) {
            tempPath[i] = '\0';
        }
        strcpy(tempPath, file_name);
        if(tempPath[strlen(tempPath) - 1] == '/') {
            tempPath[strlen(tempPath) - 1] = ' ';
			file_name[strlen(tempPath) - 1] = '\0';
        }
        for(int i = strlen(tempPath); i >= 0; i --) {
			if(tempPath[i] == '/') {
				tempPath[i] = '\0';
                break;
            }
			tempPath[i] = '\0';
        }
        // if(tempPath[0] == '\0') {
        //     tempPath[0] = '/';
        //     tempPath[1] = '\0';
        // }
		tempPath[strlen(tempPath) + 1] = '\0';
		for(int i = strlen(tempPath); i > 0; i--) {
			tempPath[i] = tempPath[i - 1];
		}
		tempPath[0] = '/';
        strcpy(pathTo, tempPath);
        printf("parent name : %s\n", pathTo);

        char tempName[100];
        for(int i = 0; i < 100; i++) {
            tempName[i] = '\0';
        }
        strcpy(tempName, file_name);
        int lastSlashIndex = 0;
        for(int i = 0; i < strlen(tempName); i++) {
            if(tempName[i] == '/' && i != strlen(tempName) - 1) {
                lastSlashIndex = i;
            }
        }
        if(lastSlashIndex == 0) {
            lastSlashIndex--;
        }
        for(int i = lastSlashIndex + 1; i < strlen(tempName); i++) {
            file_name[i - lastSlashIndex - 1] = tempName[i];
            file_name[i - lastSlashIndex] = '\0';
        }
        // getchar();
        // char tempName[100];
        // for(int i = 0; i < 100; i++) {
        //     tempName[i] = '\0';
        // }
        // strcpy(tempName, file_name);
        // for(int i = strlen(tempName); i > 0; i--) {
		// 	tempName[i] = tempName[i - 1];
		// }
		// tempName[0] = '/';
        // tempName[strlen(tempName)] = '\0';
        // strcpy(file_name, tempName);
        return;
    }
};

struct Aname
{
    char name[100];
};


vector<my_file_attr> file_list;

vector<my_file_attr>::iterator search_file_list_name(const char targetPath[100]) {
    vector<my_file_attr>::iterator iter;
    for(iter = file_list.begin(); iter < file_list.end(); iter++) {
        if(strcmp(targetPath, iter->file_name) == 0) {
            return iter;
        }
    }
    return iter;
}

vector<my_file_attr>::iterator search_file_list_name_path(const char targetName[100], const char targetPath[100]) {
    vector<my_file_attr>::iterator iter;
    vector<my_file_attr>::iterator result;
    result = file_list.begin();
    int matchFile = 0;
    for(iter = file_list.begin(); iter < file_list.end(); iter++) {
        if(strcmp(targetName, iter->file_name) == 0 && strcmp(targetPath, iter->pathTo) == 0) {
            if(matchFile == 0) {
                result = iter;
            } else {
                if(iter->modify_time > result->modify_time) {
                    result = iter;
                }
            }
            matchFile++;
        }
    }
    if(matchFile > 0) {
        return result;
    } else {
        return iter;
    }
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    printf( "[readdir] Called\n" );
    printf( "\tGetting The List of Files of %s\n", path );
	
	vector<my_file_attr>::iterator iter;
    vector<Aname> namesGoFiller;
    for(iter = file_list.begin(); iter < file_list.end(); iter++) {
		//printf("%s, %s\n", iter->pathTo, iter->file_name);
        if(strcmp(path, iter->pathTo) == 0) {
            char tempName[100];
            for(int i = 0; i < 100; i++) {
                tempName[i] = '\0';
            }
            strcpy(tempName, iter->file_name);
            // for(int i = 0; i < strlen(tempName); i++) {
            //     tempName[i] = tempName[i + 1];
            // }
            // filler(buffer, tempName, NULL, 0);
			// printf("%s\n", tempName);
            bool existName = false;
            vector<Aname>::iterator nameIter;
            for(nameIter = namesGoFiller.begin(); nameIter < namesGoFiller.end(); nameIter++) {
                if(strcmp(tempName, nameIter->name) == 0) {
                    existName = true;
                }
            }
            if(!existName) {
                Aname newName;
                strcpy(newName.name, tempName);
                namesGoFiller.push_back(newName);
            }
        }
    }
    vector<Aname>::iterator nameIter;
    for(nameIter = namesGoFiller.begin(); nameIter < namesGoFiller.end(); nameIter++) {
        filler(buffer, nameIter->name, NULL, 0);
        printf("%s\n", nameIter->name);
    }
	printf("end readdir\n");
	return 0;
}
int my_getattr(const char *path, struct stat *st) {
    printf( "[getattr] Called\n" );
	printf( "\tAttributes of %s requested\n", path );

    if ( strcmp( path, "/" ) == 0 )
	{
		st->st_uid = getuid();
		st->st_gid = getgid();
		st->st_atime = time(NULL);
		st->st_mtime = time(NULL);
		st->st_mode = S_IFDIR | 0444;
		st->st_nlink = 2;
	} else {
		char tempPath[100];
        for(int i = 0; i < 100; i++) {
            tempPath[i] = '\0';
        }
        strcpy(tempPath, path);
        for(int i = strlen(tempPath); i >= 0; i --) {
			if(tempPath[i] == '/') {
				tempPath[i] = '\0';
                break;
            }
			tempPath[i] = '\0';
        }
        tempPath[strlen(tempPath) + 1] = '\0';
		// for(int i = strlen(tempPath); i > 0; i--) {
		// 	tempPath[i] = tempPath[i - 1];
		// }
		// tempPath[0] = '/';

        
        if(tempPath[0] == '\0') {
            tempPath[0] = '/';
            tempPath[1] = '\0';
        }

        char tempName[100];
        char tempName2[100];
        for(int i = 0; i < 100; i++) {
            tempName[i] = '\0';
            tempName2[i] = '\0';
        }
        strcpy(tempName, path);
        int lastSlashIndex = 0;
        for(int i = 0; i < strlen(tempName); i++) {
            if(tempName[i] == '/' && i != strlen(tempName) - 1) {
                lastSlashIndex = i;
            }
        }
        // if(lastSlashIndex == 0) {
        //     lastSlashIndex--;
        // }

        // for(int i = lastSlashIndex + 1; i < strlen(tempName); i++) {
        //     tempName2[i - lastSlashIndex - 1] = tempName[i];
        //     tempName2[i - lastSlashIndex] = '\0';
        // }
        // tempName = tempName + lastSlashIndex + 1;
        printf("path : %s\n", tempPath);
        printf("name : %s\n", tempName2);
		vector<my_file_attr>::iterator op = search_file_list_name_path(tempName + lastSlashIndex + 1, tempPath);
		if(op == file_list.end()) {
			printf("didn't find %s\n", path);
			return -2;
		} else {
			if(op->link_flag == '5') {
				st->st_uid = op->uid;
				st->st_gid = op->gid;
				st->st_atime = time(NULL);
				st->st_mtime = op->modify_time;
                st->st_size = op->file_size;
				st->st_mode = S_IFDIR | op->file_mode;
			} else {
				st->st_uid = op->uid;
				st->st_gid = op->gid;
				st->st_atime = time(NULL);
				st->st_mtime = op->modify_time;
                st->st_size = op->file_size;
				st->st_mode = S_IFREG | op->file_mode;
			}
			printf("mode : %d\n", st->st_mode);
		}
	}
    return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
    printf( "[read] Called\n" );
    printf( "\tread %s\n", path);

	char tempPath[100];
    for(int i = 0; i < 100; i++) {
        tempPath[i] = '\0';
    }
    strcpy(tempPath, path);
    for(int i = strlen(tempPath); i >= 0; i --) {
        if(tempPath[i] == '/') {
            tempPath[i] = '\0';
            break;
        }
        tempPath[i] = '\0';
    }
    tempPath[strlen(tempPath) + 1] = '\0';
    // for(int i = strlen(tempPath); i > 0; i--) {
    // 	tempPath[i] = tempPath[i - 1];
    // }
    // tempPath[0] = '/';

    
    if(tempPath[0] == '\0') {
        tempPath[0] = '/';
        tempPath[1] = '\0';
    }

    char tempName[100];
    char tempName2[100];
    for(int i = 0; i < 100; i++) {
        tempName[i] = '\0';
        tempName2[i] = '\0';
    }
    strcpy(tempName, path);
    int lastSlashIndex = 0;
    for(int i = 0; i < strlen(tempName); i++) {
        if(tempName[i] == '/' && i != strlen(tempName) - 1) {
            lastSlashIndex = i;
        }
    }
    // if(lastSlashIndex == 0) {
    //     lastSlashIndex--;
    // }

    // for(int i = lastSlashIndex + 1; i < strlen(tempName); i++) {
    //     tempName2[i - lastSlashIndex - 1] = tempName[i];
    //     tempName2[i - lastSlashIndex] = '\0';
    // }
    // tempName = tempName + lastSlashIndex + 1;
    printf("path : %s\n", tempPath);
    printf("name : %s\n", tempName2);
    vector<my_file_attr>::iterator op = search_file_list_name_path(tempName + lastSlashIndex + 1, tempPath);

    if(op != file_list.end()) {
        size_t len = op->file_size;
        if (offset >= len) {
            return 0;
        }

        if (offset + size > len) {
            memcpy(buffer, op->content + offset, len - offset);
            printf("read : \n%s\n", buffer);
            printf("len : %ld\n", len - offset);
            return len - offset;
        }

        memcpy(buffer, op->content + offset, size);
        printf("read : \n%s\n", buffer);
        printf("len : %ld\n", size);
        return size;
    }
    return -1;
	// char *selectedText;
	// if(op == file_list.end()) {
	// 	return 0;
	// } else {
	// 	selectedText = op->content;
	// }
	
	// memcpy( buffer, selectedText + offset, size );
	
    // printf("read : \n%s\n", buffer);
    // printf("size : %ld\n", strlen(buffer));
	// return strlen(buffer);
}

static struct fuse_operations op;

int main(int argc, char *argv[]) {
	FILE *fp;
    if((fp=fopen("test.tar","rb"))==NULL){
        printf("open file error!!\n");
        system("PAUSE");
        exit(0);
    }
    // printf("%d\n", (int)ceil(0 / 512));
    //getchar();
    u_int8_t ch;

    u_int8_t temp[1026];
    while(fread(temp, 1025, 1, fp)) {
        fseek(fp, -1025, SEEK_CUR);
        printf("=======================================================\n");
        my_file_attr Afile;
        Afile.read_file(fp);
        if(strlen(Afile.file_name) == 0) {
            break;
        }
        file_list.push_back(Afile);
        //getchar();
    }
    vector<my_file_attr>::iterator iter;
    for(iter = file_list.begin(); iter < file_list.end(); iter++) {
        printf("%s\t\t==>parent :%s\n", iter->file_name, iter->pathTo);
    }
    getchar();
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}