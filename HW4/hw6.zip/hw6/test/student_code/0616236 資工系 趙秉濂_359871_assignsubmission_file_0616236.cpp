/*
Student No.: 0616236
Student Name: 趙秉濂 ( Chao Ping Lien )s
Email: plchao0415@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not
supposed to be posted to a public server, such as a
public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30

#include <iostream>
#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <vector>
#include <algorithm>
#define DEBUG false

using namespace std;

class mystat{
    public:
        char name[100];
        char * path;
        char * filename;
        char kind;
        int uid, gid, mtime, size, offset, mode; 
        bool operator==(const char* rhs){ return strcmp(this->name, rhs) == 0;}
        mystat(char * name_in, char kind, int uid, int gid , int mtime, int size, int offset, int mode):\
        kind(kind), uid(uid), gid(gid), mtime(mtime), size(size), offset(offset), mode(mode){
            strcpy(name, name_in);
        }
};
FILE *tarfile;
vector<mystat> tarstruct;

char * chsubstr(char * tar, int start, int len, int tarlen = 512){
    if(tarlen < (start + len)){
        char * subbuff = new char[len + 1]();
        memset(subbuff, '\0', len);
        return subbuff;
    }
    char * subbuff = new char[len + 1]();
    memset(subbuff, '\0', len);
    memcpy(subbuff, &(tar[start]), len);
    return subbuff;
}
bool is_ignore(const char *path){
    if(path[0] == '/' && path[1] == '.'){
        return true;
    }
    else{
        if(strcmp(path, "/autorun.inf") == 0){
            return true;
        }
    }
    return false;
}
int my_getattr(const char *path, struct stat *st){
    if(DEBUG) cout << path << " my_getattr" << endl;

    if(strcmp("/", path) == 0){
        st->st_uid = 0;
        st->st_gid = 0;
        st->st_mtime = 0;
        st->st_size = 0;
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    // ignore /autorun.inf and /.*
    else if(strlen(path) >= 2 && is_ignore(path)){
        if(DEBUG) cout << "ignore" << endl;
        st->st_uid = 0;
        st->st_gid = 0;
        st->st_mtime = 0;
        st->st_size = 0;
        st->st_mode = S_IFREG | 0777;
        return 0;
    }
    else{
        // find the file or directory return its attribute
        auto it = find(tarstruct.begin(), tarstruct.begin(), path);
        auto it_pre = find(tarstruct.begin(), tarstruct.end(), path);
        it = it_pre;
        while (it_pre != tarstruct.end()){
            auto it_next = find(it_pre + 1, tarstruct.end(), path);
            if(it_next == tarstruct.end()) break;
            it_pre = it_next;
            if(it->mtime < it_pre->mtime) it = it_pre;
        }
        
        if(it == tarstruct.end()){
            if(DEBUG) cout << "not found" << endl;
            return -ENOENT;
        }
        
        st->st_uid = it->uid;
        st->st_gid = it->gid;
        st->st_mtime = it->mtime;
        st->st_size = it->size;
        if(it->kind == 'd'){
            st->st_mode = S_IFDIR | it->mode;
        }
        else{
            st->st_mode = S_IFREG | it->mode;
        }
        return 0;
    }
    // st_uid, st_gid, st_mtime, st_size and st_mode

    // st_mode of the root directory (“/”) should be set to: S_IFDIR | 0444 (act like a read only directory)
    // Other directories: S_IFDIR | accessMode
    // Regular files: S_IFREG | accessMode

    return 0;
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
    //offset and *fi don't care
    vector<char *> record;
    bool flag = true;
    if(DEBUG) cout << path << " my_readdir" << endl;
    if(strlen(path) > 2 && is_ignore(path)){
        if(DEBUG) cout << "ignore by readdir" << endl;
        return 0;
    }
    else{
        record.clear();
        for(int i=0;i<tarstruct.size();i++){
            if(strcmp(tarstruct[i].path, path) == 0){
                if(DEBUG) cout << tarstruct[i].name << endl;
                int fix = record.size();
                for(int k=0;k<fix;k++){
                    if(DEBUG) cout << "check for" << record[k] << " " << k << endl;
                    if(strcmp(record[k], tarstruct[i].filename) == 0){
                        flag = false;
                        if(DEBUG) cout << "got U" << endl;
                        break;
                    }
                }
                if(flag){
                    record.push_back(tarstruct[i].filename);
                    filler(buffer, tarstruct[i].filename, NULL, 0);
                }
            }
        }
        record.clear();
    }

    return 0;
    // filler(buffer, "hhhhh2", NULL, 0);
     /*do something*/ 
    }
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    if(DEBUG) cout << path << " my_read" << endl;

    auto it = find(tarstruct.begin(), tarstruct.begin(), path);
    auto it_pre = find(tarstruct.begin(), tarstruct.end(), path);
    it = it_pre;
    while (it_pre != tarstruct.end()){
        auto it_next = find(it_pre + 1, tarstruct.end(), path);
        if(it_next == tarstruct.end()) break;
        it_pre = it_next;
        if(it->mtime < it_pre->mtime) it = it_pre;
    }

    if(it == tarstruct.end()){
        if(DEBUG) cout << "NOT expect : can't find file" << endl;
        return 0;
    }
    else{
        if(DEBUG) cout << "got the file " << it->name << " info size:" << it->size << endl;
        FILE * fp = fopen("test.tar", "rb");
        if(fp == NULL) if(DEBUG) cout << "open failed" << endl;
        if(fseek(fp, it->offset+512+offset, SEEK_SET)){
            if(DEBUG) cout << "fseek failed" << endl;
        }
        fread(buffer, size, 1, fp);
        if(DEBUG) cout << "content" << endl << buffer << size << endl;
        fclose(fp);
        if(it->size < size) return it->size;
        return size;
        return 0;
    }
}
void readtar(){
    tarfile = fopen("test.tar", "r");
    if(tarfile == NULL){
        if(DEBUG) cout << "openfile failed" << endl;
    }
    char buffer[512];
    char name[100];
    int offset = 0;
    //count file size
    fseek(tarfile, 0, SEEK_END);
    int sz = ftell(tarfile);
    if(DEBUG) cout << sz << endl;
    
    fseek(tarfile, 0, SEEK_SET);

    int filesize = 0;

    while(offset < sz){
        fread(buffer, 512, 1, tarfile);
        char* name = chsubstr(buffer, 0, 100);
        char addrootname[101];
        addrootname[0] = '/';
        strcpy(&addrootname[1], name);
        int uid, gid, mtime, mode;
        if(strlen(name) != 0){
            if(DEBUG) cout << chsubstr(buffer, 100, 8) << endl;
            if(DEBUG) cout << chsubstr(buffer, 108, 8) << endl;
            if(DEBUG) cout << chsubstr(buffer, 116, 8) << endl;
            if(DEBUG) cout << chsubstr(buffer, 136, 12) << endl;
            if(DEBUG) cout << chsubstr(buffer, 124, 12) << endl;
            mode = stoi(chsubstr(buffer, 100, 8), 0 , 8); 
            uid = stoi(chsubstr(buffer, 108, 8), 0 , 8);
            gid = stoi(chsubstr(buffer, 116, 8), 0 , 8);
            mtime = stoi(chsubstr(buffer, 136, 12), 0 , 8);
            filesize = stoi(chsubstr(buffer, 124, 12), 0 , 8);
            if(DEBUG) cout << "name " << addrootname << endl;
            if(DEBUG) cout << "uid " << uid << endl;
            if(DEBUG) cout << "gid " << gid << endl;
            if(DEBUG) cout << "time " << mtime << endl;
            if(DEBUG) cout << "size " << filesize << endl;
            if(DEBUG) cout << "offset " << offset << endl;
            if(name[strlen(name) - 1] == '/'){
                addrootname[strlen(name)] = '\0';
                if(DEBUG) cout << "directory" << addrootname << endl;
                tarstruct.push_back(*new mystat(addrootname, 'd', uid, gid, mtime, filesize, offset, mode));
            }
            else{
                tarstruct.push_back(*new mystat(addrootname, 'f', uid, gid, mtime, filesize, offset, mode));
            }
        }
        else{
            if(DEBUG) cout << "skip 512 byte" << endl;
        }
        
        // fseek(tarfile, 512, SEEK_CUR);
        if(filesize != 0){
            fread(buffer, 512, 1, tarfile);
            // if(DEBUG) cout << "content " << buffer << endl << endl;
            int remain = 0;
            if(filesize % 512 != 0) remain = 1;
            offset += 512 + ((filesize/512) + remain)*512;
            fseek(tarfile, offset, SEEK_SET);
        }
        else{
            if(DEBUG) cout << endl;
            offset += 512;
        }
        // fseek(tarfile, offset, SEEK_SET);
    }
    if(DEBUG) cout << "filenum" << tarstruct.size() << endl;
    fclose(tarfile);
}
void split_path(){
    if(DEBUG) cout << "start split" << endl;
    for(int i=0;i<tarstruct.size();i++){
        for(int j=strlen(tarstruct[i].name)-1;j>=0;j--){
            if(tarstruct[i].name[j] == '/'){
                if(j == 0){
                    tarstruct[i].path = chsubstr(tarstruct[i].name, 0, 1);
                    tarstruct[i].filename = chsubstr(tarstruct[i].name, 1, strlen(tarstruct[i].name) - 1);
                }
                else{
                    tarstruct[i].path = chsubstr(tarstruct[i].name, 0, j);
                    tarstruct[i].filename = chsubstr(tarstruct[i].name, j+1, strlen(tarstruct[i].name) - j);
                }
                if(DEBUG) cout << tarstruct[i].name << " " << tarstruct[i].path << " " << tarstruct[i].filename << endl; 
                break;      
            }
        }
    }
    if(DEBUG) cout << "end of split" << endl;
}
static struct fuse_operations op;
int main(int argc, char *argv[])
{
    readtar();
    split_path();
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
