/*
Student No.:0510896
Student Name:黃梓熏
Email:s210076@my.cmsh.cyc.edu.tw
SE tag:xnxcxtxuxoxsx
Statement:I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#define SKIP 364

#include <fuse.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>

typedef struct node {
    char name[101];
    int mode;
    int uid;
    int gid;
    long long size;
    long long mtime;
    long long contentOffset;
    int direcOrFile;
    struct node *next;
} NODE;

typedef struct stack {
    int tarDataNum;
    NODE *head;
} STACK;

STACK *tarData;
static struct fuse_operations op;
char *content = NULL;

int my_getattr(const char *path, struct stat *st);
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi);
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi);
void creatStack();
void pushStack(char *name,int mode, int uid, int gid, long long size, long long mtime, int direcOrFile, long long contentOffset);
void getTarData();
void movefp(FILE *fp, long long offset);
int octalToDecimal(int octal);
long long octalToDecimal2(long long octal);
int exponential(int number, int power);
long long atolonglong(char *data);
long long getContent(long long size, long long contentOffset, long long fileOffset, long long buffSize);

int main(int argc, char *argv[]) {
    creatStack();
    getTarData();
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

int my_getattr(const char *path, struct stat *st) {
    NODE *pos;
    int found = 0;
    if (!strcmp(path, "/")) {
        st->st_uid = getuid();
        st->st_gid = getgid();
        st->st_mtime = time(NULL);
        st->st_mode = S_IFDIR | 0444;
    }
    else {
        pos = tarData->head;
        if (pos == NULL) {
            printf("No data in tar file\n");
            return -ENOENT;
        }
        while (pos != NULL) {
            if (!strcmp(path, pos->name)) {
                found = 1;
                break;
            }
            pos = pos->next;
        }
        if (found) {
            st->st_uid = pos->uid;
            st->st_gid = pos->gid;
            st->st_mtime = pos->mtime;
            //directory
            if (pos->direcOrFile) {
                st->st_mode = S_IFDIR | pos->mode;
            }
            //file
            else {
                  st->st_mode = S_IFREG | pos->mode;
                  st->st_size = pos->size;
            }
        }
        else {
            printf("Not found\n");
            return -ENOENT;
        }
    }
    return 0;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    NODE *pos = tarData->head;
    char *substr, *substr2, temp[101];
    int loc, count;
    if (pos == NULL)
        return 0;
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    if (!strcmp(path, "/")) {
        while (pos != NULL) {
            strcpy(temp, pos->name);
            substr = strtok(temp, "/");
            substr2 = strtok(NULL, "/");
            if (substr2 == NULL)
                filler(buffer, substr, NULL, 0);
            pos = pos->next;
        }
    }
    else {
        while (pos != NULL) {
            if (strcmp(pos->name, path))
                if (strstr(pos->name, path) != NULL) {
                    loc = strlen(path);
                    if (pos->name[loc] == '/') {
                        loc++;
                        for (count = loc; count < strlen(pos->name); count++) {
                            if (pos->name[count] == '/')
                                break;
                            temp[count-loc] = pos->name[count];
                        }
                        if (count == strlen(pos->name)) {
                            temp[count-loc] = '\0';
                            filler(buffer, temp, NULL, 0);
                        }
                    }
                }
            pos = pos->next;
        }
    }
    return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
    long long dataSize;
    NODE *pos = tarData->head;
    while (pos != NULL) {
        if (!pos->direcOrFile)
            if (!strcmp(pos->name, path)) {
                if (!pos->size)
                    return 0;
                else
                    break;
            }
        pos = pos->next;
    }
    if (pos == NULL)
        return -ENOENT;
    dataSize = getContent(pos->size-1, pos->contentOffset, (long long)offset, (long long)size);
    for (long long i = 0; i <= dataSize; i++) {
        buffer[i] = content[i];
    }
    return dataSize;
}

void creatStack() {
    tarData = (STACK*)malloc(sizeof(STACK));
    tarData->tarDataNum = 0;
    tarData->head = NULL;
}

void pushStack(char *name,int mode, int uid, int gid, long long size, long long mtime, int direcOrFile, long long contentOffset) {
    NODE *temp;
    temp = (NODE*)malloc(sizeof(NODE));
    strcpy(temp->name, name);
    temp->mode = mode;
    temp->uid = uid;
    temp->gid = gid;
    temp->size = size;
    temp->mtime = mtime;
    temp->direcOrFile = direcOrFile;
    temp->contentOffset = contentOffset;
    temp->next = NULL;
    if (tarData->tarDataNum)
        temp->next = tarData->head;
    tarData->head = temp;
    tarData->tarDataNum++;
}

void getTarData() {
    char name[101], buffer[20];
    int mode, uid, gid, direcOrFile;
    long long mtime, size, offset, contentOffset = 0;

    FILE *fp = NULL;
    fp = fopen("test.tar", "r");
    if (fp == NULL) {
        printf("Tar file opened failed\n");
        exit(0);
    }

    while (fscanf(fp, "%c", &name[1]) != EOF) {
        if (name[1] == '\0') {
            break;
        }
        direcOrFile = 0;
        name[0] = '/';
        for (int i = 2; i <= 100; i++) {
            fscanf(fp, "%c", &name[i]);
            if (name[i] == '\0')
                if (name[i-1] == '/') {
                    name[i-1] = '\0';
                    direcOrFile = 1;
                }
        }
        fscanf(fp, "%s", buffer);
        movefp(fp, 8-strlen(buffer));
        mode = atoi(buffer);
        mode = octalToDecimal(mode);
        fscanf(fp, "%s", buffer);
        movefp(fp, 8-strlen(buffer));
        uid = atoi(buffer);
        uid = octalToDecimal(uid);
        fscanf(fp, "%s", buffer);
        movefp(fp, 8-strlen(buffer));
        gid = atoi(buffer);
        gid = octalToDecimal(gid);
        fscanf(fp, "%s", buffer);
        movefp(fp, 12-strlen(buffer));
        size = atolonglong(buffer);
        size = octalToDecimal2(size);
        fscanf(fp, "%s", buffer);
        movefp(fp, 12-strlen(buffer));
        mtime = atolonglong(buffer);
        mtime = octalToDecimal2(mtime);
        movefp(fp, SKIP);
        contentOffset++;
        if (size) {
            pushStack(name, mode, uid, gid, size, mtime, direcOrFile, contentOffset);
            if (size%512)
                offset = size/512+1;
            else
                offset = size/512;
            movefp(fp, offset*512);
            contentOffset += offset;
        }
        else {
            pushStack(name, mode, uid, gid, size, mtime, direcOrFile, 0);
        }
    }
    fclose(fp);
}

void movefp(FILE *fp, long long offset) { //
    char move;
    for (long long i = 0; i < offset; i++) {
        if (fscanf(fp, "%c", &move) == EOF)
            break;
    }
}

int octalToDecimal(int octal) {
    int decimal = 0, power = 0, digit;
    while (octal) {
        digit = octal%10;
        decimal += digit*exponential(8, power);
        octal /= 10;
        power++;
    }
    return decimal;
}

long long octalToDecimal2(long long octal) {
    long long decimal = 0, digit;
    int power = 0;
    while (octal) {
        digit = octal%10;
        decimal += digit*exponential(8, power);
        octal /= 10;
        power++;
    }
    return decimal;
}

int exponential(int number, int power) {
    int total = 1;
    for (int i = 0; i < power; i++)
        total *= number;
    return total;
}

long long atolonglong(char *data) {
    int count = 0, digit;
    long long sum = 0;
    if (data[count] == '\0')
        return 0;
    do {
            digit = (int)data[count]-(int)'0';
            sum += digit;
            if (data[count+1] != '\0') {
                sum *= 10;
                count++;
            }
            else {
                break;
            }
    } while (1);
    return sum;
}

long long getContent(long long size, long long contentOffset, long long fileOffset, long long buffSize) {
    long long count, dataSize;
    char buf;
    FILE *fp = NULL;
    if (content != NULL)
        free(content);
    content = NULL;
    content = (char*)malloc(sizeof(char)*(size+1));
    fp = fopen("test.tar", "r");
    movefp(fp, contentOffset*512);
    size -= fileOffset;
    if (size <= 0) {
        content[0] = '\0';
        return 0;
    }
    movefp(fp, fileOffset);
    if (size > buffSize)
        dataSize = buffSize;
    else
        dataSize = size;
    for (count = 0; count < dataSize; count++) {
        fscanf(fp, "%c", &buf);
        content[count] = buf;
    }
    content[count] = '\0';
    fclose(fp);
    return dataSize;
}
