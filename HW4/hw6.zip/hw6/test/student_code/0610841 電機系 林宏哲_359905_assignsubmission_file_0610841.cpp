/*
Student No.: 0610841
Student Name: 林宏哲
Email: s94285.eed06@nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30
#define __DEBUG false

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <stdlib.h>
#include <vector>
#include <sys/stat.h>

struct TarHeader{
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char modify[12];
    char headerChecksum[8];
    char linkFlag;
    char padding[512-157-sizeof(long)];
    long contentOffset;//use only for my purpose
}tmp;
typedef std::vector<struct TarHeader> TarFileList;


static int getFileList(TarFileList *tarFileList){
    FILE *fp = fopen("./test.tar","rb");
    if(!fp){fprintf(stderr,"Cannot open file");return -1;}
    while(!feof(fp)&&fread(&tmp,sizeof(TarHeader),1,fp)){
        if(strlen(tmp.name)<1){break;}  //file ends
        //remove / for dir and add ./ for files under root
        if(tmp.name[strlen(tmp.name)-1]=='/')tmp.name[strlen(tmp.name)-1]='\0';
        if(strlen(tmp.name)<3||tmp.name[1]!='/')strcpy(tmp.name,("./"+std::string(tmp.name)).c_str());
        //remove . at the begining
        strcpy(tmp.name,tmp.name+1);
        //add offset
        tmp.contentOffset = ftell(fp);
        //check update
        bool existNew = false;
        for(int i=0;i<tarFileList->size();i++){
            if(strcmp(tmp.name,tarFileList->at(i).name)==0){
                if(strtol(tmp.modify,NULL,8)>=strtol(tarFileList->at(i).modify,NULL,8)){
                    //remove old one
                    tarFileList->erase(tarFileList->begin()+i);
                    break;
                }else{
                    existNew = true;
                    break;
                }
            }
        }
        //add into vector
        if(!existNew)tarFileList->push_back(tmp);
        fseek(fp,(strtol(tmp.size,NULL,8)+511)&~511,SEEK_CUR); //round up to 512*k
    }
    fclose(fp);
};

int my_getattr(const char *path, struct stat *st) {
    if(__DEBUG)printf(" getattr of %s required\n",path);
    TarFileList fileList;
    getFileList(&fileList);
    if(strcmp(path,"/")==0){
        st->st_mode = S_IFDIR | 0444;
        st->st_nlink = 2;
        return 0;
    }else{
        //regular files/directory
        for(TarFileList::const_iterator it = fileList.begin();it != fileList.end();it++){
            if(strcmp(it->name,path)==0){
                st->st_uid = strtol(it->uid,NULL,8);
                st->st_gid = strtol(it->gid,NULL,8);
                st->st_mtime = strtol(it->modify,NULL,8);
                st->st_size = strtol(it->size,NULL,8);
                //regular file
                if(it->linkFlag == '0' || it->linkFlag == '\0')
                    st->st_mode = S_IFREG | strtol(it->mode,NULL,8);
                //sub folder
                if(it->linkFlag == '5')
                    st->st_mode = S_IFDIR | strtol(it->mode,NULL,8);
                return 0;
            }
        }
        if(__DEBUG)printf("File %s not FOUND!!\n",path);
        return -2;  //ENOENT=2
    }
    return 0;
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    if(__DEBUG)printf(" readdir of %s required\n",path);
    TarFileList fileList;
    getFileList(&fileList);
    filler(buffer,".",NULL,0);
    filler(buffer,"..",NULL,0);
    //add / behind path if not there
    char path2[100];
    strcpy(path2,path);
    if(strlen(path2)>1){ //only root has / at the end
        strcat(path2,"/");
    }
    char name[100],dir[100];
    for(TarFileList::const_iterator it = fileList.begin();it != fileList.end();it++){
        if(__DEBUG)puts(it->name);
        //parse dir and name
        strncpy(dir,it->name,strlen(path2));
        dir[strlen(path2)]='\0';
        strcpy(name,it->name+strlen(path2));
        if(strcmp(dir,path2)==0&&strchr(name,'/')==NULL){
            filler(buffer,name,NULL,0);
        }
    }
    return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
    if(__DEBUG)printf(" readcontent of %s required\n",path);
    TarFileList fileList;
    getFileList(&fileList);
    TarFileList::const_iterator it = fileList.begin();
    for(;it != fileList.end();it++){
        if(strcmp(it->name,path)==0){
            //found
            break;
        }
    }
    if(it == fileList.end())return -1;
    FILE *fp = fopen("./test.tar","rb");
    if(!fp){fprintf(stderr,"Cannot open file");return -1;}
    fseek(fp,it->contentOffset+offset,SEEK_SET);
    fread(buffer,size,1,fp);
    return size;
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

