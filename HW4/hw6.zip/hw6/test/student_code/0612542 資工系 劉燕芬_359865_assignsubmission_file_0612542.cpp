/*
Student No.: 0612542
Student Name: 劉燕芬
Email: fandy1632@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/

#define FUSE_USE_VERSION 30
#define  _FILE_OFFSET_BITS 64

#include <fuse.h>
#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <fcntl.h>
#include <assert.h>
#include <list>
#include <errno.h>
#include <sys/time.h>

using namespace std;
struct GnuTarHeader
{
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char chksum[8];
    char typeflag;
    char linkname[100];
    char magic[8];
    char uname[32];
    char gname[32];
    char devmajor[8];
    char devminor[8];
    char prefix[167];
    //char pad[12];
};

void parseFileSize(GnuTarHeader *tarHeader);
void parseFileName(GnuTarHeader *tarHeader);
void parseLongLink(GnuTarHeader *tarHeader, int fd);
void parseTarHeader(GnuTarHeader *tarHeader);

string currentFileName;
unsigned long long currentFileSize;
bool lastLongLinkHeader;
list<GnuTarHeader> untar;

void parseFileSize(GnuTarHeader *tarHeader)
{
    int i;
    currentFileSize = 0;

    if (tarHeader->size[0] & (0X01 << 7)) {// file size > 8 GB.
        for (i=1; i<12; i++) {
            currentFileSize *= 256;
            currentFileSize += tarHeader->size[i];
        }
    } else {// file size < 8 GB.
        for (i=0; i<12; i++) {
            if ((0 == tarHeader->size[i]) || (' ' == tarHeader->size[i])) {continue;}
            currentFileSize *= 8;
            currentFileSize += (tarHeader->size[i] - '0');
        }
    }
}

void parseFileName(GnuTarHeader *tarHeader)
{
    int i;
    char fileName[256];
    currentFileName = "";
    if (0 != tarHeader->prefix[0]) {
        for (i=0; i<167; i++) {
            if (0 == tarHeader->prefix[i]) {break;}
            fileName[i] = tarHeader->prefix[i];
        }
        fileName[i] = '\0';
        currentFileName = fileName;
        currentFileName += "//";
    }

    for (i=0; i<100; i++) {
        if (' ' == tarHeader->name[0]) {break;}
        fileName[i] = tarHeader->name[i];
    }

    fileName[i] = '\0';
    currentFileName += fileName;
}

void parseLongLink(GnuTarHeader *tarHeader, int fd)
{
    int ret;
    char fileName[512+1]; // last byte for '\0''

    currentFileName = "";
    parseFileSize(tarHeader);
    while (true) {
        ret = read (fd, fileName, 512);
        if (currentFileSize > 512) {fileName[512] = '\0';}
        else {
            fileName[currentFileSize] = '\0';
            currentFileName += fileName;
            break;
        }
        currentFileSize -= 512;
        currentFileName += fileName;
    }
    lastLongLinkHeader = true;
}

void parseTarHeader(GnuTarHeader *tarHeader)
{
    parseFileSize(tarHeader);
    if (false == lastLongLinkHeader) {parseFileName(tarHeader);}
    lastLongLinkHeader = false;
    printf ("%s %llu\n", currentFileName.c_str(), currentFileSize);
}

void tarToPath(const char *path,char *name,char* fullname)
{
       int length=strlen(name);
       int pl=strlen(path);

       if(name[length-1]=='/')
           strncat(fullname,name,length-1);
       else if(name[length-1]!='/') strcat(fullname,name);

}

bool dirToFile(const char *dir,char *pathname,char* fullname)
{
       int length=strlen(pathname);
       int pl=strlen(dir),pc=0,a=0,b=0;

       //cout<<"dir vs pathname:"<<dir<<" vs "<<pathname<<endl;

       for(int i=0;i<pl;i++){
            if(dir[i]==pathname[i]) pc++;
            if(dir[i]=='/') a++;
       }
       b=a;
       for(int i=pc;i<length;i++) {if(pathname[i]=='/') b++;}

       if(pc==pl&&strcmp(dir,"/")==0&&b==a){
          int j=0;
          for(int i=pc;i<length;i++) {fullname[j]=pathname[i];j++;}
          fullname[j]='\0';
          //cout<<"tarToFile: "<<fullname<<endl;
          return true;
       }else if(pc==pl&&b==(a+1)&&pathname[pc]=='/'){
          int j=0;
          pc++;
          for(int i=pc;i<length;i++) {fullname[j]=pathname[i];j++;}
          fullname[j]='\0';
          //cout<<"tarToFile: "<<fullname<<endl;
          return true;
       }else return false;

}

static fuse_operations operations;

static int do_getattr( const char *path, struct stat *st )
{
	printf( "[getattr] Called\n" );
	printf( "\tAttributes of %s requested\n", path );

	//int check=0,check2=0;

	list<GnuTarHeader>::iterator itr;

	if ( strcmp( path, "/" ) == 0 ){
	          st->st_uid =geteuid();
	          st->st_gid = getgid();
              st->st_mtime = time(NULL);
		      st->st_mode = S_IFDIR | 0644;
		      //check2++;
		      return 0;
    }else{
        for(itr=untar.begin();itr!=untar.end();itr++){

              char fullname[100]="/";
              cout<<"itr->name: "<<itr->name<<endl;
              tarToPath(path,itr->name,fullname);
              if(strcmp(fullname,path)==0){
              //check++;
              cout<<"getattr fullname: "<<fullname<<endl;
	          if((*itr).typeflag=='5') st->st_mode = S_IFDIR | strtol((*itr).mode,NULL,8);
	          else st->st_mode = S_IFREG | strtol((*itr).mode,NULL,8);
              st->st_uid =strtol((*itr).uid,NULL,8);
              st->st_gid = strtol((*itr).gid,NULL,8);
	          st->st_mtim.tv_sec = strtol((*itr).mtime,NULL,8);
              parseTarHeader(&*itr);
		      st->st_size =currentFileSize;
		      return 0;
          }
       }
    }
    //printf("done do_getattr check:%d check2:%d\n",check,check2);

    if(itr==untar.end()) return -2;
}

static int do_readdir( const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi )
{
	printf( "--> Getting The List of Files of %s\n", path );

	filler( buffer, ".", NULL, 0 ); // Current Directory
	filler( buffer, "..", NULL, 0 ); // Parent Directory

	list<GnuTarHeader>::iterator itr;

    for(itr=untar.begin();itr!=untar.end();itr++){
              char fullname2[100]="/";
              tarToPath(path,itr->name,fullname2);
              char filename[100];
              if(dirToFile(path,fullname2,filename)){
                 cout<<"readdir filename: "<<filename<<endl;
                 filler( buffer, filename, NULL, 0 );
              }
    }
    printf("done do_readdir\n");

	return 0;
}


const char* dxTarRead(const void* tarData, const long tarSize,const char* fileName, long* fileSize, GnuTarHeader *tarHeader)
{
	    const int NAME_OFFSET = 0, SIZE_OFFSET = 124;
	    const int BLOCK_SIZE = 512, NAME_SIZE = 100,SZ_SIZE = 12;
	    const char* tar = (const char*) tarData;
	    long Size=0, mul, i, p = 0, found = 0, newOffset = 0;

	    *fileSize = 0;
	    do {
	        const char* name = tar + NAME_OFFSET + p + newOffset;
	        cout<<"do read name:"<<name<<endl;
	        const char* sz = tar + SIZE_OFFSET + p + newOffset;
	        p += newOffset;
	        cout<<"point tar location: "<<p<<endl;

            Size = 0;
	        for(i=SZ_SIZE-2, mul=1; i>=0; mul*=8, i--)
	            if( (sz[i]>='0') && (sz[i] <= '9') ) Size += (sz[i] - '0') * mul;

            cout<<"do read size:"<<Size<<endl;

	        newOffset = (1 + Size/BLOCK_SIZE) * BLOCK_SIZE;
	        printf("newOffset1: %ld\n",newOffset);
	        if( (Size % BLOCK_SIZE) > 0 ) newOffset += BLOCK_SIZE;
	        printf("newOffset2: %ld\n",newOffset);

	        i = 0;
	        while((i<NAME_SIZE) && (fileName[i]!='\0') && (name[i]==fileName[i])) i++;
	        if( (i > 0) && (name[i] == '\0') && (fileName[i] == '\0') ) found = 1;

	    } while( !found && (p + newOffset + BLOCK_SIZE <= tarSize) );

	    if( found ){
	        *fileSize = Size;
	        return tar + p + BLOCK_SIZE; // /* skip header, point to data
	    } else return 0; //  /* No file found in TAR - return NULL
}

void pathToFile(char* pathname,char* fullname)
{
    int pl=strlen(pathname);
    int a=0;
    for(int i=0;i<pl;i++) if(pathname[i]=='/') a++;

    int j=0;
    for(int i=0;i<pl;i++){
        if(a==0){fullname[j]=pathname[i];j++;}
        if(pathname[i]=='/') a--;
    }
    fullname[j]='\0';

}


static int do_read( const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi )
{
	printf( "--> Trying to read %s, %u, %u\n", path, (unsigned int)offset,  (unsigned int)size );

	const char *selectedText;
	list<GnuTarHeader>::iterator itr;
	long fsize, mysize=0;
    char* data;
    FILE* f;

    f = fopen("test.tar", "rb");
	fseek(f, 0, SEEK_END);
	fsize = ftell(f);
	cout<<"tarSize: "<<fsize<<endl;
	fseek(f, 0, SEEK_SET);
	data = (char*) malloc(fsize+1);
	int bytes_read = fread(data, 1, fsize, f);
    if( bytes_read != fsize ){
	        puts("File was not read correctly!");
	        free(data);
	        return -1;
    }
	fclose(f);

	data[fsize] = '\0';

	for(itr=untar.begin();itr!=untar.end();itr++){
	      char fullname[100]="/";
	      tarToPath(path,itr->name,fullname);

	      if(strcmp(path,fullname)==0){
	          selectedText = dxTarRead(data, fsize,itr->name, &mysize,&*itr);
	          memcpy( buffer, selectedText+offset, size );
                  cout<<strlen(buffer)<<endl;
	          break;
	      }
	}
    if(itr!=untar.end())
	    return std::min(mysize-offset,(long)size);
    else return -1;
}

int main( int argc, char *argv[] )
{
    int fd,ret,emptyHeaders = 0;
    unsigned long long seek;
    GnuTarHeader gnuHeader, emptyHeader;

    fd = open("test.tar", O_RDONLY);
    assert (fd != -1);
    memset (&emptyHeader, 0, 512);

    while (1) {
        ret = read(fd, &gnuHeader, 512);
        assert(ret == 512);
        if (0 == memcmp(&gnuHeader, &emptyHeader, 512)) {
            emptyHeaders ++;
            if (2 == emptyHeaders) {break;}
            continue;
        }
        emptyHeaders = 0;
        if ('L' == gnuHeader.typeflag) {parseLongLink(&gnuHeader, fd);}
        else {
            parseTarHeader(&gnuHeader);
            seek = (currentFileSize/512) + (currentFileSize%512 ? 1 : 0);
            seek *= 512;
            seek = lseek(fd, seek, SEEK_CUR);
            assert((int)seek != -1);
        }
        untar.push_back(gnuHeader);
    }

    operations.getattr= do_getattr;
    operations.readdir= do_readdir;
    operations.read= do_read;

	return fuse_main( argc, argv, &operations, NULL );
}
