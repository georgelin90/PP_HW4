/*
Student No.: 0610015
Student Name: Tsai Yueh feng
Email: yuehyueh24.eecs06@cntu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#include <iostream>
#include <fuse.h>
#include <string.h>
#include <string>
#include <errno.h>
#include <vector>
#include <fstream>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
using namespace std;

vector<char*> hello_str;

struct array{
	char arr[100];
	char linkname[100];
	long long modifytime;
	int uid;
	int gid;
	int mode;
	long long s;
	char link;
};
vector<array> hello_path;
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
//	cout << "readdir called\n";
//	printf("dir of %s is read\n", path);
	if(strcmp(path, "/") != 0)
		return -ENOENT;
	filler(buffer, ".", NULL, 0);
	filler(buffer, "..", NULL, 0);
	
	for(int i = 0; i < hello_path.size(); i++)
	{
		int count = 0;
		for(int j = 1; j < 100; j++)
		{
			if(hello_path[i].arr[j] == '/')	count++;
		}
		if(count > 1) break;
//		cout << hello_path[i].arr << endl;
		filler(buffer, hello_path[i].arr + 1, NULL, 0);
	}
	return 0;
}

int my_getattr(const char *path, struct stat *st){
	int res = 0;
//	cout << "getattr called\n";
//	printf("attr of %s requested\n", path);
//	memset(st, 0, sizeof(struct stat));
	for(int i = 0; i < hello_path.size(); i++)
	{
//		cout << hello_path[i].link << endl;
		if(strcmp(path, "/") == 0)
		{
			st->st_uid = getuid();
			st->st_gid = getgid();
			st->st_mtime = time(NULL);
			st->st_mode = S_IFDIR | 0444;
			st->st_nlink = 2;
			return 0;
		}
		else if(strcmp(path, hello_path[i].arr) == 0)
		{
			if(hello_path[i].link == '5')
			{
		
				st->st_mode = S_IFDIR | hello_path[i].mode;
				//st->st_nlink;
				st->st_size = strlen(hello_str[i]);
				st->st_mtime = hello_path[i].modifytime;
				st->st_uid = hello_path[i].uid;
				st->st_gid = hello_path[i].gid;
				return 0;
			}
			//st->st_mode = S_IFREG | 0444;
			st->st_mode = S_IFREG | hello_path[i].mode;
			st->st_nlink = 1;
			st->st_size = hello_path[i].s;//strlen(hello_str[i]);
			st->st_mtime = hello_path[i].modifytime;
			st->st_uid = hello_path[i].uid;
			st->st_gid = hello_path[i].gid;
			return 0;
		}
//		else
//			res = -ENOENT;
	}
	return -ENOENT;
//	return res;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
//	cout << "read is called " << endl;
	for(int i = 0; i < hello_path.size(); i++)
	{
		if(strcmp(path, hello_path[i].arr) == 0)
		{
			
			size_t len;
			//len = strlen(hello_str[i]);
			len = hello_path[i].s;
			if(offset < len){
				if(offset + size > len)
					size = len - offset;
				memcpy(buffer, hello_str[i] + offset, size);
			}
			else
				size = 0;
		
//			cout << "actual size" << hello_path[i].s << "\toffset" << offset << "\tsize" << size << endl;
			return size;
		}
	}
	return -ENOENT;
}

static struct fuse_operations op;
struct tarformat{
	long long s;
	long long mtime;
	long long uid;
	long long gid;
	int mode;
	char link;
	char filename[100];
	char filemode[8];
	char userid[8];
	char groupid[8];
	char filesize[12];
	char modifytime[12];
	char headerchecksum[8];
	char linkflag;
	char linkname[100];
	char magic[8];
	char username[32];
	char groupname[32];
	char majorid[8];
	char minorid[8];
	char *content;
	long long nextindex;
};
int main(int argc, char *argv[])
{
	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	ifstream tar;
	tar.open("./test.tar");
	tar.seekg(0, tar.end);
	int length = tar.tellg();
	tar.seekg(0, tar.beg);
	char *buffer = new char [length];
	tar.read(buffer, length);
		
	cout << "reading " << length << " characters.." << endl;
/*
	char filename[100];
	char filemode[8];
	char userid[8];
	char groupid[8];
	char filesize[12];
	char modifytime[12];
	char headerchecksum[8];
	char linkflag;
	char linkname[100];
	char magic[8];
	char username[32];
	char groupname[32];
	char majorid[8];
	char minorid[8];
*/
	vector<tarformat> tarfile;
	//tarfile.push_back();
	int k = 0;
	long long nextindex = 0;
	while(1)
	{
		tarformat temp;
		int i = 0;
		tar.seekg(100 + nextindex, tar.beg);
		tar >> oct >> temp.mode;
		tar.seekg(124 + nextindex, tar.beg);	
		tar >> oct >> temp.s;
		tar.seekg(136 + nextindex, tar.beg);
		tar >> oct >> temp.mtime;
		tar.seekg(108 + nextindex, tar.beg);
		tar >> oct >> temp.uid;
		tar.seekg(156 + nextindex, tar.beg);
		tar >> temp.link;
		tar.seekg(116 + nextindex, tar.beg);
		tar >> oct >> temp.gid;
//		cout << temp.s << endl;		
		for(int j = 0; i < 100; i++)
			temp.filename[j++] = buffer[i + nextindex];
		
		if(temp.filename[1] == '\0') break;
		cout << temp.filename << '\t' << temp.s << endl << endl;

		for(int j = 0; i < 108; i++)
			temp.filemode[j++] = buffer[i + nextindex];
		for(int j = 0; i < 116; i++)
			temp.userid[j++] = buffer[i + nextindex];
		for(int j = 0; i < 124; i++)
			temp.groupid[j++] = buffer[i + nextindex];
		for(int j = 0 ; i < 136; i++)
			temp.filesize[j++] = buffer[i + nextindex];
		for(int j = 0; i < 148; i++)
			temp.modifytime[j++] = buffer[i + nextindex];
		for(int j = 0; i < 156; i++)
			temp.headerchecksum[j++] = buffer[i + nextindex];
		for(int j = 0; i < 157; i++)
			temp.linkflag = buffer[i + nextindex];
		for(int j = 0; i < 257; i++)
			temp.linkname[j++] = buffer[i + nextindex];
		for(int j = 0; i < 265; i++)
			temp.magic[j++] = buffer[i + nextindex];
		for(int j = 0; i < 297; i++)
			temp.username[j++] = buffer[i + nextindex];
		for(int j = 0; i < 329; i++)
			temp.groupname[j++] = buffer[i + nextindex];
		for(int j = 0; i < 337; i++)
			temp.majorid[j++] = buffer[i + nextindex];
		for(int j = 0; i < 345; i++)
			temp.minorid[j++] = buffer[i + nextindex];
		
		temp.content = new char[temp.s];
		for(int i = 512; i < 512 + temp.s; i++)
			temp.content[i - 512] = buffer[i + nextindex];
		
		temp.nextindex = (((temp.s) + 511) & ~511);
		nextindex += temp.nextindex;
		nextindex += 512;		
//		cout << nextindex << endl;
		
		tarfile.push_back(temp);
		if(nextindex == length) break;
		//k++;
	}
	hello_path.resize(tarfile.size());
	hello_str.resize(tarfile.size());
	for(int i = 0; i < hello_path.size(); i++)
	{
		hello_path[i].arr[0] = '/';		
	}
	for(int k = 0; k < tarfile.size(); k++)
	{
	//	for(int i = 0; i < 99; i++)
	//		cout << tarfile[k].filename[i];
	//	cout << endl;
		for(int i = 0; i < 99; i++){
			hello_path[k].arr[i + 1] = tarfile[k].filename[i];
			hello_path[k].linkname[i] = tarfile[k].linkname[i];
		}
//		for(int i = 0; i < 12; i++)
		hello_path[k].uid = tarfile[k].uid;
		hello_path[k].gid = tarfile[k].gid;
		hello_path[k].s = tarfile[k].s;
		hello_path[k].link = tarfile[k].link;
		hello_path[k].modifytime = tarfile[k].mtime;
		hello_path[k].mode = tarfile[k].mode;
		hello_str[k] = tarfile[k].content;
//		for(int i = 0; i < 100; i++)
//			cout << hello_path[k].arr[i];

	}

//for(int i = 0; i < 99; i++)
//	hello_path[i + 1] = filename[i];

//	hello_str = content;
//for(int i = 0; i < 100; i++)	cout << hello_path[i];
//for(int j = 0; j < s; j++)
//cout << content[j];
//cout << endl;
//	long long nextindex = (((s) + 511) & ~511);
//	for(int i = 0; i < length; i++)
//		cout << buffer[i];
//	cout << endl;
//	return 0;
	return fuse_main(argc, argv, &op, NULL);
}
