/*
Student No.: 0616036
Student Name: Peng Chen(Chronos)
Email: nakamurawk10@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/

#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#include <sys/xattr.h>

static const char *filepath = "/test.tar";
static const char *filename = "test.tar";
static const char *filecontent = "";

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi)
{
    /*do something*/ 
    (void) offset;
    (void) fi;

    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);

    filler(buffer, filename, NULL, 0);

    return 0;
}

int my_getattr(const char *path, struct stat *st) 
{ 
    /*do something*/ 
    memset(st, 0, sizeof(struct stat));

    if (strcmp(path, "/") == 0) {
        st->st_mode = S_IFDIR | 0755;
        st->st_nlink = 2;
        return 0;
    }

    if (strcmp(path, filepath) == 0) {
        st->st_mode = S_IFREG | 0777;
        st->st_nlink = 1;
        st->st_size = strlen(filecontent);
        return 0;
    }

    return -ENOENT;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi)
{
    /*do something*/ 
    if (strcmp(path, filepath) == 0) {
        size_t len = strlen(filecontent);
        
        if (offset >= len) {
        return 0;
        }

        if (offset + size > len) {
        memcpy(buffer, filecontent + offset, len - offset);
        return len - offset;
        }

        memcpy(buffer, filecontent + offset, size);
        return size;
    }

    return -ENOENT;
}

static struct fuse_operations op;

int main(int argc, char *argv[])
{
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}