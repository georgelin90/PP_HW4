/*
 * Student No.: 0616074
 * Student Name: 李睦樂
 * Email: s094392@gmail.com
 * SE tag: xnxcxtxuxoxsx
 * Statement: I am fully aware that this program is not supposed to be
 * posted to a public server, such as a public GitHub repository or a public
 * web page.
 * */

#define FUSE_USE_VERSION 30
#include <bits/stdc++.h>
#include <fuse.h>

using namespace std;

#define ASCII_TO_NUMBER(num) \
    ((num)-48)  // Converts an ascii digit to the corresponding number (assuming
                // it is an ASCII digit)

map<string, vector<string> > file_list;
map<string, char*> file_content;
map<string, struct stat*> file_stat;

static uint64_t decodeTarOctal(char *data, size_t size = 12) {
    unsigned char *currentPtr = (unsigned char *)data + size;
    uint64_t sum = 0;
    uint64_t currentMultiplier = 1;
    unsigned char *checkPtr =
        currentPtr;  // This is used to check where the last NUL/space char is
    for (; checkPtr >= (unsigned char *)data; checkPtr--) {
        if ((*checkPtr) == 0 || (*checkPtr) == ' ') {
            currentPtr = checkPtr - 1;
        }
    }
    for (; currentPtr >= (unsigned char *)data; currentPtr--) {
        sum += ASCII_TO_NUMBER(*currentPtr) * currentMultiplier;
        currentMultiplier *= 8;
    }
    return sum;
}

struct TARFileHeader {
    char filename[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char fileSize[12];
    char lastModification[12];
    char checksum[8];
    char typeFlag;
    char linkedFileName[100];
    char ustarIndicator[6];  //"ustar" -- 6th character might be NUL but results
                             // show it doesn't have to
    char ustarVersion[2];    // 00
    char ownerUserName[32];
    char ownerGroupName[32];
    char deviceMajorNumber[8];
    char deviceMinorNumber[8];
    char filenamePrefix[155];
    char padding[12];

    bool isUSTAR() { return (memcmp("ustar", ustarIndicator, 5) == 0); }

    size_t getFileSize() { return decodeTarOctal(fileSize); }

    bool checkChecksum() {
        char originalChecksum[8];
        memcpy(originalChecksum, checksum, 8);
        memset(checksum, ' ', 8);
        int64_t unsignedSum = 0;
        int64_t signedSum = 0;
        for (int i = 0; i < sizeof(TARFileHeader); i++) {
            unsignedSum += ((unsigned char *)this)[i];
            signedSum += ((signed char *)this)[i];
        }
        memcpy(checksum, originalChecksum, 8);
        uint64_t referenceChecksum = decodeTarOctal(originalChecksum);
        return (referenceChecksum == unsignedSum ||
                referenceChecksum == signedSum);
    }
};

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    string filepath = string(path);
    cout<<"read: "<<filepath<<" offset: "<<offset<<" size: "<<size<<endl;
    memcpy(buffer, file_content[filepath] + offset, size);
    return size;
}


int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler,
            off_t offset, struct fuse_file_info *fi) {
    cout<<"readdir: "<<path<<endl;
    string filepath = string(path);
    if (filepath == "/") {
        for (int i=0; i<file_list[filepath].size(); i++){
            filler(buffer, file_list[filepath][i].c_str() + filepath.size(), NULL, 0);
            cout<<"return: "<<file_list[filepath][i].c_str() + filepath.size()<<endl;
        }
    }
    else{
        filepath += "/";
        for (int i=0; i<file_list[filepath].size(); i++){
            filler(buffer, file_list[filepath][i].c_str() + filepath.size(), NULL, 0);
            cout<<"return: "<<file_list[filepath][i].c_str() + filepath.size()<<endl;
        }
    }
    return 0;
}

int my_getattr(const char* path, struct stat *st) {
    memset(st, 0, sizeof(struct stat));
    string filename = string(path);
    cout<<"getattr: "<<filename<<endl;
    if(strcmp(path, "/") == 0){
        cout<<"return root"<<endl;
        st->st_mode = S_IFDIR | 0444;
        return 0;
    }
    else if (file_stat.find(filename) != file_stat.end()){
        st->st_mode = file_stat[filename]->st_mode | S_IFREG;
        st->st_uid = file_stat[filename]->st_uid;
        st->st_gid = file_stat[filename]->st_gid;
        st->st_size = file_stat[filename]->st_size;
        st->st_mtime = file_stat[filename]->st_mtime;
        return 0;
    }
    else if (file_stat.find(filename + "/") != file_stat.end()){
        filename = filename + "/";
        st->st_mode = file_stat[filename]->st_mode | S_IFDIR;
        st->st_uid = file_stat[filename]->st_uid;
        st->st_gid = file_stat[filename]->st_gid;
        st->st_size = file_stat[filename]->st_size;
        st->st_mtime = file_stat[filename]->st_mtime;
        return 0;
    }
    else{
        cout<<"nofile"<<endl;
        return -ENOENT;
    }
}

static struct fuse_operations op;


int main(int argc, char **argv) {
    ifstream file("test.tar", ios::in|ios::binary|ios::ate);
    file.seekg (0, ios::beg);
    string filename("test.tar");
    char zeroBlock[512];
    memset(zeroBlock, 0, 512);

    bool nextEntryHasLongName = false;


    while (1) {
        TARFileHeader currentFileHeader;
        file.read((char *)&currentFileHeader, 512);
        if (memcmp(&currentFileHeader, zeroBlock, 512) == 0) {
            cout << "Found TAR end\n";
            break;
        }
        string filename(currentFileHeader.filename,
                        min((size_t)100, strlen(currentFileHeader.filename)));
        size_t prefixLength = strlen(currentFileHeader.filenamePrefix);
        if (prefixLength > 0) {
            filename = string(currentFileHeader.filenamePrefix,
                              min((size_t)155, prefixLength)) +
                       "/" + filename;
        }
        filename = "/" + filename;
        if (currentFileHeader.typeFlag == '0' ||
            currentFileHeader.typeFlag == 0) {  // Normal file
            if (nextEntryHasLongName) {
                filename = string(currentFileHeader.filename);
                file.read((char *)&currentFileHeader, 512);
                nextEntryHasLongName = false;
            }
            size_t size = currentFileHeader.getFileSize();

            char *fileData =
                new char[size + 1];  //+1: Place a terminal NUL to allow
                                     // interpreting the file as cstring
                                     // (you can remove this if unused)
            file.read(fileData, size);
            size_t paddingBytes =
                (512 - (size % 512)) %
                512;  // How long the padding to 512 bytes needs to be
            file.ignore(paddingBytes);

            if(file_content.find(filename) != file_content.end()) {
                if(decodeTarOctal(currentFileHeader.lastModification) < file_stat[filename]->st_mtime) {
                    continue;
                }
            }

            file_content[filename] = fileData;

            file_stat[filename] = new struct stat;
            file_stat[filename]->st_uid = decodeTarOctal(currentFileHeader.uid);
            file_stat[filename]->st_gid = decodeTarOctal(currentFileHeader.gid);
            file_stat[filename]->st_mtime = decodeTarOctal(currentFileHeader.lastModification);
            file_stat[filename]->st_mode = decodeTarOctal(currentFileHeader.mode);
            file_stat[filename]->st_size = size;

            string dir = filename.substr(0, filename.find_last_of("/") + 1);
            cout << filename << " " << dir << endl;
            if(find(file_list[dir].begin(), file_list[dir].end(), filename) == file_list[dir].end())
                file_list[dir].push_back(filename);
        }
        else if(currentFileHeader.typeFlag == '5' || currentFileHeader.typeFlag == 5) {
            if (nextEntryHasLongName) {
                filename = string(currentFileHeader.filename);
                file.read((char *)&currentFileHeader, 512);
                nextEntryHasLongName = false;
            }
            size_t size = currentFileHeader.getFileSize();

            char *fileData =
                new char[size + 1];  //+1: Place a terminal NUL to allow
                                     // interpreting the file as cstring
                                     // (you can remove this if unused)
            file.read(fileData, size);

            size_t paddingBytes =
                (512 - (size % 512)) %
                512;  // How long the padding to 512 bytes needs to be

            file.ignore(paddingBytes);

            if(file_content.find(filename) != file_content.end()) {
                if(decodeTarOctal(currentFileHeader.lastModification) < file_stat[filename]->st_mtime) {
                    continue;
                }
            }

            file_content[filename] = fileData;

            file_stat[filename] = new struct stat;
            file_stat[filename]->st_uid = decodeTarOctal(currentFileHeader.uid);
            file_stat[filename]->st_gid = decodeTarOctal(currentFileHeader.gid);
            file_stat[filename]->st_mtime = decodeTarOctal(currentFileHeader.lastModification);
            file_stat[filename]->st_mode = decodeTarOctal(currentFileHeader.mode);
            file_stat[filename]->st_size = size;


            string dir = filename.substr(0, filename.substr(0, filename.size() - 1).find_last_of("/") + 1);
            cout << filename << " " << dir << endl;
            if(find(file_list[dir].begin(), file_list[dir].end(), filename.substr(0, filename.size() - 1)) == file_list[dir].end())
                file_list[dir].push_back(filename.substr(0, filename.size() - 1));
        }
    }


    file.close();
    op.readdir = my_readdir;
    op.getattr = my_getattr;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
