/*
Student No.: 0616316
Student Name: 郭勁辰
Email: kbpsolrz.cs06@nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30

#ifndef __APPLE__

#include <fuse/fuse.h>

#endif

#include <cstdio>
#include <cstring>
#include <cerrno>
#include <fcntl.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>

#define existin(element, container) (container.find(element) != container.end())

using namespace std;

namespace filesystem {
    const char sep = '/';

    string getFileName(const string &s) {
        size_t i = s.rfind(sep, s.length());
        if (i != string::npos) {
            return (s.substr(i + 1, s.length() - i));
        }

        return s;
    }

    string getPath(const string &s) {
        size_t i = s.rfind(sep, s.length());
        if (i != string::npos) {
            return (s.substr(0, i));
        }

        return ("");
    }
}

namespace tar {

    namespace CONST {
        const auto TMAGIC = "ustar";        /* ustar and a null */
        const int block_size{512};
        set<char> typeflag_record = {'0','\0','5'};

        typedef struct posix_header {                                     /* byte offset */
            char name[100];               /*   0 */
            char mode[8];                 /* 100 */
            char uid[8];                  /* 108 */
            char gid[8];                  /* 116 */
            char size[12];                /* 124 */
            char mtime[12];               /* 136 */
            char chksum[8];               /* 148 */
            char typeflag;                /* 156 */
            char linkname[100];           /* 157 */
            char magic[6];                /* 257 */
            char version[2];              /* 263 */
            char uname[32];               /* 265 */
            char gname[32];               /* 297 */
            char devmajor[8];             /* 329 */
            char devminor[8];             /* 337 */
            char prefix[155];             /* 345 */
            /* 500 */
        } tar_posix_header;
    }

    namespace var {
        FILE *file;
        size_t size;
        map<string, set<string>> dir_content;
        map<string, size_t> file_in_tar_addrs;
        map<string, size_t> files_size;
        map<string, time_t> files_mtime;
        map<string, uid_t> files_uid;
        map<string, gid_t> files_gid;
        map<string, mode_t> files_mode;
        char tar_path[] = "./test.tar";
    }

    namespace Pfunction{

        void read_tar_attr(const CONST::tar_posix_header *header, size_t pos, size_t file_size, const string &cur_file) {
            var::files_size[cur_file] = file_size;
            var::file_in_tar_addrs[cur_file] = pos;
            var::files_mtime[cur_file] = strtoul(header->mtime, nullptr, 8);
            var::files_uid[cur_file] = strtoul(header->uid, nullptr, 8);
            var::files_gid[cur_file] = strtoul(header->gid, nullptr, 8);
            var::files_mode[cur_file] = strtoul(header->mode, nullptr, 8);
        }

        string &remove_unnecssary_slash(string &cur_file) {
            if (cur_file.back() == '/')
                cur_file = cur_file.substr(0, cur_file.size() - 1);
            return cur_file;
        }

        basic_string<char, char_traits<char>, allocator<char>> remove_first_slash(const char *path) {
            string pathstr = path;
            auto strip_path = pathstr.substr(1, pathstr.size() - 1);
            return strip_path;
        }
    }

    bool IsValidTarFile() {
        if (!var::file) {
            fprintf(stderr, "File is not exist\n");
            return false;
        }

        unsigned char buf[CONST::block_size];
        auto *header = (CONST::tar_posix_header *) buf;
        memset(buf, 0, CONST::block_size);

        fseek(var::file, 0, SEEK_END);
        var::size = ftell(var::file);
        fseek(var::file, 0, SEEK_SET);
        if (var::size % CONST::block_size != 0) {
            return false;
        }

        size_t pos{0};

        while (true) {
            size_t read_size = fread(buf, CONST::block_size, 1, var::file);
            if (read_size != 1) break;
            if (header->magic == CONST::TMAGIC) break;

            pos += CONST::block_size;
            size_t file_size = strtoul(header->size, nullptr, 8);
            size_t file_block_count = (file_size + CONST::block_size - 1) / CONST::block_size;

            string cur_file = (header->name);
            cur_file = Pfunction::remove_unnecssary_slash(cur_file);
            auto cur_path = filesystem::getPath(cur_file);
            auto cur_filename = filesystem::getFileName(cur_file);

            if(existin(header->typeflag, CONST::typeflag_record)){
                if(!existin(cur_file,var::files_mtime)){
                    Pfunction::read_tar_attr(header, pos, file_size, cur_file);
                }else {
                    time_t cur_file_mtime = strtoul(header->mtime, nullptr, 8);
                    if(var::files_mtime[cur_file] < cur_file_mtime){
                        Pfunction::read_tar_attr(header, pos, file_size, cur_file);
                    }
                }
                if (!existin(cur_path, var::dir_content)) {
                    set<string> temp;
                    var::dir_content[cur_path] = temp;
                }
                if (cur_filename.size() != 0) {
                    var::dir_content[cur_path]
                            .insert(cur_filename);
                }
                pos += file_block_count * CONST::block_size;
                fseek(var::file, pos, SEEK_SET);
            }
        }

        fseek(var::file, 0, SEEK_SET);

        return true;
    }


    bool GetFileContents(const string& file_name, char *contents) {
        bool flag = false;
        if(existin(file_name, var::files_size)){
            int file_size = var::files_size[file_name];
            flag = true;
            fseek(var::file, var::file_in_tar_addrs[file_name], SEEK_SET);
            fread(contents, file_size, 1, var::file);
            fseek(var::file, 0, SEEK_SET);
        }
        return flag;
    }

    size_t GetFileSize(string file_name) {
        cout << "GetFileSize(" << file_name << "), Size:" << var::files_size[file_name] << endl;
        return var::files_size[file_name];
    }

    int open_and_parse_tar_contents() {
        var::file = fopen(var::tar_path, "rb");
        bool is_valid_tar_file = IsValidTarFile();
        if (!is_valid_tar_file) {
            fprintf(stderr, "it is not a valid tar file: %s\n", var::tar_path);
            return -1;
        }

        for (auto const &pair : var::dir_content) {
            auto path = pair.first;
            cout << path << ":" << endl;
            for (auto name : pair.second) {
                string full_path = pair.first + "/" + name;
                cout << "    " << name << ", Size: " << var::files_size[full_path] << endl;
                cout << "        Mtime: " << var::files_mtime[full_path];
                cout << ", Gid: " << var::files_gid[full_path];
                cout << ", Uid: " << var::files_uid[full_path];
                cout<<endl;
            }
        }
        return 0;
    }
}
//#ifndef __APPLE__

namespace fuse_function {
    int
    read_dir_content(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
        string pathstr = path;
        auto strip_path = pathstr.substr(1, pathstr.size() - 1);
        for (auto file : tar::var::dir_content[strip_path]) {
            filler(buffer, file.c_str(), nullptr, 0);
        }
        return 0;
    }

    int getattr(const char *path, struct stat *stdbuf) {
        int result = 0;
        memset(stdbuf, 0, sizeof(struct stat));
        string pathstr = path;
        auto strip_path = pathstr.substr(1, pathstr.size() - 1);

        stdbuf->st_uid = tar::var::files_uid[strip_path];
        stdbuf->st_gid = tar::var::files_gid[strip_path];
        stdbuf->st_mtime = tar::var::files_mtime[strip_path];
        mode_t cur_mode = tar::var::files_mode[strip_path];
        if(strip_path == ""){
            stdbuf->st_mode = S_IFDIR | 0444u;
        } else if (existin(strip_path, tar::var::dir_content)) {// Setup as dir
            stdbuf->st_mode = S_IFDIR | cur_mode;
        } else if (existin(strip_path, tar::var::file_in_tar_addrs)) {// Setup as file
            stdbuf->st_mode = S_IFREG | cur_mode;
            stdbuf->st_size = tar::GetFileSize(strip_path);
        } else
            result = -ENOENT; // File not found

        return result;
    }

    int readfile(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *_) {
        (void) _;

        tar::var::file = fopen(tar::var::tar_path, "rb");
        auto strip_path = tar::Pfunction::remove_first_slash(path);
        size_t file_size = tar::GetFileSize(strip_path);
        char *contents = new char[file_size + 1];
        cout<<"[contents initialized]"<<endl;
        if (tar::GetFileContents(strip_path, contents)) {
            contents[file_size] = '\0';
            if (offset < file_size) {
                if (offset + size > file_size) {
                    size = file_size - offset;
                }
                memcpy(buffer, contents + offset, size);
            } else {
                size = 0;
            }
            cout<<"[contents filled]"<<endl;
            cout<<"[clear contents]"<<endl;
            return size;
        }
        return 0;
    }
}

namespace solution {
    struct fuse_operations oper;

    int mount_tar(int argc, char *argv[]) {
        tar::open_and_parse_tar_contents();
        if (!tar::IsValidTarFile()) {
            fprintf(stderr, "it is not a valid tar file: %s\n", tar::var::tar_path);
            return -1;
        }

        oper.getattr = fuse_function::getattr;
        oper.readdir = fuse_function::read_dir_content;
        oper.read = fuse_function::readfile;
        return fuse_main(argc, argv, &oper, nullptr);
    }
}

int main(int argc, char *argv[]) {
    cout << "Fuse Server Start" << endl;
#ifndef __APPLE__
    return solution::mount_tar(argc, argv);
#endif
}


