#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <math.h>
#include <sys/stat.h>
#include <map>

using namespace std;

typedef struct header {
    char filename[100];
	char filemode[8];
	char uid[8];
	char gid[8];
	char filesize[12];
	char mtime[12];
	char checksum[8];
	char type;
	char linkname[100];
	char magic[6];
	char version[2];
	char uname[32];
	char gname[32];
	char majordeviceID[8];
	char minordeviceID[8];
	char prefix[167];
} TarHeader;

class TarFile {
public:
    TarFile() {}
    TarFile(struct stat s, char * c, unsigned int length) {
        st = s;
        content = (char *)malloc(length);
        memcpy(content, c, length);
        contentLength = length;
    }
    struct stat st;
    char *content;
    unsigned int contentLength;
};

map<string, TarFile> fs;



int octal_string_to_int(char *current_char, unsigned int size){
    unsigned int output = 0;
    while(size > 0){
        // cout << (int)*current_char << endl;
        if(*current_char != 0 && *current_char != ' ') {
            output = output * 8;
            output += *current_char - '0';
        }
        current_char++;
        size--;
    }
    // cout << output << endl;
    return output;
}

unsigned int checksum(char *current_char, unsigned int size) {
    unsigned int i, sum;
    sum = 0;
    for(i = 0; i < 512; i++)
        sum += 0xFF & current_char[i];
    return sum;
}

int my_getattr(const char *path, struct stat *st) {
    cout << "getattr: " << path << endl;
    string p(path);
    if(strcmp( path, "/" ) == 0) {
        st->st_mode = S_IFDIR | 0755;
    }
    else if(fs.find(p) != fs.end()) {
        st->st_uid = fs[p].st.st_uid;
        st->st_gid = fs[p].st.st_gid;
        st->st_mtime = fs[p].st.st_mtime;
        st->st_size = fs[p].st.st_size;
        st->st_mode = fs[p].st.st_mode;
    } 
    else return -2;
    return 0;
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) { 
    cout << "readdir " << path << endl;
    string p(path);
    if(p[p.length()-1] != '/')p += '/';
    map<string, int> dir;
    for (map<string, TarFile>::iterator it=fs.begin(); it!=fs.end(); ++it) {
        string file = it->first;
        int pos = file.find(p);
        if(pos != string::npos) {
            cout << file << endl;
            file = file.substr(pos+p.length());
            file = file.substr(0, file.find("/"));
            cout << "add " << file << endl;
            dir[file] = 1;
        }
        // cout << path.substr(0, pos) << endl;
    }
    for (map<string, int>::iterator it=dir.begin(); it!=dir.end(); ++it) {
        string path = it->first;
        cout << path << endl;
        filler(buffer, path.c_str(), NULL, 0);
    }
    return 0;
    
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
    cout << "read" << path << endl;
    string p(path);
    if(fs.find(p) != fs.end()) {
        cout << fs[p].content << endl;
        unsigned int length = fs[p].contentLength - offset;
        if (length > size) length = size;
        memcpy(buffer, fs[p].content+offset, length);
        return length;
    }
    return 0;
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
    memset(&op, 0, sizeof(op)); 

    ifstream tarfile;
    tarfile.open ("test.tar");
    cout << oct << S_IFREG << dec << endl;
    char buffer[512];
    while(!tarfile.eof()) {
        tarfile.read(buffer, 512);
        cout << "checksum " << checksum(&buffer[0], 513) << endl; 
        if(checksum(buffer, 512) == 0) break;
        cout << "-----------file-----------" << endl;
        TarHeader* header = (TarHeader*) buffer;
        int size_of_file = octal_string_to_int(header->filesize, sizeof(header->filesize));
        string filename(header->filename);
        cout << "filename "<< filename << endl;
        struct stat st;
        cout << octal_string_to_int(header->uid, 8) << endl;
        st.st_uid = octal_string_to_int(header->uid, 8);
        st.st_gid = octal_string_to_int(header->gid, 8);
        st.st_mtime = octal_string_to_int(header->mtime, 12);
        st.st_size = size_of_file;
        int mode = octal_string_to_int(header->filemode, 8);
        if(header->type == '5')
            st.st_mode = (S_IFDIR | mode);
        else
            st.st_mode = (S_IFREG | mode);
        int contentBlockNum = (int)ceil(size_of_file / 512.0)*512;
        cout << "contentBlockNum " << contentBlockNum << endl;
        char fileContent[contentBlockNum];
        if (contentBlockNum > 0)
            tarfile.read(fileContent, contentBlockNum);
        TarFile file(st, fileContent, contentBlockNum);
        if(filename[filename.length()-1] == '/') filename = filename.substr(0, filename.length()-1);
        if(fs.find("/"+filename) != fs.end()) {
            if(fs["/"+filename].st.st_mtime < st.st_mtime)
                fs["/"+filename] = file;
        }
        else
            fs["/"+filename] = file;
    }
    tarfile.close();
    for (map<string, TarFile>::iterator it=fs.begin(); it!=fs.end(); ++it)
        cout << it->first  << '\n';
    cout << "-----" << endl;
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

