/*
Student No.: 0616329
Student Name: Lee, Ching-Jui
Email: rarylee0703@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#include <vector>
#include <string>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <fuse.h>
#include <sys/stat.h>
#include <fstream>
#include <errno.h>
#define TMAGIC   "ustar"        /* ustar and a null */
using namespace std;

typedef struct header
{                                     /* byte offset */
	char name[100];               /*   0 */
	char mode[8];                 /* 100 */
	char uid[8];                  /* 108 */
	char gid[8];                  /* 116 */
	char size[12];                /* 124 */
	char mtime[12];               /* 136 */
	char chksum[8];               /* 148 */
	char typeflag;                /* 156 */
	char linkname[100];           /* 157 */
	char magic[6];                /* 257 */
	char version[2];              /* 263 */
	char uname[32];               /* 265 */
	char gname[32];               /* 297 */
	char devmajor[8];             /* 329 */
	char devminor[8];             /* 337 */
	char prefix[155];             /* 345 */
                                      /* 500 */
} tar_header;


class TarFile {
public:
	TarFile(const char* tar_name);
	void parse_tar_file();
	std::vector<string> GetFileNames();
	vector<string> GetFileUid();
	vector<string> GetFileGid();
	vector<string> GetFileTime();
	bool GetFileContents(const char* file_name, char* contents);
	vector<size_t> GetFileSize();
	size_t GetTarSize();
	~TarFile();
private:
	FILE* file;
	size_t size;
	vector<string> file_names;
	vector<string> file_uid;
	vector<string> file_gid;
	vector<string> file_mtime;
	vector<size_t> file_sizes;
	vector<size_t> file_data_start_addrs;
};

TarFile::TarFile(const char* tar_name)
	: file(NULL), size(0)
{
	file_names.clear();
	file_mtime.clear();
	file_gid.clear();
	file_uid.clear();
	file_sizes.clear();
	file_data_start_addrs.clear();
	file = fopen(tar_name, "rb");
}
 
TarFile::~TarFile()
{
	if (file) {
		fclose(file);
		file = NULL;
	}
	file_names.clear();
	file_mtime.clear();
	file_gid.clear();
	file_uid.clear();
	file_sizes.clear();
	file_data_start_addrs.clear();
}
 
void TarFile::parse_tar_file()
{
	if (!file) return;
 
	const int block_size = 512;
	unsigned char buf[block_size];
	tar_header* header = (tar_header*)buf;
	memset(buf, 0, block_size);
 
	fseek(file, 0, SEEK_END);
	size = ftell(file);
	fseek(file, 0, SEEK_SET);
	if (size % block_size != 0)
		return;
 
	size_t pos = 0;
 
	while (1) {
		size_t read_size = fread(buf, block_size, 1, file);
		if (read_size != 1) break;
		if (strncmp(header->magic, TMAGIC, 5)) break;
 
		pos += block_size;
		size_t file_size = 0;
		sscanf(header->size, "%lo", &file_size);
		size_t file_block_count = (file_size + block_size - 1) / block_size;
		switch (header->typeflag) {
			case '0':
			case '\0':
				// normal file
				file_sizes.push_back(file_size);
				file_names.push_back(string(header->name));
				file_mtime.push_back(string(header->mtime));
				file_uid.push_back(string(header->uid));
				file_gid.push_back(string(header->gid));
				file_data_start_addrs.push_back(pos);
				break;
			case '5':
				// directory
				file_sizes.push_back(file_size);
				file_names.push_back(string(header->name));
				file_mtime.push_back(string(header->mtime));
				file_uid.push_back(string(header->uid));
				file_gid.push_back(string(header->gid));
				file_data_start_addrs.push_back(pos);
				break;
			default:
				break;
		}
 
		pos += file_block_count * block_size;
		fseek(file, pos, SEEK_SET);
	}
 
	fseek(file, 0, SEEK_SET);
 
	return;
}
 
vector<string> TarFile::GetFileNames()
{
	return file_names;
}

vector<string> TarFile::GetFileUid()
{
	return file_uid;
}

vector<string> TarFile::GetFileGid()
{
	return file_gid;
}

vector<string> TarFile::GetFileTime()
{
	return file_mtime;
}
 
vector<size_t> TarFile::GetFileSize()
{
	return file_sizes;
}

bool TarFile::GetFileContents(const char* file_name, char* contents)
{
	bool flag = false;
	size_t mtime=0, mtime_tmp;
	vector<string> file_mtime = GetFileTime();
	for (int i = 0; i < file_names.size(); i++) {
		sscanf(file_mtime[i].c_str(), "%lo", &mtime_tmp) ;
		if (strcmp(file_names[i].c_str(), file_name) == 0 && mtime <= mtime_tmp) {
			int file_size = file_sizes[i];
			flag = true;
			fseek(file, file_data_start_addrs[i], SEEK_SET);
			fread(contents, file_size, 1, file);
			fseek(file, 0, SEEK_SET);
		}
	}
 
	return flag;
}

 
size_t TarFile::GetTarSize()
{
	return size;
}

struct node{
	char* name;
	size_t size;
	size_t uid;
	size_t gid;
	char *content;
	size_t mtime;
	node *next;
	node *child;
	node *parent;
};

typedef struct node node;

static node *root;
node* new_node(){
	node *newnode = new node;
	newnode->name = (char*)malloc(sizeof(char)*256);
	newnode->size = 0;
	newnode->uid = 0;
	newnode->gid = 0;
	newnode->mtime = 0;
	newnode->content = NULL;
	newnode->next = NULL;
	newnode->child = NULL;
	newnode->parent = NULL;
	return newnode;
}

void add_child(node* parent, node* child){
	if(parent->child == NULL){
		parent->child = child;
		child->parent = parent;
	}
	else{
		node *ptr = parent->child;
		while(ptr->next != NULL)
			ptr = ptr->next;
		ptr->next = child;
		child->parent = parent;
	}
}

void trace(node* current){
	if(current == NULL)
		return;
	node *ptr = current->child;
	while(ptr!=NULL){

	}
	trace(current->child);
	trace(current->next);
}

int my_readdir( const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi )
{
	char *p = (char*)malloc(sizeof(char)*(strlen(path)+1));
	strcpy(p, path);
	node *current = root->child;
	const char *delim = "/";
 	char *pch;
 	pch = strtok(p, delim);
 	while(pch!=NULL){
 		while(current!=NULL){
 			if(strcmp(current->name, pch)==0){
 				current = current->child;
 				break;
 			}
 			current = current->next;
 			if(current == NULL)
 				return -ENOENT;
 		}
 		pch = strtok(NULL, delim);
 		if(current == NULL && pch)
 			return -ENOENT;
 	}
 	while(current!=NULL){
 		filler(buffer, current->name, NULL, 0);
 		current = current->next;
 	}
	return 0;
}

static int my_getattr( const char *path, struct stat *st )
{
	if ( strcmp( path, "/" ) == 0 )
	{
		st->st_mode = S_IFDIR | 0444;
		return 0;
	}
	int valid = 1;
	char *p = (char*)malloc(sizeof(char)*(strlen(path)+1));
	if(path[0]=='/')
		strncpy(p, path+1, strlen(path));
	else
		strcpy(p, path);
	node *current = root->child;
	node *parent = NULL;
	const char *delim = "/";
 	char *pch;
 	if(!strchr(p, '/')){
 		while(current!=NULL){
 			if(strcmp(current->name, p)==0)
 				break;
 			current = current->next;
 		}
 		if(!current)
 			return -ENOENT;
 		else if(current->child){
 			if(current->uid == 0)
 				st->st_mode = S_IFDIR | 0755;
 			else
 				st->st_mode = S_IFDIR | 0775;
			st->st_uid = current->uid;
			st->st_gid = current->gid;
			st->st_mtime = current->mtime;
 		}
 		else{
 			if(current->uid == 0)
 				st->st_mode = S_IFREG | 0644;
 			else
 				st->st_mode = S_IFREG | 0664;
 			st->st_uid = current->uid;
			st->st_gid = current->gid;
			st->st_size = current->size;
			st->st_mtime = current->mtime;
 		}

 	}
 	else{
	 	pch = strtok(p, delim);
	 	while(pch!=NULL){
	 		while(current!=NULL){
	 			if(strcmp(current->name, pch)==0){
	 				parent = current;
	 				current = current->child;
	 				
	 				break;
	 				
	 			}
	 			current = current->next;
	 			if(current == NULL){
		 			valid = 0;
		 			return -ENOENT;
	 			}
	 		}
	 		
	 		pch = strtok(NULL, delim);
	 	}
		if(valid && parent && parent->child!=NULL){
			if(parent->uid == 0)
 				st->st_mode = S_IFDIR | 0755;
 			else
 				st->st_mode = S_IFDIR | 0775;
			st->st_uid = parent->uid;
			st->st_gid = parent->gid;
			st->st_mtime = parent->mtime;
		}
		else{
			if(parent->uid == 0)
 				st->st_mode = S_IFREG | 0644;
 			else
 				st->st_mode = S_IFREG | 0664;
			st->st_uid = parent->uid;
			st->st_gid = parent->gid;
			st->st_size = parent->size;
			st->st_mtime = parent->mtime;
			
		}
	}
	return 0;
}

static int my_read( const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi )
{
	int valid = 1;
	int length=0;
	char *p = (char*)malloc(sizeof(char)*(strlen(path)+1));
	if(path[0]=='/')
		strncpy(p, path+1, strlen(path));
	else
		strcpy(p, path);
	node *current = root->child;
	const char *delim = "/";
 	char *pch;
 	if(!strchr(p, '/')){
 		while(current!=NULL){
 			if(strcmp(current->name, p)==0)
 				break;
 			current = current->next;
 		}
 		if(!current)
 			return -ENOENT;
 		else{
 			length = strlen(current->content);
 			if(offset>=length)
 				return 0;
 			if(length == 0)
 				return length;
 			if(size > length - offset)
				size = length - offset;
 			strncpy(buffer, current->content+offset, size);
 		}

 	}
 	else{
 		if(offset > size)
 			return 0;
 		node *parent = NULL;
	 	pch = strtok(p, delim);
	 	while(pch!=NULL){
	 		while(current!=NULL){
	 			if(strcmp(current->name, pch)==0){
	 				parent = current;
	 				current = current->child;
	 				break;
	 				
	 			}
	 			current = current->next;
	 			if(current == NULL){		 			
	 				valid = 0;
		 			return -ENOENT;
	 			}
	 		}
	 		pch = strtok(NULL, delim);
	 	}
		length = strlen(parent->content);
		if(offset>=length)
			return 0;
 		if(length == 0)
 			return length;
 		if(size > length - offset)
			size = length - offset;
		strncpy(buffer, parent->content+offset, size);
	}
	return size;
}

static struct fuse_operations op;

int main(int argc, char *argv[])
{
	const string tar_file_path= "test.tar" ;
	TarFile tarfile(tar_file_path.c_str());
 
	tarfile.parse_tar_file();
 
	vector<string> file_names = tarfile.GetFileNames();
	vector<string> file_uid = tarfile.GetFileUid();
	vector<string> file_gid = tarfile.GetFileGid();
	vector<string> file_mtime = tarfile.GetFileTime();
	vector<size_t> file_size = tarfile.GetFileSize();
	int i;
	//build tree
 	root = new_node();
 	strcpy(root->name, "/");
 	for(i=0;i<file_names.size();i++){
 		char *s = (char*)malloc((file_names[i].length()+1)*sizeof(char));
 		int j;
 		strcpy(s, file_names[i].c_str());
 		const char *delim = "/";
 		char *pch;
 		node *current = root;
 		pch = strtok(s, delim);
 		while(pch!=NULL){
 			node *files = current->child;
 			while(files!=NULL){
 				if(strcmp(files->name, pch)==0){
 					current = files;
 					break;
 				}
 				files = files->next;
 			}
 			if(files == NULL){
 				node *newnode = new_node();
 				strcpy(newnode->name,pch);
 				add_child(current, newnode);
 				current = newnode;
 			}
 			else{
 				current = files;
 			}
 			pch = strtok(NULL, delim);
 			if(pch==NULL){
 				size_t uid, gid, mtime;
 				sscanf(file_uid[i].c_str(), "%lo", &uid);
 				sscanf(file_gid[i].c_str(), "%lo", &gid);
 				sscanf(file_mtime[i].c_str(), "%lo", &mtime);
 				if(mtime >= current->mtime){
 					current->mtime = mtime;
 					current->uid = uid;
 					current->gid = gid;
 					current->size = file_size[i];
 					current->content = new char[file_size[i] + 1];
 					tarfile.GetFileContents(file_names[i].c_str(), current->content);
					current->content[file_size[i]] = '\0';
				}
 			}
 		}
 	}
 	memset(&op, 0, sizeof(op));
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	return fuse_main(argc, argv, &op, NULL);
}