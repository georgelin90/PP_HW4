/*
Student No.: 0616026
Student Name: 游騰德
Email: samuelyuyy@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <sys/stat.h>
#include <string>
#include <math.h>
#include <errno.h>
using namespace std;

struct TARFileHeader {
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char modifyTime[12];
    char checksum[8];
    char linkFlag;
    char linkName[100];
    char magic[8];
    char userName[33];
    char groupName[33];
    char majorDeviceID[8];
    char minorDeviceID[8];
    char padding[167];
};

TARFileHeader curFileHeader;

void ParseFileHeader(char fileHeaderstr[512]) {
    strncpy(curFileHeader.name,         fileHeaderstr+0,   100);
    strncpy(curFileHeader.mode,         fileHeaderstr+100, 8);
    strncpy(curFileHeader.uid,          fileHeaderstr+108, 8);
    strncpy(curFileHeader.gid,          fileHeaderstr+116, 8);
    strncpy(curFileHeader.size,         fileHeaderstr+124, 12);
    strncpy(curFileHeader.modifyTime,   fileHeaderstr+136, 12);
    strncpy(curFileHeader.checksum,     fileHeaderstr+148, 8);
    curFileHeader.linkFlag = fileHeaderstr[156];
    strncpy(curFileHeader.linkName,     fileHeaderstr+157, 100);
    strncpy(curFileHeader.magic,        fileHeaderstr+257, 8);
    strncpy(curFileHeader.userName,     fileHeaderstr+265, 32);
    strncpy(curFileHeader.groupName,    fileHeaderstr+297, 32);
    strncpy(curFileHeader.majorDeviceID,fileHeaderstr+329, 8);
    strncpy(curFileHeader.minorDeviceID,fileHeaderstr+337, 8);
    strncpy(curFileHeader.padding,      fileHeaderstr+345, 167);

    if ( curFileHeader.name[strlen(curFileHeader.name)-1] == '/' )
        curFileHeader.name[strlen(curFileHeader.name)-1] = '\0';
    curFileHeader.userName[strlen(curFileHeader.userName)] = '\0';
    curFileHeader.groupName[strlen(curFileHeader.groupName)] = '\0';
}

bool isInDir(const char *path) {
    int i = 0;
    for (; i+1 < strlen(path); i++) {
        if (path[i+1] != curFileHeader.name[i]) return 0;
    }
    if (curFileHeader.name[i++] != '/' && strlen(path) != 1)
        return 0;

    int count = 0;
    for (; i < strlen(curFileHeader.name); i++) {
        if (curFileHeader.name[i] == '/') count++;
    }
    
    if (count == 0) return 1;
    return 0;
}

unsigned long GetMode() {
    unsigned long mode = 0;
    unsigned long base = 1;
    int m = 0;
    if (curFileHeader.mode[6] == ' ') m = 1;
    for (int i = 6-m; i >= 0; i--) {
        int tmp = curFileHeader.mode[i];
        mode += (tmp-48) * base;
        base *= 8;
    }
    return mode;
} 

unsigned long GetSize() {
    unsigned long size = 0;
    unsigned long base = 1;
    for (int i = 10; i >= 0; i--) {
        int tmp = curFileHeader.size[i];
        size += (tmp-48) * base;
        base *= 8;
    }
    return size;
} 

unsigned long GetUID() {
    unsigned long id = 0;
    unsigned long base = 1;
    int m = 0;
    if (curFileHeader.uid[6] == ' ') m = 1;
    for (int i = 6-m; i >= 0; i--) {
        int tmp = curFileHeader.uid[i];
        id += (tmp-48) * base;
        base *= 8;
    }
    return id;
} 

unsigned long GetGID() {
    unsigned long id = 0;
    unsigned long base = 1;
    int m = 0;
    if (curFileHeader.gid[6] == ' ') m = 1;
    for (int i = 6-m; i >= 0; i--) {
        int tmp = curFileHeader.gid[i];
        id += (tmp-48) * base;
        base *= 8;
    }
    return id;
} 

unsigned long GetMTime() {
    unsigned long mt = 0;
    unsigned long base = 1;
    for (int i = 10; i >= 0; i--) {
        int tmp = curFileHeader.modifyTime[i];
        mt += (tmp-48) * base;
        base *= 8;
    }
    return mt;
} 


int my_getattr(const char *path, struct stat *st) { 
    /*do something*/
    FILE *fp;

    fp = fopen("test.tar", "r");
    int chcount = 0, find = 0;
    char ch, curFileHeaderStr[512];
    unsigned long tmpTime = 0;
    int hct = -1, hidx = 0;
    while (fscanf(fp, "%c", &ch) == 1) {
        curFileHeaderStr[chcount++] = ch;
        if (chcount == 512) {
            ParseFileHeader(curFileHeaderStr);
            if (strlen(path) == strlen(curFileHeader.name) + 1 &&
                !strncmp(path+1, curFileHeader.name, strlen(curFileHeader.name))) {
                if (strlen(path) > 1 && strlen(curFileHeader.name) ||
                    strlen(path) == 1 && !strlen(curFileHeader.name)) {
                    find = 1;
                    if (GetMTime() > tmpTime) {
                        tmpTime = GetMTime();
                        hct = hidx;
                    }
                }
            }
            hidx++;
            fseek(fp, (((GetSize()) + 511) & ~511), SEEK_CUR);
            chcount = 0;
        }
    }
    fclose(fp);
    if (!find) return -ENOENT;
    
    fp = fopen("test.tar", "r");
   
    chcount = 0;
    int tmpidx = 0;
    while (fscanf(fp, "%c", &ch) == 1) {
        curFileHeaderStr[chcount++] = ch;
        if (chcount == 512) {
            ParseFileHeader(curFileHeaderStr);
            if (tmpidx == hct) {
                break;
            }
            
            fseek(fp, (((GetSize()) + 511) & ~511), SEEK_CUR);
            chcount = 0;
            tmpidx++;
        }
    }
    
    if (!strncmp(path, "/\0", 2)) {
        st->st_mode = S_IFDIR | 0444;
    } else {
        if (curFileHeader.linkFlag == '5')
            st->st_mode = S_IFDIR | GetMode();
        else
            st->st_mode = S_IFREG | GetMode();

        st->st_uid = GetUID();
        st->st_gid = GetGID();
        st->st_mtime = GetMTime();
        st->st_size = GetSize();
    }
   
    fclose(fp);
    return 0;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) { 
    /*do something*/ 
    FILE *fp;
    fp = fopen("test.tar", "r");

    int chcount = 0;
    char ch, curFileHeaderStr[512];
    char added[1000][100];
    int a = 0;
    while (fscanf(fp, "%c", &ch) == 1) {
        curFileHeaderStr[chcount++] = ch;
        if (chcount == 512) {
            ParseFileHeader(curFileHeaderStr);
            if (isInDir(path) && strlen(curFileHeader.name)) {
                int j = 0;
                for (int i = 0; i < strlen(curFileHeader.name); i++)
                    if (curFileHeader.name[i] == '/') j = i+1;
                
                char filename[100];
                strncpy(filename, curFileHeader.name+j, strlen(curFileHeader.name)-j);
                filename[strlen(curFileHeader.name)-j] = '\0';

                int isadded = 0;
                for (int i = 0; i < a; i++) {
                    if (!strcmp(filename, added[i])) {
                        isadded = 1;
                        break;
                    }
                }
                if (!isadded) {
                    filler(buffer, filename, NULL, 0);
                    strcpy(added[a++], filename);
                    added[a][ strlen(filename) ] = '\0';
                }
            }
            fseek(fp, (((GetSize()) + 511) & ~511), SEEK_CUR);
            chcount = 0;
        }
    }
    
    fclose(fp);
    return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
    /*do something*/ 
    FILE *fp;
    fp = fopen("test.tar", "r");
    int chcount = 0, find = 0;
    char ch, curFileHeaderStr[512];
    unsigned long tmpTime = 0;
    int hct = -1, hidx = 0;
    while (fscanf(fp, "%c", &ch) == 1) {
        curFileHeaderStr[chcount++] = ch;
        if (chcount == 512) {
            ParseFileHeader(curFileHeaderStr);
            if (strlen(path) == strlen(curFileHeader.name) + 1 &&
                !strncmp(path+1, curFileHeader.name, strlen(curFileHeader.name))) {
                if (strlen(path) > 1 && strlen(curFileHeader.name) ||
                    strlen(path) == 1 && !strlen(curFileHeader.name)) {
                    find = 1;
                    if (GetMTime() > tmpTime) {
                        tmpTime = GetMTime();
                        hct = hidx;
                    }
                }
            }
            hidx++;
            fseek(fp, (((GetSize()) + 511) & ~511), SEEK_CUR);
            chcount = 0;
        }
    }
    fclose(fp);
    if (!find) return -ENOENT;

    fp = fopen("test.tar", "r");

    chcount = 0;
    int tmpidx = 0;
    while (fscanf(fp, "%c", &ch) == 1) {
        curFileHeaderStr[chcount++] = ch;
        if (chcount == 512) {
            ParseFileHeader(curFileHeaderStr);
            if (tmpidx == hct) {
                break;
            }

            fseek(fp, (((GetSize()) + 511) & ~511), SEEK_CUR);
            chcount = 0;
            tmpidx++;
        }
    }
    
    unsigned long fsize = GetSize();
    char tmpBuffer[fsize];
    chcount = 0;
    int j = 0;
    while (fscanf(fp, "%c", &ch) == 1 && chcount < fsize) {
        tmpBuffer[j++] = ch;
        chcount++;
    }
    memcpy(buffer, tmpBuffer + offset, (size<j? size:j));
    fclose(fp);
    return size<j? size:j;
}

static struct fuse_operations op;
int main(int argc, char *argv[]) {
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
