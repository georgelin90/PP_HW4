/*
Student NO.: 0616306
Student Name: 李柏霖
Email: leebolin8801@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30
#include <fuse.h>
#include <string>
#include <memory.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include<bits/stdc++.h>
using namespace std;

#define LF_OLDNORMAL '\0' /* Normal disk file, Unix compatible */
#define LF_NORMAL '0'	 /* Normal disk file */
#define LF_LINK '1'		  /* Link to previously dumped file */
#define LF_SYMLINK '2'	/* Symbolic link */
#define LF_CHR '3'		  /* Character special file */
#define LF_BLK '4'		  /* Block special file */
#define LF_DIR '5'		  /* Directory */
#define LF_FIFO '6'		  /* FIFO special file */
#define LF_CONTIG '7'	 /* Contiguous file */

struct tar{
	string Filename;
	int Filemode;
	int UserID;
	int GroupID;
	int Filesize;
	int Modifytime;
	string Linkflag;
	string Linkname;
	string Username;
	string Groupname;
	string MajordeviceID;
	string MinordeviceID;
	string FileContents;
};

struct tar addtar(tar* t, string fname, int fmode, int UID, int GID, int fsize, int modtime, string lflag, string lname, string uname, string gname, string majorid, string minorid, string fcontents){
	
	t->Filename = fname;
	t->Filemode = fmode;
	t->UserID = UID;
	t->GroupID = GID;
	t->Filesize = fsize;
	t->Modifytime = modtime;
	t->Linkflag = lflag;
	t->Linkname = lname;
	t->Username = uname;
	t->Groupname = gname;
	t->MajordeviceID = majorid;
	t->MinordeviceID = minorid;
	t->FileContents = fcontents;
	return *t;
}

vector<tar> Table;

void readtar(){
	string fname;
	int fmode;
	int UID;
	int GID;
	int fsize;
	int modtime;
	string lflag;
	string lname;
	string uname;
	string gname;
	string majorid;
	string minorid;
	string fcontents;

	char buffer[512];

	int sizecnt = 0;
	ifstream fin("test.tar");
	if(!fin)
		cout << "error\n";
	while(fin.read(buffer, sizeof(buffer))){
		if(sizecnt == 0){
			fname = fname + '/';
			for(int i=0; i<100; i++)
				if(buffer[i] != '\0')
					fname = fname + buffer[i];
				else
					break;

			if(fname[fname.size()-1] == '/')
				fname.resize(fname.size() - 1);
			
			char c;
			int msum = 0;
			for(int i=100; i<107; i++){
				c = buffer[i];
				if(isdigit(c))
					msum = msum*8 + c - '0';
			}
			fmode = msum;
			//cout << "fmode = " << fmode << endl;

			int uids = 0;
			for(int i=108; i<115; i++){
				c = buffer[i];
				if(isdigit(c))
					uids = uids*8 + c - '0';
			}
			UID = uids;
			//cout << "UID = " << UID << endl;

			int gids = 0;
			for(int i=116; i<123; i++){
				c = buffer[i];
				if(isdigit(c))
					gids = gids*8 + c - '0';
			}
			GID = gids;
			//cout << "GID = " << GID <<endl;

			bool empty = 0;
			for(int i=124; i<135; i++){
				c = buffer[i];
				if(isdigit(c)){
					sizecnt = sizecnt*8 + c - '0';
				}
				else{
					empty = 1;
					fname.clear();
					fmode =  UID = GID = fsize = modtime = 0;
					lflag.clear();
					lname.clear();
					uname.clear();
					gname.clear();
					majorid.clear();
					minorid.clear();
					fcontents.clear();
					break;
				}
			}
			if(empty)
				continue;
			fsize = sizecnt;
			//cout << "fsize = " << fsize << endl;

			int time = 0;
			for(int i=136; i<147; i++){
				c = buffer[i];
				if(isdigit(c))
					time = time*8 + c - '0';
			}
			modtime = time;
			//cout << "Modifytime = " << modtime << endl;

			for(int i=156; i<157; i++)
				lflag += buffer[i];
			for(int i=157; i<257; i++){
				if(buffer[i] != '\0')
					lname += buffer[i];
				else
					break;
			}
			for(int i=265; i<297; i++){
				if(buffer[i] != '\0')
					uname += buffer[i];
				else
					break;
			}
			for(int i=297; i<329; i++){
				if(buffer[i] != '\0')
					gname += buffer[i];
				else
					break;
			}
			for(int i=329; i<336; i++)
				majorid += buffer[i];
			for(int i=337; i<344; i++)
				minorid += buffer[i];

			if(sizecnt == 0){
				tar tt;
				Table.push_back(addtar(&tt, fname, fmode, UID, GID, fsize, modtime, lflag, lname, uname, gname, majorid, minorid, fcontents));
				uname.clear();
				fcontents.clear();
				lname.clear();
				fmode = UID = GID = fsize = modtime = 0;
				gname.clear();
				fname.clear();
				minorid.clear();
				lflag.clear();
				majorid.clear();
			}
		}else{
			for(int i=0; i<512; i++){
				if(sizecnt != 0){
					fcontents += buffer[i];
					sizecnt--;
				}else{
					break;
				}
			}
			if(sizecnt == 0){
				tar tt;
				Table.push_back(addtar(&tt, fname, fmode, UID, GID, fsize, modtime, lflag, lname, uname, gname, majorid, minorid, fcontents));
				//cout << "FILENAME: "<< tt.Filename << endl;
				fname.clear();
				fmode = UID = GID = fsize = modtime = 0;
				lflag.clear();
				lname.clear();
				uname.clear();
				gname.clear();
				majorid.clear();
				minorid.clear();
				fcontents.clear();
			}
		}
	}
	fin.close();
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
 /*do something*/ 
//	cout << "reading" << endl;
	vector<string> dir;
	dir.clear();
	string p = path;
	for(int i=0; i<Table.size(); i++){
		string cmp = Table[i].Filename;
		for(int j=cmp.size()-1; j>=0; j--){
			if(cmp[j] == '/'){
				cmp.resize(cmp.size()-1);
				break;
			}else{
				cmp.resize(cmp.size()-1);
			}
		}
		if(cmp.size() == 0)
			cmp += '/';
		if(cmp == p){
			//cout << Table[i].Filename << endl;
			string s = Table[i].Filename;
			//cout << s << endl;
			std::size_t found = s.find_last_of("/");
			s = s.substr(found + 1);

			if(find(dir.begin(), dir.end(), s) == dir.end()){
				filler(buffer, s.c_str(), NULL, 0);
				dir.push_back(s);
			}
		}
	}
	filler(buffer, ".", NULL, 0);
	filler(buffer, "..", NULL, 0);
	return 0;
}

int my_getattr(const char *path, struct stat *st) {
 /*do something*/ 
	string target;
	target = path;
	if(target == "/"){
		st->st_mode = S_IFDIR | 0444;
		return 0;
	}
	bool targetfound = 0;
	for(int i=0; i<=Table.size(); i++){
		if(Table[i].Filename == target){
			st->st_size = Table[i].Filesize;
			st->st_gid = Table[i].GroupID;
			st->st_mtime = Table[i].Modifytime;
			st->st_uid = Table[i].UserID;
			if(Table[i].Linkflag[0] == '5'){
				int mode = Table[i].Filemode;
				st->st_mode = S_IFDIR | mode;
			}else{
				int mode = Table[i].Filemode;
				st->st_mode = S_IFREG | mode;
			}
			targetfound = 1;
			break;
		}
	}
	if(!targetfound)
		return -ENOENT;

	return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
 /*do something*/ 
	string p = path;
	for(int i=0; i<Table.size(); i++){
		if(Table[i].Filename == p){
			int max = offset + size;
			if(offset >= Table[i].FileContents.size()){
				return 0;
			}else if(max > Table[i].FileContents.size()){
				max = Table[i].FileContents.size()-offset;
				memcpy(buffer, Table[i].FileContents.c_str() + offset, max);
				return max;
			}else{
				memcpy(buffer, Table[i].FileContents.c_str() + offset, size);
				return size;
			}
		}
	}
	return 0;
}

static struct fuse_operations op;

int main(int argc, char *argv[]){
	readtar();
	memset(&op, 0, sizeof(op)); 
	op.getattr = my_getattr;
	op.readdir = my_readdir;
	op.read = my_read;
	return fuse_main(argc, argv, &op, NULL);
}
