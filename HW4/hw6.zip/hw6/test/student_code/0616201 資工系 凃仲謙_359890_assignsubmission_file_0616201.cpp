#define FUSE_USE_VERSION 30
#include <bits/stdc++.h>
#include <fuse.h>

using namespace std;

#define BLOCK_SIZE 512

/*
Student No.: 0616201
Student Name: 凃仲謙
Email: a3102a123@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/

struct TAR_header {
    char filename[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char fileSize[12];
    char lastModification[12];
    char checksum[8];
    char typeFlag;
    char linkedFileName[100];
    char ustarIndicator[6];
    char ustarVersion[2];
    char ownerUserName[32];
    char ownerGroupName[32];
    char deviceMajorNumber[8];
    char deviceMinorNumber[8];
    char filenamePrefix[155];
    char padding[12];
};

static uint64_t decodeTarOctal(char* data, size_t size) {
    unsigned char* currentPtr = (unsigned char*) data + size;
    uint64_t sum = 0;
    int currentMultiplier = 1;
    //Skip everything after the last NUL/space character
    //In some TAR archives the size field has non-trailing NULs/spaces, so this is neccessary
    unsigned char* checkPtr = currentPtr; //This is used to check where the last NUL/space char is
    for (; checkPtr >= (unsigned char*) data; checkPtr--) {
        if ((*checkPtr) == 0 || (*checkPtr) == ' ') {
            currentPtr = checkPtr - 1;
        }
    }
    for (; currentPtr >= (unsigned char*) data; currentPtr--) {
        sum += ((*currentPtr) - 48) * currentMultiplier;
        currentMultiplier *= 8;
    }
    return sum;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi){
    cout<<"call readdir "<<path<<"\n";
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);
    FILE *fp = fopen("test.tar","r");
    char con_buffer[BLOCK_SIZE+1];
    const char *ptr;
    while(!feof(fp)){
        struct TAR_header h;
        bzero(&h,sizeof(struct TAR_header));
        fread(&h,sizeof(struct TAR_header),1,fp);
        int con_size = decodeTarOctal( h.fileSize , 12 );
        /*fill in file name*/
        /*root directory*/
        if(!strcmp(path,"/")){
            char *pch = strtok(h.filename,"/");
            int count = 0;
            while(pch != NULL){
                count++;
                pch = strtok(NULL,"/");
            }
            if(count == 1)
                filler(buffer, h.filename, NULL, 0);
        }
        /*other directory*/
        else{
            char path_copy[strlen(path) + 1];
            char file_name_copy[strlen(h.filename) + 1];
            vector<string> p,f;
            strcpy(path_copy,path+1);
            strcpy(file_name_copy,h.filename);
            char *pch = strtok(path_copy,"/");
            while(pch != NULL){
                p.push_back(pch);
                pch = strtok(NULL,"/");
            }
            pch = strtok(file_name_copy,"/");
            while(pch != NULL){
                f.push_back(pch);
                pch = strtok(NULL,"/");
            }
            if(f.size() == p.size() + 1){
                for(int i = 0 ; i < f.size() ; i++){
                    if(i == f.size() - 1){
                        filler(buffer, f[i].c_str(), NULL, 0);
                        break;
                    }
                    if(strcmp(f[i].c_str() , p[i].c_str()))
                        break;
                }
            }
        }
        /*read data and go to next file header*/
        while(con_size > 0){
            memset(con_buffer,0,BLOCK_SIZE+1);
            fread(con_buffer,512,1,fp);
            con_size -= 512;
        }
    }
    fclose(fp);
    return 0;
}

int my_getattr(const char *path, struct stat *st){
    cout<<"call getattr "<<path<<"\n";
    FILE *fp = fopen("test.tar","r");
    char con_buffer[BLOCK_SIZE+1];
    bool find = false;
    const char *ptr;
    while(!feof(fp)){
        struct TAR_header h;
        bzero(&h,sizeof(struct TAR_header));
        fread(&h,sizeof(struct TAR_header),1,fp);
        if(!strcmp(path,"/")){
            stat("test.tar",st);
            st->st_mode = S_IFDIR | 0444;
            find = true;
        }
        else{
            ptr = path + 1 ;
            int last = strlen(h.filename) - 1;
            if(h.filename[last] == '/')
                h.filename[last] = '\0';
        }
        if(!find && !strcmp(ptr,h.filename)){
            // cout<< h.uid <<" uid\n";
            st->st_uid = decodeTarOctal( h.uid , 8);
            // cout<< h.gid <<" gid\n";
            st->st_gid = decodeTarOctal( h.gid , 8);
            // cout<<h.lastModification<<" time\n";
            st->st_mtim.tv_sec = decodeTarOctal( h.lastModification , 12);
            // cout<<h.fileSize<<" size\n";
            st->st_size = decodeTarOctal( h.fileSize , 12 );
            int accessMode = decodeTarOctal(h.mode , 8);
            if(h.typeFlag == '5')
                st->st_mode = S_IFDIR | accessMode;
            else
                st->st_mode = S_IFREG | accessMode;
            find = true;
            break;
        }
        int con_size = (int) decodeTarOctal( h.fileSize , 12);
        /*tar file information*/
        // cout<<"=================================\n";
        // cout<< h.filename << "\n";
        // cout<< "size : "<< con_size <<"\n";
        // cout<< "type flag : "<<h.typeFlag<<"\n";
        // cout<< "uid : "<< decodeTarOctal(h.uid, 8) <<"\n";
        // cout<< "gid : "<< decodeTarOctal(h.gid, 8) <<"\n";
        // cout<< "time(last) : "<< decodeTarOctal(h.lastModification, 12) <<"\n";
        // cout<< "mode : "<<oct<< decodeTarOctal(h.mode , 8) <<"\n";
        // mode_t m = S_IFDIR | decodeTarOctal(h.mode , 8);
        // cout<< "mode | SIFDIR " << m <<"\n";
        // m = S_IFREG | decodeTarOctal(h.mode , 8);
        // cout<< "mode | SIFREG " << m <<"\n";
        // cout << dec;
        /*read data and go to next file header*/
        while(con_size > 0){
            memset(con_buffer,0,BLOCK_SIZE+1);
            fread(con_buffer,512,1,fp);
            // cout<<buffer;
            con_size -= 512;
        }
    }
    fclose(fp);
    /*if sucess return 0 else return  nonzero value*/
    if(find)
        return 0;
    else
        return -2;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
    cout<<"call read "<<path<<"\n";
    cout<<"size : "<<size<<" offset : "<<offset<<"\n";
    FILE *fp = fopen("test.tar","r");
    char con_buffer[BLOCK_SIZE+1];
    int buffer_num = 0;
    bool find = false;
    while(!feof(fp)){
        struct TAR_header h;
        bzero(&h,sizeof(struct TAR_header));
        fread(&h,sizeof(struct TAR_header),1,fp);
        int con_size = decodeTarOctal( h.fileSize , 12 ),read_num = 0;
        /*find file and fill in buffer*/
        if(!strcmp(path + 1, h.filename)){
            find = true;
            fseek(fp,offset,SEEK_CUR);
            while( (buffer_num < size) && (con_size > 0) ){
                if(con_size >= BLOCK_SIZE)
                    read_num = BLOCK_SIZE;
                else
                    read_num = con_size;
                memset(con_buffer,0,BLOCK_SIZE+1);
                fread(con_buffer,read_num,1,fp);
                cout<<con_buffer;
                memcpy(buffer + buffer_num,con_buffer,read_num);
                con_size -= read_num;
                buffer_num += read_num;
            }
            cout<<"\n";
            break;
        }
        /*read data and go to next file header*/
        else{
            while(con_size > 0){
                memset(con_buffer,0,BLOCK_SIZE+1);
                fread(con_buffer,512,1,fp);
                con_size -= 512;
            }
        }
        if(find)
            break;
    }
    fclose(fp);
    /*return number of bytes read successfully*/
    return buffer_num;
}

static struct fuse_operations op;

int main(int argc,char **argv){
    memset(&op, 0, sizeof(op));
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    // const char *path;
    // struct stat *st;
    // my_getattr(path, st);
    // return 0;
    return fuse_main(argc, argv, &op, NULL);
}