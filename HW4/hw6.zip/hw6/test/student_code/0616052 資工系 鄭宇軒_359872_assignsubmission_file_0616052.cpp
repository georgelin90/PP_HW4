/*
Student No.: 0616052
Student Name: 鄭宇軒
Email: sam43125.cs06@g2.nctu.edu.tw
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30
#define TRIM_SLASH(NAME) if (strlen(NAME) > 0 && (NAME)[strlen(NAME) - 1] == '/') (NAME)[strlen(NAME) - 1] = '\0'

#include <fuse.h>
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <errno.h>

/* POSIX header. */

struct posix_header { /* byte offset */
    char name[100]; /* 0 */
    char mode[8]; /* 100 */
    char uid[8]; /* 108 */
    char gid[8]; /* 116 */
    char size[12]; /* 124 */
    char mtime[12]; /* 136 */
    char chksum[8]; /* 148 */
    char typeflag; /* 156 */
    char linkname[100]; /* 157 */
    char magic[6]; /* 257 */
    char version[2]; /* 263 */
    char uname[32]; /* 265 */
    char gname[32]; /* 297 */
    char devmajor[8]; /* 329 */
    char devminor[8]; /* 337 */
    char prefix[167]; /* 345 */
    /* 512 */
};

int my_getattr(const char *path, struct stat *st) {
    FILE *fp = fopen("test.tar", "r");
    if (!fp)
        return 0;

    // std::cout << "Path from getattr: " << path << std::endl;
    posix_header header;
    bool isExist = false;
    time_t mtime = 0;
    char buffer[512];

    if (!strcmp(path, "/")){
        stat("test.tar", st);
        st->st_mode = S_IFDIR | 0444;
        fclose(fp);
        return 0;
    }
    while (read(fileno(fp), &header, 512) == 512) {
        //          /dir1/dir2 dir1/dir2/
        //          /dir1/file dir1/file
        TRIM_SLASH(header.name);
        if (!strncmp(path + 1, header.name, 100)) {
            if (isExist && mtime > strtol(header.mtime, NULL, 8))
                continue;
            if (header.typeflag == '0') {
                // Normal file
                // std::cout << header.name << " is a file\n";
                st->st_uid = strtol(header.uid, NULL, 8);
                st->st_gid = strtol(header.gid, NULL, 8);
                st->st_mtime = strtol(header.mtime, NULL, 8);
                st->st_size = strtol(header.size, NULL, 8);
                st->st_mode = S_IFREG | strtol(header.mode, NULL, 8);
                isExist = true;
                mtime = st->st_mtime;
            }
            else if (header.typeflag == '5') {
                // Directory
                // std::cout << header.name << " is a folder\n";
                st->st_uid = strtol(header.uid, NULL, 8);
                st->st_gid = strtol(header.gid, NULL, 8);
                st->st_mtime = strtol(header.mtime, NULL, 8);
                st->st_size = strtol(header.size, NULL, 8);
                st->st_mode = S_IFDIR | strtol(header.mode, NULL, 8);
                isExist = true;
                mtime = st->st_mtime;
            }
            // else
            //     std::cerr << "ERROR\n";
            // fclose(fp);
            // return 0;
        }
        size_t len = strtol(header.size, NULL, 8);
        len = (len + 511) & ~511;
        lseek(fileno(fp), len, SEEK_CUR);
    }
    fclose(fp);
    if (isExist)
        return 0;
    return -ENOENT;
}

int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
    FILE *fp = fopen("test.tar", "r");
    if (!fp)
        return 0;

    // std::cout << "Path from readdir: " << path << std::endl;
    posix_header header;
    std::set<std::string> files;
    filler(buffer, ".", NULL, 0);
    filler(buffer, "..", NULL, 0);

    while (read(fileno(fp), &header, 512) == 512) {
        //           /         abc.txt
        //           /dir      dir/dir1/abc => dir1
        //           /dir/dir1 dir/dir1/abc => abc
        std::string _path(path);
        std::string _name(header.name);
        _path += "/";
        _path = _path.substr(1);
        if (_path == "/") {
            size_t pos = _name.find_first_of('/');
            if (pos != std::string::npos)
                _name = _name.substr(0, pos);
            files.insert(_name);
            // filler(buffer, _name.c_str(), NULL, 0);
        }
        else {
            bool isMatched = true;
            for (size_t i = 0; i < _path.size(); i++) {
                if (_name[0] == _path[i])
                    _name = _name.substr(1);
                else
                    isMatched = false;
            }
            if (isMatched) {
                size_t pos = _name.find_first_of('/');
                if (pos != std::string::npos)
                    _name = _name.substr(0, pos);
                files.insert(_name);
                // filler(buffer, _name.c_str(), NULL, 0);
            }
        }
        size_t len = strtol(header.size, NULL, 8);
        len = (len + 511) & ~511;
        lseek(fileno(fp), len, SEEK_CUR);
    }
    files.erase("");
    std::set<std::string>::iterator it = files.begin();
    for (; it != files.end(); it++) {
        filler(buffer, it->c_str(), NULL, 0);
        // std::cout << "Add " << *it << std::endl;
    }
    fclose(fp);
    return 0;
}

int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
    FILE *fp = fopen("test.tar", "r");
    if (!fp)
        return 0;
    
    posix_header header;
    bool isExist = false;
    time_t max_mtime = 0;
    size_t nread = 0;
    long pos = 0;
    // std::cout << "Path from read: " << path << std::endl;

    while (read(fileno(fp), &header, 512) == 512) {
        // std::cout << "Explore " << header.name << std::endl;
        if (!strcmp(path + 1, header.name)) {
            time_t mtime = strtol(header.mtime, NULL, 8);
            
            // char timestamp[100] = {};
            // strncpy(timestamp, ctime(&mtime), 100);
            // std::cout << timestamp << std::endl;
            
            if (!isExist || max_mtime < mtime) {
                pos = ftell(fp);
                // lseek(fileno(fp), offset, SEEK_CUR);
                // memset(buffer, '\0', sizeof(buffer));
                // nread = read(fileno(fp), buffer, size);
                // fclose(fp);
                // return nread;
                isExist = true;
                max_mtime = mtime;
            }
        }
        size_t len = strtol(header.size, NULL, 8);
        len = (len + 511) & ~511;
        lseek(fileno(fp), len, SEEK_CUR);
    }
    if (isExist) {
        lseek(fileno(fp), pos + offset, SEEK_SET);
        nread = read(fileno(fp), buffer, size);
        fclose(fp);
        return nread;
    }
    fclose(fp);
    return 0;
}

static struct fuse_operations op;

int main(int argc, char *argv[]) {
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}
