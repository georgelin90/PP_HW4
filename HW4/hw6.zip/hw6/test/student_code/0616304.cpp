/*
Student No.: 0616304
Student Name: Eric Chen
Email: egghead2612@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define false 0
#define true 1
typedef struct tar_entry{
char name[100];
char s_mode[8];
char s_uid[8];
char s_gid[8];
char s_mtime[12];
char s_size[12];
char lk_flag;
char *data;

int uid;
int gid;
int size;
int mode;
int mtime;

int exist;
struct tar_entry *next;
}entry;

typedef struct tar_table{

entry *head;
entry *tail;

}table;
table T;
int entry_num = 0;
int oct_to_dec(char *num,int size)
{
int ans = 0;
int base = 1;
for(int i = size - 1; i >= 0; i--)
	{
	if(num[i] >= 48 && num[i] <= 57)
		{
		ans += (num[i] - 48) * base;
		base *= 8;
		}
	}
return ans;

}

void fill_entry(char *head,entry *E)
{
for(int i = 0; i < 100; i++)
	{
	E->name[i] = head[i];
	}
for(int i = 100; i < 108; i++)
	{
	E->s_mode[i - 100] = head[i];
	E->mode = oct_to_dec(E->s_mode,8);
	}
for(int i = 108; i < 116; i++)
	{
	E->s_uid[i - 108] = head[i];
	E->uid = oct_to_dec(E->s_uid,8);
	}
for(int i = 116; i < 124; i++)
	{
	E->s_gid[i - 116] = head[i];
	E->gid = oct_to_dec(E->s_gid,8);
	}
for(int i = 124; i < 136; i++)
	{
	E->s_size[i - 124] = head[i];
	E->size = oct_to_dec(E->s_size,12);
	}
for(int i = 136; i < 148; i++)
	{
	E->s_mtime[i - 136] = head[i];
	E->mtime = oct_to_dec(E->s_mtime,12);
	} 
E->lk_flag = head[156];
E->exist = 1;
}
void copy_entry(entry *E1,entry *E2)
{
for(int i = 0; i < 100; i++)
	{
	E1->name[i] = E2->name[i];
	}
for(int i = 0; i < 8; i++)
	{
	E1->s_mode[i] = E2->s_mode[i];
	}
for(int i = 0; i < 8; i++)
	{
	E1->s_uid[i] = E2->s_uid[i];
	}
for(int i = 0; i < 8; i++)
	{
	E1->s_gid[i] = E2->s_gid[i];
	}
for(int i = 0; i < 12; i++)
	{
	E1->s_size[i] = E2->s_size[i];
	}
for(int i = 0; i < 12; i++)
	{
	E1->s_mtime[i] = E2->s_mtime[i];
	}
E1->mode = E2->mode;
E1->uid = E2->uid;
E1->gid = E2->gid;
E1->size = E2->size;
E1->mtime = E2->mtime;
E1->lk_flag = E2->lk_flag;
E1->data = strdup(E2->data);
E1->exist = 1;
}
void update_table(entry *E)
{
entry *tmp = T.head;
int update = 0;
while(tmp != T.tail && !update)
	{
	if(!strcmp(E->name,tmp->name))
		{
		if(E->mtime > tmp->mtime)
			{
			copy_entry(tmp,E);
			update = 1;
			}
		}
	tmp = tmp->next;
	}
if(!update)
	{
	if(!strcmp(E->name,tmp->name))
		{
		if(E->mtime > tmp->mtime)
			{
			copy_entry(tmp,E);
			update = 1;
			}
		}
	if(!update)
		{
		T.tail->next = E;
		T.tail = E;	
		}
	}
}
void make_table(FILE *fp)
{
int table_built = 0;


char head[512];
while(!feof(fp))
	{
	entry *E = (entry *)malloc(sizeof(entry));
	fread(head,1,512,fp);
	if(head[0] == '\0')
		{
		continue;
		}

	fill_entry(head,E);
	entry_num++;

	E->data = (char *)malloc(E->size * sizeof(char));
	fread(E->data,1,E->size,fp);

	if(!table_built)
		{
		T.head = E;
		T.tail = E;
		table_built = 1;
		}
	else
		{
		update_table(E);
		}
	// read header, maintain the table done
	//printf("name: %s\n",E->name);
	//printf("size: %d\n",E->size);


	//printf("data: " );
	//fwrite(E->data,1,E->size,stdout);	
	
	int padding = 512 - (E->size % 512);
	if(padding != 512)
		{
		char *pad = (char *)malloc(padding * sizeof(char));
		fread(pad,1,padding,fp);
		//printf("padding: %d\n",padding);
		}
	}
}
void show_entry(entry *E)
{
	printf("name: ");
	fwrite(E->name,1,100,stdout);
	printf(",size: ");
	fwrite(E->s_size,1,12,stdout);
	printf(",uid: ");
	fwrite(E->s_uid,1,8,stdout);
	printf(",gid: ");
	fwrite(E->s_gid,1,8,stdout);
	printf(",s_mtime: ");
	fwrite(E->s_mtime,1,12,stdout);
	printf("\n");
}
void show_table()
{
printf("Total entry: %d\n",entry_num);
entry *E  = T.head;
while(E != T.tail)
	{
	show_entry(E);
	E = E->next;
	}
	show_entry(E);
}
entry* find_entry(char *name)
{
for(int i = 1; i <= strlen(name); i++)
	{
	name[i - 1] = name[i];
	}
//printf("name1: %s\n",name);
entry *tmp = T.head;
while(tmp != T.tail)
	{	
	char *name2 = strdup(tmp->name);
	if(name2[strlen(name2) - 1] == '/')
		{
		name2[strlen(name2) - 1] = '\0';
		}
//	printf("name2: %s\n",name2);

	if(!strcmp(name2,name))
		{
		return tmp;
		}
	tmp = tmp->next;
	}	
	char *name2 = strdup(tmp->name);
	if(name2[strlen(name2) - 1] == '/')
		{
		name2[strlen(name2) - 1] = '\0';
		}
//	printf("name2: %s\n",name2);

if(!strcmp(name2,name))
	{
	return tmp;
	}
else
	{
	tmp = (entry *)malloc(sizeof(entry));
	tmp->exist = 0;
	return tmp;
	}
}
int my_getattr(const char *path, struct stat *st) {
printf("getattr\n");
printf("path: %s\n",path);

char *path2 = strdup(path);
if(!strcmp(path,"/"))
	{
	st->st_mode = S_IFDIR | 0444;
	st->st_size = 0;	
	printf("endof getattr1\n");					
	return 0;
	}
else
	{
	entry *E;
//	printf("before_find\n");
	E = find_entry(path2);
//	printf("after_find\n");
	if(!E->exist)
		{
		printf("error getattr\n");					
		return -2; // there is no such entry;
		}
	else
		{
		
		st->st_uid = E->uid;
		st->st_gid = E->gid;
		st->st_mtime = E->mtime;
		st->st_size = E->size;
	
		if(E->lk_flag == '5')	// if directory
			{
			st->st_mode = S_IFDIR | E->mode;
		//	st->st_mode = S_IFDIR | 0777;
			}
		else			// if regular file
			{
			st->st_mode = S_IFREG | E->mode;
		//	st->st_mode = S_IFREG | 0777;
			}
		printf("endof getattr\n");					
		return 0;
		}
	}
				// uid = int
				// gid = int
				// mtime = int
				// mode = int
				// size = int

return 0;
}
int check_str(char *name)
	{
	for(int i = 0; i < strlen(name); i++)
		{
		if(name[i] == '/' && i != strlen(name) - 1)
			{
			return false;
			}
		}
	return true;
	}
int check_str_pre(char *name,char *prefix)
	{
	if(strlen(prefix) >= strlen(name))
		{
		return false;
		}
	else
		{
		for(int i = 0; i < strlen(prefix) - 1; i++)
			{
			if(name[i] != prefix[i + 1])
				{
				return false;
				}
			}
		if(name[strlen(prefix) - 1] != '/')
			{
			return false;
			}
		for(int i = strlen(prefix); i < strlen(name); i++)
			{
			if(name[i] == '/' && i != strlen(name) - 1 )
				{
				return false;
				}
			}
		return true;
		}
	}
void del_before_slash(char *name)
{
int size = strlen(name);
int rec = -1;
for(int i = size - 2; i >= 0; i--)
	{
	if(name[i] == '/')
		{
		rec = i;
		break;
		}
	}
if(rec == -1)
	{
	return;
	}
else	
	{
	for(int i = rec + 1; i < size; i++)
		{
		name[i - rec - 1] = name[i];
		}
	name[size - rec - 1] = '\0';
	}
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
printf("readdir\n");
printf("%s\n",path);
char *path2 = strdup(path);
char *name;
if(!strcmp(path,"/"))
	{
	entry *E = T.head;
	
	while(E != T.tail)
		{
		int valid = check_str(E->name);
		if(valid)
			{	
			name = strdup(E->name);
			if(name[strlen(name) - 1] == '/')
				{
				name[strlen(name) - 1] = '\0';
				}
	//		printf("name1: %s\n",E->name);
			filler(buffer,name,NULL,0);
			}
		E = E->next;

		}	
	int valid = check_str(E->name);
	if(valid)
		{
		name = strdup(E->name);
		if(name[strlen(name) - 1] == '/')
			{
			name[strlen(name) - 1] = '\0';
			}
		filler(buffer,name,NULL,0);
	//	printf("name2: %s\n",E->name);
		}
	//filler(buffer,"AAA",NULL,0);


	printf("Finish fill\n");
	}

else
	{
	entry *E = T.head;
	while(E != T.tail)
		{
		printf("cmp: %s, %s\n",E->name,path2);
		int valid = check_str_pre(E->name,path2);
		if(valid)
			{
			name = strdup(E->name);

			del_before_slash(name);	
			
			if(name[strlen(name) - 1] == '/')
				{
				name[strlen(name) - 1] = '\0';
				}

			printf("S: %s\n",name);
			if(name[0] != '\0')
				filler(buffer,name,NULL,0);
			}
		E = E->next;
		}	
	int valid = check_str_pre(E->name,path2);
	if(valid)
		{
		name = strdup(E->name);
		del_before_slash(name);
		
		if(name[strlen(name) - 1] == '/')
			{
			name[strlen(name) - 1] = '\0';
			}
		printf("S: %s\n",name);
		if(name[0] != '\0')
			filler(buffer,name,NULL,0);
		}
	}
printf("end_readdir\n");

return 0;
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) {
printf("read\n");
printf("%s\n",path);

char *path2 = strdup(path);

if(!strcmp(path,"/"))
	{
	return 0;
	}
else
	{
	entry *E = T.head;
	E = find_entry(path2);
	if(!E->exist)
		{
		return 0;
		}
	else
		{
		if(E->lk_flag == '5')
			{
			return 0;
			}
		else
			{
			int bg = offset;
			if(bg + size <= E->size)
				{
				for(int i = bg ; i < bg + size; i++)
					{
					buffer[i - bg] = E->data[i];
					}
				return size;
				}
			else
				{
				for(int i = bg; i < E->size; i++)
					{
					buffer[i - bg] = E->data[i];
					}
				return (E->size - bg);
				}
			}
		}
	}
return 0;
}
static struct fuse_operations op;
int main(int argc, char *argv[])
{
FILE *fp = fopen("test.tar","r");
make_table(fp);
fclose(fp);
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

