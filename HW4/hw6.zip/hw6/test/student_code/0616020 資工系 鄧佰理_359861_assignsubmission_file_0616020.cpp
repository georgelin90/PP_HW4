/*
Student No.: 0616020
Student Name: Bai-Li Deng
Email: rayman0411@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be
posted to a public server, such as a public GitHub repository or a public
web page.
*/
#define FUSE_USE_VERSION 30

#include <fuse.h>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <set>
#include<iostream>
#include <sys/stat.h>
#include <errno.h>
#include <vector>
using namespace std;
string mount_point;
vector<vector<char> > tar_blocks;
bool read_tar = false;
void get_tar_data(){
	read_tar = true;
	ifstream ifs("test.tar",std::ifstream::binary);
	vector<char> buf(512);
	while(ifs){
		ifs.read(buf.data(),buf.size());
		tar_blocks.push_back(buf);
	}
	ifs.close();
	bool onezero = false;
	for(int i = 0; i < tar_blocks.size(); i++){
		bool allzero = true;
		for(int j= 0; j < 512; j++){
			if(tar_blocks[i][j]!= 0){
				allzero = false;
				break;
			}
		}
		if(!allzero){
			onezero = false;
		}
		else{
			if(!onezero) onezero = true;
			else{
				tar_blocks.erase(tar_blocks.begin()+i,tar_blocks.end());
				break;
			}
		}
	}
}
int my_getattr(const char *path, struct stat *st){
	int res = 0;
	if(!read_tar){
		get_tar_data();
	}
	int index = 0;
	uid_t uid;
	gid_t gid;
	time_t mtime;
	mode_t mode;
	off_t size;
	//int uid,gid,mtime,mode,size;
	bool found = false;
	bool directory = false;
	while(index < tar_blocks.size()){
		string filepath="/";
		for(int i = 0; i < 100; i++){
			if(tar_blocks[index][i] == '\0'){
				break;
			}
			filepath.push_back(tar_blocks[index][i]);
		}
		int file_size = 0;
		for(int i = 0; i < 12; i++){
			if(tar_blocks[index][i+124]>'7'||tar_blocks[index][i+124]<'0') break;
			file_size = file_size* 8 + tar_blocks[index][i+124] - '0';
		}
		//file_size /=8;
		//file_size = ((file_size+511)& ~511)/8;
		if(filepath[filepath.size()-1]=='/'&&filepath != "/") filepath = filepath.substr(0,filepath.size()-1);
		if(filepath == path){
			found = true;
			size = file_size;
			uid = 0;
			for(int i = 0; i <8; i++){
				if(tar_blocks[index][i+108]>'7'||tar_blocks[index][i+108]<'0') break;
				uid = uid * 8 + (tar_blocks[index][i+108]-'0');
			}
			gid = 0;
			for(int i = 0; i< 8; i++){
				if(tar_blocks[index][i+116]>'7'||tar_blocks[index][i+116]<'0') break;
				gid = gid * 8 + (tar_blocks[index][i+116]-'0');
			}
			mtime = 0;
			for(int i = 0; i < 12; i++){
				if(tar_blocks[index][i+136]>'7'||tar_blocks[index][i+136]<'0') break;
				mtime = mtime *8 + (tar_blocks[index][i+136]-'0');
			}
			mode = 0;
			for(int i = 0; i < 8; i++){
				if(tar_blocks[index][i+100]>'7'||tar_blocks[index][i+100]<'0') break;
				mode = mode * 8 + (tar_blocks[index][i+100]-'0');
			}
			if(tar_blocks[index][156]=='5'){
				directory = true;
			}
		}
		int blocks = (file_size)/512;
		if(file_size%512!=0) blocks++;
		index += 1+blocks;	
	}
	//memset(st,0,sizeof(st));
	if(found){
		if(strcmp(path,"/")==0){
			st->st_mode = S_IFDIR|0444;
			st->st_size = 0;
		}
		else if(directory){
			st->st_mode = S_IFDIR|mode;
		}
		else{
			st->st_mode = S_IFREG|mode;
		}
		st->st_gid = gid;
		st->st_uid = uid;
		st->st_mtime = mtime;
		st->st_size = size;
	}
	else res = -ENOENT;
	return res;
}
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info *fi) {
	string dir_root(path);
	if(dir_root != "/") dir_root += "/";
	if(!read_tar){
		get_tar_data();
	}
	int index = 0;
	set<string> fnls;
	while(index < tar_blocks.size()){
		string filepath="/";
		for(int i = 0; i < 100; i++){
			if(tar_blocks[index][i] == '\0'){
				break;
			}
			filepath.push_back(tar_blocks[index][i]);
		}
		if(dir_root.size()<filepath.size()){
			bool match = true;
			for(int i = 0; i<dir_root.size()&&match;i++){
				if(dir_root[i]!= filepath[i]){
					match = false;
					break;
				}
			}
			for(int i = dir_root.size();i <filepath.size()-1&&match;i++){
				if(filepath[i]=='/'){
					match = false;
					break;
				}
			}
			if(match){
				string filename = filepath.substr(dir_root.size(),-1);
				if(filename[filename.size()-1]=='/') filename = filename.substr(0,filename.size()-1);
				fnls.insert(filename);
				//filler(buffer,filename.c_str(),NULL,0);
			}
		}
		int file_size = 0;
		for(int i = 0; i < 12; i++){
			if(tar_blocks[index][i+124]<'0'||tar_blocks[index][i+124]>'7') break;
			file_size = file_size* 8 + tar_blocks[index][i+124] - '0';
		}
		//file_size/=8;
		//file_size = ((file_size+511)& ~511)/8;
		int blocks = (file_size)/512;
		if(file_size%512!=0) blocks++;
		index += 1+blocks;	
	}
		for(set<string>::iterator iter = fnls.begin();iter != fnls.end(); iter++){
			filler(buffer,iter->c_str(),NULL,0);
		}
	return 0; //Always return 0;*/
}
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi) { 
	int location = -1;
	int fz;
	int index =0;
	while(index < tar_blocks.size()){
		string filepath="/";
		for(int i = 0; i < 100; i++){
			if(tar_blocks[index][i] == '\0'){
				break;
			}
			filepath.push_back(tar_blocks[index][i]);
		}
		int file_size = 0;
		for(int i = 0; i < 12; i++){
			if(tar_blocks[index][i+124]>'7'||tar_blocks[index][i+124]<'0') break;
			file_size = file_size* 8 + tar_blocks[index][i+124] - '0';
		}
		//file_size /=8;
		//file_size = ((file_size+511)& ~511)/8;
		if(filepath[filepath.size()-1]=='/'&&filepath != "/") filepath = filepath.substr(0,filepath.size()-1);
		if(filepath == path){
			location = index;
			fz = file_size;
		}
		int blocks = (file_size)/512;
		if(file_size%512!=0) blocks++;
		index += 1+blocks;	
	}
	if(location == -1) return -ENOENT;
	size_t sent = 0;
	int data_loc = location+1;
	int block_loc =0;
	while(sent < size && fz >0){
		if(offset>0){
			offset--;
		}
		else{
			buffer[sent]=tar_blocks[data_loc][block_loc];
			sent++;
		}
		block_loc++;
		if(block_loc >= 512){
			block_loc = 0;
			data_loc++;
		}
		fz--;
	}
	return sent;
}

static struct fuse_operations op;
int main(int argc, char *argv[])
{
	if(argc >=3){
		mount_point=argv[2];
	}
    memset(&op, 0, sizeof(op)); 
    op.getattr = my_getattr;
    op.readdir = my_readdir;
    op.read = my_read;
    return fuse_main(argc, argv, &op, NULL);
}

