/*
Student No.: 0616206
Student Name: Kuan Chieh Wu
Email: a87954g@gmail.com
SE tag: xnxcxtxuxoxsx
Statement: I am fully aware that this program is not supposed to be posted to a public server, such as a public GitHub repository or a public web page.
*/

#define FUSE_USE_VERSION 30

#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <string>
#include <fuse.h>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <vector>
#include <map>
using namespace std;

char buf[5000000];

struct tar_header{
	string filename;
	long long filemode;
	long long uid;
	long long gid;
	long long fs;
	long long mt;
	string data;
};

map<string, tar_header> mfile; //for bonus
map<string, tar_header> ::iterator it;

string content_data(int &pos, int len){
	string data;
	data.clear();

	//當讀到0就break,不然就加到string data中
	for(int i=0; i<len; i++){
		if(buf[pos+i]==0)
			break;
		else
			data += buf[pos+i];
	}
	pos += len; //use pointer, for content length
	return data;
}

long long string_to_octal(string data){
	long long ans = 0, power = 1;
	for(int i=data.size()-1; i>=0; i--){ //從個位數開始，所以從字串最尾端走
		if(data[i]>='0' && data[i]<='9'){
			ans += power * (data[i]-'0');
			power = power * 8;
		}
	}
	return ans;
}

string gat_all_data(int &pos, int len){
	string data;
	data.clear();
	//不像content_data一樣要在0的時候break, 因為資料中會有出現0的狀況，不能break，也要讀進去
	for(int i=0; i<len; i++){
		data += buf[pos+i];
	}
	pos += len;
	return data;
}

void swap(string &a, string &b){
	string tmp;
	tmp = a;
	a = b;
	b = tmp;
}

void partition(string data, string &parent, string &child){
	parent.clear();
	child.clear();
	//不在for迴圈中一起做因為可能為"/"
	child += data[data.length()-1];
	int index;
	for(index = data.length()-2; index>=0; index--){
		if(data[index] == '/')
			break;
		child += data[index]; //加到看到倒數第一個文件名前的"/"
	}
	if(index >= 0){
		for(; index>=0; index--)
			parent += data[index];
	}
	/*for(; index>=0; index--)
		parent += data[index];*/
	//因為從檔案後面開始讀＋放，所以檔名順序是倒著的，要交換成正確的檔名
	for(int i=0; i<parent.length()/2; i++)
		swap(parent[i], parent[parent.length()-1-i]);
	for(int i=0; i<child.length()/2; i++)
		swap(child[i], child[child.length()-1-i]);

	return;
}

//Get a list of files and directories that reside in the directory. (Get file names only)
/************************
 *        readdir       *
 ************************/
int my_readdir(const char *path, void *buffer, fuse_fill_dir_t filler, off_t ofmfileet,struct fuse_file_info *fi){
	string rel_path = string(path);
    filler(buffer, ".", NULL, 0); //當層
    filler(buffer, "..", NULL, 0); //上一層
    //string rel_path = string(path);
    for(it = mfile.begin(); it != mfile.end(); it++){
        string parent;
        string child;
        //切出資料關係
        partition(it->second.filename, parent, child);
        //cout << "a" << endl;

        if(parent==rel_path || parent==rel_path+"/"){
            if(child[child.length()-1]=='/')
                child.resize(child.length()-1); //不用看child後面的"/"

            //c_str()是將一個 AnsiString 的字串轉換成以NULL結尾的字串 (?)
            filler(buffer, child.c_str(), NULL, 0);
        }
    }
    return 0;
}

//Get attributes of a file/directory.
/************************
 *        getattr       *
 ************************/
int my_getattr(const char *path, struct stat *st){
	string rel_path = string(path);

	//the root directory (“/”)
	if(rel_path=="/"){
		st->st_mode = S_IFDIR | 0444;
		st->st_uid = getuid();
		st->st_gid = getgid();
		st->st_size = 0;
		st->st_mtime = time(NULL);

		return 0;
	}
	else{
		for(it = mfile.begin(); it != mfile.end(); it++){
			if(it->second.filename == rel_path || it->second.filename == rel_path+"/"){
				//Other directories
				if(it->second.filename[it->second.filename.length()-1]=='/')
					st->st_mode = S_IFDIR | it->second.filemode;
				//Regular files
				else
					st->st_mode = S_IFREG | it->second.filemode;

				st->st_uid = it->second.uid;
				st->st_gid = it->second.gid;
				st->st_size = it->second.fs;
				st->st_mtime = it->second.mt;

				return 0;
			}
		}
		return -ENOENT;
	}
	//return 0;
}

//Get the content of a file
/************************
 *         read         *
 ************************/
int my_read(const char *path, char *buffer, size_t size, off_t offset, struct fuse_file_info *fi){
	string rel_path = string(path);

	for(it = mfile.begin(); it != mfile.end(); it++){
		if(it->second.filename == rel_path || it->second.filename == rel_path+"/"){
			memcpy(buffer, it->second.data.c_str() + offset, size);
			//Return number of bytes read successfully.
			//cout << size << endl;
			return size;
		}
	}
	return 0;
}

static struct fuse_operations op;

int main(int argc, char *argv[]){
	/************************
	 *     open test.tar    *
	 ************************/
	FILE* f;
	long long fsize;
	f = fopen("test.tar", "rb");
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    if(fsize%512!=0){
    	cout << "wrong file" << endl;
    }
    fread(buf, fsize, sizeof(char), f);
    fclose(f);
    //cout << "a" << endl;

    int pos = 0;
    while(pos < fsize){
    	tar_header current_file;
    	current_file.filename = "/" + content_data(pos, 100); //100 bytes  File name
    	if(current_file.filename == "/") break;
    	current_file.filemode = string_to_octal(content_data(pos, 8)); //8 bytes  File mode
    	current_file.uid = string_to_octal(content_data(pos, 8)); //8 bytes  User ID
    	current_file.gid = string_to_octal(content_data(pos, 8)); //8 bytes  Group ID
    	current_file.fs = string_to_octal(content_data(pos, 12)); //12 bytes  File size
    	current_file.mt = string_to_octal(content_data(pos, 12)); //12 bytes  Modify time

    	pos += 8; //8 bytes  Header checksum
    	pos += 1; //1 bytes  Link flag
    	pos += 100; //100 bytes  Linkname
    	pos += 8; //8 bytes  Magic
    	pos += 32; //32 bytes  User name
    	pos += 32; //32 bytes  Group name
    	pos += 8; //8 bytes  Major device ID
    	pos += 8; //8 bytes  Minor device ID
    	pos += 167; //167 bytes  Padding

    	//pos = pos + 8 + 1 + 100 + 8 + 32 + 32 + 8 + 8 + 167;
    	current_file.data = gat_all_data(pos, current_file.fs);

    	int remain = pos % 512;
    	if(remain != 0)
    		pos += 512 - remain;

    	//for bonus
    	//當出現新的filename或是看同樣檔名的timestamp，找出哪個是新的file
    	//新增資料或是更新資料
    	if(mfile.find(current_file.filename)==mfile.end())
    		mfile[current_file.filename] = current_file;
    	else if(mfile[current_file.filename].mt<current_file.mt)
    		mfile[current_file.filename] = current_file;
    	//cout << "b" << endl;
    	//cout << current_file.filename<<endl;
    }
	//cout << "c" << endl;
	memset(&op, 0, sizeof(op));
	//cout << "c" << endl;
	op.getattr = my_getattr;
	//cout << "a" << endl;
	op.readdir = my_readdir;
	//cout << "b" << endl;
	op.read = my_read;
	//cout << "c" << endl;
	//return 0;
	return fuse_main(argc, argv, &op, NULL);
}