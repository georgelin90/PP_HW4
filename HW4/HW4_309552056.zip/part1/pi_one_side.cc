#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---

    long long circle = 0, *temp;
    MPI_Win win;
    unsigned int seed;
    bool done[20]{false};
    double d = (double)1 / RAND_MAX;

    // TODO: MPI init
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    const long long iter = tosses / world_size;
    done[world_rank] = false;
    if (world_rank == 0)
    {
	MPI_Win_allocate(world_size * sizeof(long long), sizeof(long long), MPI_INFO_NULL, MPI_COMM_WORLD, &temp, &win);
        // Master
	seed = (unsigned int)world_size * time(NULL);
	for(int i = 0; i<world_size; i++)
		temp[i] = 0;
	for(int i = 0; i < iter; i++)
	{
		double x = (double) rand_r(&seed) * d;
		double y = (double) rand_r(&seed) * d;
		if(x*x + y*y <= 1)
			circle ++;
	}
	while(done[0] == false)
	{
		done[0] = true;
		MPI_Win_lock(MPI_LOCK_SHARED, 0, 0, win);
		for(int i = 1; i<world_size; i++)
			if(temp[i] == 0){
			       	done[0] = false;
				//printf("temp%d: %lld", i, temp[i]);
			}
		MPI_Win_unlock(0, win);
	}
	for(int i = 1; i<world_size; i++)
	{
		circle += temp[i];
	}
    }
    else
    {
        MPI_Win_create(NULL, 0, 1, MPI_INFO_NULL, MPI_COMM_WORLD, &win);
	seed = (unsigned int)world_rank * time(NULL);
	for(int i = 0; i < iter; i++)
	{
		double x = (double) rand_r(&seed) * d;
		double y = (double) rand_r(&seed) * d;
		if(x*x + y*y <= 1)
			circle ++;
	}
	MPI_Win_lock(MPI_LOCK_EXCLUSIVE, 0, 0, win);
	MPI_Put(&circle, 1, MPI_LONG_LONG, 0, world_rank, 1, MPI_LONG_LONG, win);
	MPI_Win_unlock(0, win);
    }

    MPI_Win_free(&win);

    if (world_rank == 0)
    {
        // TODO: handle PI result
	pi_result = (double) 4 * circle / tosses;
        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
//	MPI_Win_free(&win);
        // ---
    }
    MPI_Finalize();
    return 0;
}
